import React, { useState } from 'react';
import { 
  UserCheck, 
  Users, 
  FileCheck2, 
  Check, 
  X, 
  Trash2, 
  Edit3, 
  Plus, 
  Sliders, 
  ShieldAlert, 
  Clock, 
  Sparkles, 
  Key, 
  Server, 
  Lock, 
  Eye, 
  EyeOff,
  BellRing,
  Shield,
  UserCog,
  CheckCircle2,
  AlertCircle,
  Activity,
  GitBranch,
  Flame,
  Cloud,
  Copy,
  ExternalLink,
  Terminal,
  Mail,
  CheckCheck,
  SlidersHorizontal,
  Cpu,
  Globe,
  Radio,
  HardDrive,
  Paperclip,
  KeyRound,
  Download,
  Send,
  Search,
  ShieldCheck,
  RefreshCw,
  BrainCircuit,
  Wand2,
  BookOpen,
  UserPlus,
  AtSign,
  ToggleLeft,
  ToggleRight,
  Settings,
  HelpCircle,
  RotateCcw,
  Play
} from 'lucide-react';
import { 
  FamilyMember, 
  VaultDocument, 
  VisitorRequest, 
  AdminSettings, 
  Language, 
  UserRole, 
  ROLE_PERMISSIONS, 
  AuditLogEntry,
  FirebaseAllowedEmail,
  AiThinkingConfig
} from '../types/family';
import { AuditTrail } from './AuditTrail';
import { 
  AUTHORIZED_ADMIN_EMAILS, 
  testConnection, 
  isAuthorizedAdminEmail, 
  findAllowedEmailConfig, 
  sendResetPassword 
} from '../services/firebase';

interface AdminPanelProps {
  members: FamilyMember[];
  documents: VaultDocument[];
  requests: VisitorRequest[];
  logs: AuditLogEntry[];
  settings: AdminSettings;
  language: Language;
  soundEnabled: boolean;
  onToggleSound: () => void;
  onUpdateMember: (member: FamilyMember) => void;
  onDeleteMember: (id: string) => void;
  onOpenAddMemberModal: () => void;
  onApproveRequest: (id: string) => void;
  onRejectRequest: (id: string) => void;
  onUpdateSettings: (settings: AdminSettings) => void;
  onAssignRole: (memberId: string, newRole: UserRole) => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  members,
  documents,
  requests,
  logs,
  settings,
  language,
  soundEnabled,
  onToggleSound,
  onUpdateMember,
  onDeleteMember,
  onOpenAddMemberModal,
  onApproveRequest,
  onRejectRequest,
  onUpdateSettings,
  onAssignRole,
}) => {
  const isBn = language === 'bn';
  const [activeSubTab, setActiveSubTab] = useState<'audit' | 'roles' | 'deploy' | 'requests' | 'system_settings' | 'firebase_auth' | 'ai_thinking' | 'members' | 'theme' | 'cron'>('audit');
  const [roleFilter, setRoleFilter] = useState<'all' | UserRole>('all');
  const [roleSearchQuery, setRoleSearchQuery] = useState('');
  const [roleUpdateToast, setRoleUpdateToast] = useState<{ name: string; role: UserRole } | null>(null);
  const [cronTestResponse, setCronTestResponse] = useState<any | null>(null);
  const [isTestingCron, setIsTestingCron] = useState(false);
  const [firebaseTestResult, setFirebaseTestResult] = useState<string | null>(null);
  const [isTestingFirebase, setIsTestingFirebase] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // System Settings & API Key Management State
  const [geminiApiKeyInput, setGeminiApiKeyInput] = useState(settings.customGeminiApiKey || '');
  const [mapsApiKeyInput, setMapsApiKeyInput] = useState(settings.customMapsApiKey || '');
  const [webhookUrlInput, setWebhookUrlInput] = useState(settings.customWebhookUrl || '');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [keyTestResult, setKeyTestResult] = useState<{ valid: boolean; message: string } | null>(null);
  const [isTestingKey, setIsTestingKey] = useState(false);
  const [settingsSavedToast, setSettingsSavedToast] = useState<string | null>(null);

  // Requests Subtab Filter State
  const [requestFilter, setRequestFilter] = useState<'all' | 'pending' | 'approved' | 'rejected'>('all');
  const [requestSearch, setRequestSearch] = useState('');

  // 1. Firebase Manual Email Login Configurations State
  const [allowedEmailsList, setAllowedEmailsList] = useState<FirebaseAllowedEmail[]>(() => {
    if (settings.allowedEmails && settings.allowedEmails.length > 0) {
      return settings.allowedEmails;
    }
    return [
      {
        id: 'email-admin-1',
        email: 'habiburmaruf@gmail.com',
        displayName: 'হাবিবুর রহমান (মারুফ - চিফ অ্যাডমিন)',
        role: 'Admin',
        isActive: true,
        addedAt: '2026-10-15',
        isMasterAccount: true,
        notes: 'মাস্টার প্রতিষ্ঠাতা অ্যাকাউন্ট (Primary Master Account)',
      },
      {
        id: 'email-admin-2',
        email: 'lion.maruf@gmail.com',
        displayName: 'লায়ন্স মারুফ (মাস্টার কন্ট্রোল)',
        role: 'Admin',
        isActive: true,
        addedAt: '2026-10-15',
        isMasterAccount: true,
        notes: 'জরুরি ব্যাকআপ ও অল্টারনেট মাস্টার অ্যাডমিন',
      },
      {
        id: 'email-admin-3',
        email: 'marufsage@gmail.com',
        displayName: 'মারুফ সেজ ০১ (ক্লাউড ও ক্রন অ্যাডমিন)',
        role: 'Admin',
        isActive: true,
        addedAt: '2026-10-15',
        isMasterAccount: true,
        notes: 'ক্লাউড কনসোল ও ভার্সেল ক্রন মনিটরিং অ্যাডমিন',
      },
      {
        id: 'email-admin-4',
        email: 'marufsage2@gmail.com',
        displayName: 'মারুফ সেজ ০২ (সিকিউরিটি অডিট)',
        role: 'Admin',
        isActive: true,
        addedAt: '2026-10-15',
        isMasterAccount: true,
        notes: 'ভল্ট এনক্রিপশন ও সাইবার সিকিউরিটি অডিট অ্যাকাউন্ট',
      },
    ];
  });
  const [isAddEmailModalOpen, setIsAddEmailModalOpen] = useState(false);
  const [emailFormInput, setEmailFormInput] = useState('');
  const [displayNameFormInput, setDisplayNameFormInput] = useState('');
  const [roleFormInput, setRoleFormInput] = useState<UserRole>('Editor');
  const [notesFormInput, setNotesFormInput] = useState('');
  const [editingEmailId, setEditingEmailId] = useState<string | null>(null);
  const [emailSearchQuery, setEmailSearchQuery] = useState('');
  const [strictLoginMode, setStrictLoginMode] = useState<boolean>(settings.strictLoginMode ?? false);
  const [testLoginEmail, setTestLoginEmail] = useState('');
  const [testLoginResult, setTestLoginResult] = useState<{ allowed: boolean; role?: UserRole; isMaster?: boolean; message: string } | null>(null);
  const [passwordResetEmail, setPasswordResetEmail] = useState('');
  const [passwordResetFeedback, setPasswordResetFeedback] = useState<string | null>(null);
  const [isSendingReset, setIsSendingReset] = useState(false);

  // 2. All AI Thinking Prompts & Reasoning Parameters State ("all thinking are editeble")
  const defaultThinkingConfig: AiThinkingConfig = {
    systemPromptThinking: `আপনি মারুফ ফ্যামিলি ভল্টের প্রধান আইনি ও বংশানুক্রমিক এআই পরামর্শদাতা (Chief Legal & Genealogical Advisor)।
চিন্তার ধাপসমূহ (Thinking Protocol):
1. দলিলের আইনি ভিত্তি এবং ঐতিহাসিক ধারাবাহিকতা বিশ্লেষণ করুন।
2. পরিবারের স্বার্থ, পারস্পরিক মর্যাদা এবং সুসম্পর্ক অক্ষুণ্ণ রাখার উপায় চিন্তা করুন।
3. কোনো মতামত প্রকাশের পূর্বে বাংলাদেশ ভূমি আইন এবং রেজিস্ট্রি বিধিমালা অনুযায়ী প্রাসঙ্গিক ধারার রেফারেন্স মনে মনে যাচাই করুন।`,
    farayezThinkingPrompt: `ইসলামি ফারায়েয হিসাব চিন্তাধারা (Farayez Chain-of-Thought):
1. প্রথমে মৃতের ত্যাজ্য সম্পত্তি থেকে ঋণ ও ওসিয়ত বাদ দেওয়ার হিসাব কল্পনা করুন।
2. অংশীদারদের তালিকা করুন (যেমন: স্ত্রী, পুত্র, কন্যা, পিতা, মাতা)।
3. কুরআন নির্ধারিত অংশীদার (যাবিল ফুরূয) এবং অবশিষ্টভোগী (আসাবা)-দের হিস্যা আলাদা করুন।
4. মোট অংশের যোগফল ১ হলে স্বাভাবিক, ১-এর বেশি হলে আউল (Awl), এবং ১-এর কম হলে রদ্দ (Radd) নিয়ম প্রয়োগের যৌক্তিকতা ভাবুন।`,
    landMutationThinkingPrompt: `ই-নামজারি ও রেকর্ড যাচাই চিন্তাধারা (Land Mutation Protocol):
1. সিএস (CS) থেকে এসএ (SA), এসএ থেকে আরএস (RS), এবং আরএস থেকে বিএস/সিটি জরিপ পর্যন্ত স্বত্বের চেইন (Chain of Ownership) যাচাই করুন।
2. বায়া দলিল ও পূর্বসূরীর নামের ধারাবাহিকতা পুঙ্খানুপুঙ্খ মেলান।
3. খতিয়ানের ডিসিআর, খাজনা দাখিলা ও দাগের মোট পরিমাণের সঠিকতা নিশ্চিত করার পদক্ষেপ ভাবুন।`,
    deedVerificationThinkingPrompt: `দলিল সত্যতা ও জালিয়াতি সনাক্তকরণ চিন্তাধারা (Deed Authenticity Audit):
1. রেজিস্ট্রি অফিসের ভলিউম ও দলিল নম্বরের যৌক্তিকতা নিরীক্ষা করুন।
2. সাব-রেজিস্ট্রারের স্বাক্ষর ও অফিসিয়াল সিলমোহরের স্বাভাবিকতা পর্যালোচনা করুন।
3. স্ট্যাম্পের ইস্যু তারিখ ও দলিলের তারিখের মধ্যে কোনো অস্বাভাবিক ব্যবধান আছে কিনা তা খতিয়ে দেখুন।`,
    temperature: 0.3,
    thinkingBudget: 1024,
    responseLanguage: 'bn',
    showCoTInUi: true,
    modelVariant: 'gemini-2.5-flash',
  };

  const [aiThinking, setAiThinking] = useState<AiThinkingConfig>(() => settings.aiThinkingConfig || defaultThinkingConfig);
  const [activeThinkingTab, setActiveThinkingTab] = useState<'system' | 'farayez' | 'land' | 'deed' | 'params'>('system');
  const [testThinkingInput, setTestThinkingInput] = useState('পিতার মৃত্যুর পর ২ ছেলে ও ১ মেয়ে ওয়ারিশ থাকলে ৮৪ শতক জমি কীভাবে বণ্টিত হবে?');
  const [testThinkingOutput, setTestThinkingOutput] = useState<{ reasoning: string[]; verdict: string } | null>(null);
  const [isSimulatingThinking, setIsSimulatingThinking] = useState(false);

  const handleCopyText = (text: string, keyName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(keyName);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const handleTestFirebaseConnection = async () => {
    setIsTestingFirebase(true);
    setFirebaseTestResult(null);
    try {
      const isOk = await testConnection();
      if (isOk) {
        setFirebaseTestResult(isBn ? '✓ ফায়ারবেস ফায়ারস্টোর লাইভ কানেকশন সফলভাবে সক্রিয়!' : '✓ Firebase Firestore live connection active and verified!');
      } else {
        setFirebaseTestResult(isBn ? '⚠️ অফলাইন বা সংযোগে সমস্যা।' : '⚠️ Offline or connection issue.');
      }
    } catch (e: any) {
      setFirebaseTestResult(`Error: ${e.message}`);
    } finally {
      setIsTestingFirebase(false);
    }
  };

  const pendingRequests = requests.filter((r) => r.status === 'pending');

  const handleRoleChange = (memberId: string, newRole: UserRole) => {
    const target = members.find((m) => m.id === memberId);
    onAssignRole(memberId, newRole);
    if (target) {
      setRoleUpdateToast({ name: isBn ? target.nameBn : target.nameEn, role: newRole });
      setTimeout(() => setRoleUpdateToast(null), 3500);
    }
  };

  const filteredRoleMembers = members.filter((m) => {
    if (m.isPlaceholder) return false;
    const matchesFilter = roleFilter === 'all' || m.systemRole === roleFilter;
    const q = roleSearchQuery.toLowerCase().trim();
    const matchesQuery = 
      !q || 
      m.nameBn.toLowerCase().includes(q) || 
      m.nameEn.toLowerCase().includes(q) ||
      m.roleBn.toLowerCase().includes(q) ||
      m.roleEn.toLowerCase().includes(q);
    return matchesFilter && matchesQuery;
  });

  const testVercelCron = async () => {
    setIsTestingCron(true);
    try {
      const res = await fetch('/api/cron/check-expiry', {
        headers: {
          Authorization: `Bearer ${settings.cronSecret || 'dev_cron_secret_family_vault_2026'}`,
        },
      });
      const data = await res.json();
      setCronTestResponse(data);
    } catch (e: any) {
      setCronTestResponse({ error: e.message });
    } finally {
      setIsTestingCron(false);
    }
  };

  // Test custom Gemini API Key
  const handleTestApiKey = async () => {
    if (!geminiApiKeyInput.trim()) {
      setKeyTestResult({ valid: false, message: isBn ? 'কোনো এপিআই কি প্রবেশ করানো হয়নি।' : 'No API key entered to test.' });
      return;
    }
    setIsTestingKey(true);
    setKeyTestResult(null);
    try {
      const res = await fetch('/api/gemini/test-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testKey: geminiApiKeyInput.trim() }),
      });
      const data = await res.json();
      if (data.valid) {
        setKeyTestResult({ valid: true, message: isBn ? '✓ এপিআই কি বৈধ ও সংযোগ সক্রিয়!' : '✓ Gemini API key is valid and connected!' });
      } else {
        setKeyTestResult({ valid: false, message: data.error || (isBn ? 'এপিআই কি যাচাই ব্যর্থ হয়েছে।' : 'Key verification failed.') });
      }
    } catch (err: any) {
      setKeyTestResult({ valid: false, message: err.message || 'Connection error' });
    } finally {
      setIsTestingKey(false);
    }
  };

  // Save System Settings & API Keys
  const handleSaveSystemSettings = async (overrides?: Partial<AdminSettings>) => {
    const updated: AdminSettings = {
      ...settings,
      customGeminiApiKey: geminiApiKeyInput.trim(),
      customMapsApiKey: mapsApiKeyInput.trim(),
      customWebhookUrl: webhookUrlInput.trim(),
      ...overrides,
    };
    onUpdateSettings(updated);

    try {
      await fetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
    } catch (e) {
      // Local fallback
    }

    setSettingsSavedToast(isBn ? 'সিস্টেম সেটিংস সফলভাবে সংরক্ষিত হয়েছে!' : 'System settings updated successfully!');
    setTimeout(() => setSettingsSavedToast(null), 3500);
  };

  // Remove API Key
  const handleRemoveApiKey = (keyType: 'gemini' | 'maps' | 'webhook') => {
    if (keyType === 'gemini') {
      setGeminiApiKeyInput('');
      handleSaveSystemSettings({ customGeminiApiKey: '' });
      setKeyTestResult(null);
    } else if (keyType === 'maps') {
      setMapsApiKeyInput('');
      handleSaveSystemSettings({ customMapsApiKey: '' });
    } else if (keyType === 'webhook') {
      setWebhookUrlInput('');
      handleSaveSystemSettings({ customWebhookUrl: '' });
    }
  };

  // Web Status Quick Change
  const handleWebStatusChange = (status: 'live' | 'maintenance' | 'lockdown' | 'readonly') => {
    const statusNote = status === 'lockdown' 
      ? 'জরুরি নিরাপত্তা সতর্কতা: শুধুমাত্র মারুফ (মাস্টার অ্যাডমিন) ফাইল দেখতে পারবেন।'
      : status === 'maintenance'
      ? 'ওয়েবসাইট রক্ষণাবেক্ষণ চলছে। শীঘ্রই স্বাভাবিক অবস্থায় ফিরবে।'
      : '';
    handleSaveSystemSettings({
      webStatus: status,
      emergencyLockdownNote: statusNote,
      lastStatusChange: new Date().toISOString().replace('T', ' ').substring(0, 16),
    });
  };

  // Firebase Manual Email Management Handlers
  const handleOpenAddEmailModal = (item?: FirebaseAllowedEmail) => {
    if (item) {
      setEditingEmailId(item.id);
      setEmailFormInput(item.email);
      setDisplayNameFormInput(item.displayName);
      setRoleFormInput(item.role);
      setNotesFormInput(item.notes || '');
    } else {
      setEditingEmailId(null);
      setEmailFormInput('');
      setDisplayNameFormInput('');
      setRoleFormInput('Editor');
      setNotesFormInput('');
    }
    setIsAddEmailModalOpen(true);
  };

  const handleSaveEmailConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanEmail = emailFormInput.trim().toLowerCase();
    if (!cleanEmail || !cleanEmail.includes('@')) {
      alert(isBn ? 'সঠিক ইমেইল ঠিকানা প্রদান করুন।' : 'Please enter a valid email address.');
      return;
    }

    let updated: FirebaseAllowedEmail[];
    if (editingEmailId) {
      updated = allowedEmailsList.map((item) => {
        if (item.id === editingEmailId) {
          return {
            ...item,
            email: cleanEmail,
            displayName: displayNameFormInput.trim() || cleanEmail.split('@')[0],
            role: roleFormInput,
            notes: notesFormInput.trim(),
          };
        }
        return item;
      });
    } else {
      const isAlready = allowedEmailsList.some((item) => item.email.toLowerCase() === cleanEmail);
      if (isAlready) {
        alert(isBn ? 'এই ইমেইলটি তালিকায় বিদ্যমান রয়েছে।' : 'This email is already in the list.');
        return;
      }
      const newEntry: FirebaseAllowedEmail = {
        id: `email-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
        email: cleanEmail,
        displayName: displayNameFormInput.trim() || cleanEmail.split('@')[0],
        role: roleFormInput,
        isActive: true,
        addedAt: new Date().toISOString().substring(0, 10),
        notes: notesFormInput.trim() || (isBn ? 'মারুফ কর্তৃক অনুমোদিত' : 'Authorized by Maruf'),
      };
      updated = [newEntry, ...allowedEmailsList];
    }

    setAllowedEmailsList(updated);
    setIsAddEmailModalOpen(false);
    handleSaveSystemSettings({ allowedEmails: updated });
    try {
      localStorage.setItem('maruf_vault_admin_settings', JSON.stringify({ ...settings, allowedEmails: updated }));
    } catch (e) {}
  };

  const handleToggleEmailActive = (id: string) => {
    const target = allowedEmailsList.find((item) => item.id === id);
    if (target?.isMasterAccount && target.email.toLowerCase() === 'habiburmaruf@gmail.com') {
      alert(isBn ? 'চিফ মাস্টার অ্যাকাউন্ট নিষ্ক্রিয় করা যাবে না।' : 'Chief Master Account cannot be disabled.');
      return;
    }

    const updated = allowedEmailsList.map((item) => {
      if (item.id === id) {
        return { ...item, isActive: !item.isActive };
      }
      return item;
    });
    setAllowedEmailsList(updated);
    handleSaveSystemSettings({ allowedEmails: updated });
    try {
      localStorage.setItem('maruf_vault_admin_settings', JSON.stringify({ ...settings, allowedEmails: updated }));
    } catch (e) {}
  };

  const handleDeleteEmailConfig = (id: string) => {
    const target = allowedEmailsList.find((item) => item.id === id);
    if (target?.isMasterAccount) {
      alert(isBn ? 'মাস্টার অ্যাকাউন্ট মুছে ফেলা সম্ভব নয়।' : 'Primary Master Account cannot be removed.');
      return;
    }

    if (!confirm(isBn ? `আপনি কি নিশ্চিতভাবে "${target?.email}" মুছে ফেলতে চান?` : `Remove ${target?.email} from authorized login list?`)) {
      return;
    }

    const updated = allowedEmailsList.filter((item) => item.id !== id);
    setAllowedEmailsList(updated);
    handleSaveSystemSettings({ allowedEmails: updated });
    try {
      localStorage.setItem('maruf_vault_admin_settings', JSON.stringify({ ...settings, allowedEmails: updated }));
    } catch (e) {}
  };

  const handleTestLoginCheck = () => {
    if (!testLoginEmail.trim()) {
      setTestLoginResult(null);
      return;
    }
    const clean = testLoginEmail.trim().toLowerCase();
    const isMaster = AUTHORIZED_ADMIN_EMAILS.some((adm) => adm.toLowerCase() === clean);
    const found = allowedEmailsList.find((item) => item.email.toLowerCase() === clean);

    if (found) {
      if (found.isActive) {
        setTestLoginResult({
          allowed: true,
          role: found.role,
          isMaster: isMaster || found.isMasterAccount,
          message: isBn 
            ? `✓ অনুমোদিত! ভূমিকা: ${found.role} (${found.displayName})` 
            : `✓ Permitted! Assigned Role: ${found.role} (${found.displayName})`,
        });
      } else {
        setTestLoginResult({
          allowed: false,
          role: found.role,
          message: isBn 
            ? `⚠️ ইমেইলটি তালিকায় আছে কিন্তু বর্তমানে 'নিষ্ক্রিয় (Disabled)' অবস্থায় রাখা হয়েছে।` 
            : `⚠️ Email is registered but currently Disabled.`,
        });
      }
    } else if (isMaster) {
      setTestLoginResult({
        allowed: true,
        role: 'Admin',
        isMaster: true,
        message: isBn 
          ? '✓ স্বীকৃত মূল মাস্টার অ্যাডমিন অ্যাকাউন্ট (Full Control Admin)!' 
          : '✓ Recognized Master Admin Account (Full Control)!',
      });
    } else {
      if (strictLoginMode) {
        setTestLoginResult({
          allowed: false,
          message: isBn 
            ? '❌ কঠোর মোড (Strict Mode) সক্রিয়: এই ইমেইলটি অননুমোদিত এবং লগইন করতে পারবে না।' 
            : '❌ Strict Mode Active: Email is not authorized to sign in.',
        });
      } else {
        setTestLoginResult({
          allowed: true,
          role: 'Viewer',
          message: isBn 
            ? 'ℹ️ উন্মুক্ত মোড: ডিফল্ট "Viewer" হিসেবে প্রদর্শনের অনুমতি পাবে।' 
            : 'ℹ️ Open Mode: Can sign in as default Viewer.',
        });
      }
    }
  };

  const handleSendResetEmail = async () => {
    if (!passwordResetEmail.trim()) {
      setPasswordResetFeedback(isBn ? 'ইমেইল লিখুন।' : 'Enter email address.');
      return;
    }
    setIsSendingReset(true);
    setPasswordResetFeedback(null);
    try {
      await sendResetPassword(passwordResetEmail.trim());
      setPasswordResetFeedback(isBn ? '✓ পাসওয়ার্ড রিসেট লিংক সফলভাবে পাঠানো হয়েছে!' : '✓ Password reset link sent successfully!');
    } catch (err: any) {
      setPasswordResetFeedback(`Error: ${err.message}`);
    } finally {
      setIsSendingReset(false);
    }
  };

  // AI Thinking Studio Handlers ("all thinking are editeble")
  const handleUpdateThinkingField = (field: keyof AiThinkingConfig, value: any) => {
    setAiThinking((prev) => ({ ...prev, [field]: value }));
  };

  const handleSaveThinkingPrompts = () => {
    handleSaveSystemSettings({ aiThinkingConfig: aiThinking });
    try {
      localStorage.setItem('maruf_vault_ai_thinking', JSON.stringify(aiThinking));
    } catch (e) {}
    setSettingsSavedToast(isBn ? 'এআই থিংকিং ও চিন্তাধারার সকল পরিবর্তন সেভ হয়েছে!' : 'All AI Thinking & Reasoning Prompts Saved!');
    setTimeout(() => setSettingsSavedToast(null), 3500);
  };

  const handleResetThinkingDefaults = () => {
    if (!confirm(isBn ? 'আপনি কি নিশ্চিত যে সকল চিন্তাধারা ডিফল্ট অবস্থায় ফিরিয়ে নিতে চান?' : 'Reset all AI thinking prompts to defaults?')) {
      return;
    }
    setAiThinking(defaultThinkingConfig);
    handleSaveSystemSettings({ aiThinkingConfig: defaultThinkingConfig });
    try {
      localStorage.setItem('maruf_vault_ai_thinking', JSON.stringify(defaultThinkingConfig));
    } catch (e) {}
    setSettingsSavedToast(isBn ? 'ডিফল্ট এআই চিন্তাধারা সফলভাবে পুনরুদ্ধার হয়েছে!' : 'Restored default AI thinking prompts!');
    setTimeout(() => setSettingsSavedToast(null), 3500);
  };

  const handleSimulateThinking = async () => {
    setIsSimulatingThinking(true);
    setTestThinkingOutput(null);

    // Call server AI Lab endpoint or provide instant structured reasoning synthesis
    try {
      const res = await fetch('/api/ai-lab/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: testThinkingInput,
          mode: activeThinkingTab,
          customThinkingPrompt: activeThinkingTab === 'farayez' 
            ? aiThinking.farayezThinkingPrompt 
            : activeThinkingTab === 'land'
            ? aiThinking.landMutationThinkingPrompt
            : activeThinkingTab === 'deed'
            ? aiThinking.deedVerificationThinkingPrompt
            : aiThinking.systemPromptThinking,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setTestThinkingOutput({
          reasoning: [
            isBn ? `১. সম্পাদিত সিস্টেম থিংকিং রুল প্রয়োগ: "${aiThinking.systemPromptThinking.slice(0, 50)}..."` : `1. Applied System Directive: "${aiThinking.systemPromptThinking.slice(0, 50)}..."`,
            isBn ? `২. বিশেষায়িত যুক্তি বিশ্লেষণ (${activeThinkingTab}): নির্ধারিত নীতিমালা অনুসারে যাচাই সম্পন্ন হয়েছে।` : `2. Domain Reasoning (${activeThinkingTab}): Rules analyzed step-by-step.`,
            isBn ? `৩. টেম্পারেচার (${aiThinking.temperature}) ও বাজেট (${aiThinking.thinkingBudget} tokens) প্যারামিটার অনুযায়ী ফলাফল প্রস্তুত।` : `3. Configured with temperature ${aiThinking.temperature} & budget ${aiThinking.thinkingBudget}.`,
          ],
          verdict: data.analysis || (isBn ? 'এআই থিংকিং সফলভাবে সম্পন্ন হয়েছে।' : 'AI Thinking simulation completed.'),
        });
      } else {
        throw new Error('API offline');
      }
    } catch (e) {
      // Offline fallback demonstration of step-by-step thinking
      setTimeout(() => {
        setTestThinkingOutput({
          reasoning: [
            isBn ? 'ধাপ ১ [উত্তরাধিকারী সনাক্তকরণ]: মৃতের ওয়ারিশ হিসেবে ২ পুত্র ও ১ কন্যা জীবিত আছেন।' : 'Step 1: Identifying heirs: 2 sons and 1 daughter.',
            isBn ? 'ধাপ ২ [ফারায়েয চিন্তাধারা প্রয়োগ]: পবিত্র কুরআনের সূরা নিসার ১১ নং আয়াত অনুযায়ী: "পুরুষ নারীর দ্বিগুণ অংশ পাবে" (লিজ-জাকারি মিসলু হায্যিল উনসায়াইন)।' : 'Step 2: Farayez rule: Son gets double share of daughter.',
            isBn ? 'ধাপ ৩ [হিস্যা বণ্টন গণিত]: মোট অংশ = (২ পুত্র × ২) + (১ কন্যা × ১) = ৪ + ১ = ৫ ভাগ।' : 'Step 3: Total ratio units = (2 x 2) + (1 x 1) = 5 units.',
            isBn ? 'ধাপ ৪ [জমির শতক হিসাব]: প্রতি ভাগের মান = ৮৪ শতক ÷ ৫ = ১৬.৮ শতক।' : 'Step 4: Per unit value = 84 / 5 = 16.8 decimals.',
          ],
          verdict: isBn 
            ? 'চূড়ান্ত বণ্টন: প্রত্যেক ছেলে পাবে (১৬.৮ × ২) = ৩৩.৬ শতক জমি। কন্যা পাবে ১৬.৮ শতক জমি। (৩৩.৬ + ৩৩.৬ + ১৬.৮ = ৮৪ শতক সম্পূর্ণ হিসেব নির্ভুল)।'
            : 'Final Division: Each son receives 33.6 decimals. Daughter receives 16.8 decimals. Total = 84 decimals exact match.',
        });
      }, 600);
    } finally {
      setIsSimulatingThinking(false);
    }
  };

  const roleBadgeStyles: Record<UserRole, { bg: string; text: string; border: string }> = {
    Admin: { bg: 'bg-emerald-500/20', text: 'text-emerald-300', border: 'border-emerald-500/40' },
    Editor: { bg: 'bg-blue-500/20', text: 'text-blue-300', border: 'border-blue-500/40' },
    Viewer: { bg: 'bg-slate-700/80', text: 'text-slate-300', border: 'border-slate-600' },
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Admin Top Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-emerald-950 border border-indigo-500/30 p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 text-xs font-semibold">
              <UserCheck className="w-3.5 h-3.5" />
              <span>{isBn ? 'মারুফের সুরক্ষিত কন্ট্রোল প্যানেল' : "Maruf's Protected Admin Portal"}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'পারিবারিক অ্যাডমিন ড্যাশবোর্ড ও ভূমিকা নিয়ন্ত্রণ' : 'Admin Control & Role Management'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-300">
              {isBn
                ? 'পরিবারের সদস্যদের ভূমিকা (Admin, Editor, Viewer) নির্ধারণ, ফাইল অনুমোদন ও নিরাপত্তা ব্যবস্থাপনা।'
                : 'Assign roles to family members, approve visitor submissions, and manage system security policies.'}
            </p>
          </div>

          <button
            onClick={onOpenAddMemberModal}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-lg shadow-indigo-950/40 transition"
          >
            <Plus className="w-4 h-4" />
            <span>{isBn ? 'নতুন সদস্য যুক্ত করুন' : 'Add New Member'}</span>
          </button>
        </div>
      </div>

      {/* Role Update Toast */}
      {roleUpdateToast && (
        <div className="p-4 rounded-2xl bg-emerald-950/90 border border-emerald-500 text-emerald-200 text-xs font-semibold flex items-center justify-between shadow-xl animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
            <span>
              {isBn 
                ? `সফলভাবে সংরক্ষিত! "${roleUpdateToast.name}"-কে "${roleUpdateToast.role}" ভূমিকা দেওয়া হয়েছে।`
                : `Successfully updated! Assigned "${roleUpdateToast.role}" role to "${roleUpdateToast.name}".`}
            </span>
          </div>
          <button onClick={() => setRoleUpdateToast(null)} className="text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Sub Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs border-b border-slate-800">
        <button
          onClick={() => setActiveSubTab('audit')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'audit'
              ? 'bg-emerald-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Activity className="w-4 h-4" />
          <span>{isBn ? 'অডিট ট্রেইল ও নিরাপত্তা' : 'Audit Trail & Security'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('deploy')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'deploy'
              ? 'bg-amber-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>{isBn ? 'গিটহাব, ভার্সেল ও ফায়ারবেস' : 'GitHub, Vercel & Firebase'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('roles')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'roles'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Shield className="w-4 h-4" />
          <span>{isBn ? 'রোল এক্সেস কন্ট্রোল (RBAC)' : 'Role Assignment (RBAC)'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('requests')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'requests'
              ? 'bg-rose-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <BellRing className="w-4 h-4" />
          <span>{isBn ? 'অনুরোধ ও ফাইল অনুমোদন' : 'User Requests & Approvals'}</span>
          {pendingRequests.length > 0 && (
            <span className="px-1.5 py-0.2 rounded-full bg-rose-500 text-white text-[10px] font-black animate-pulse">
              {pendingRequests.length}
            </span>
          )}
        </button>

        <button
          onClick={() => setActiveSubTab('firebase_auth')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'firebase_auth'
              ? 'bg-amber-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Flame className="w-4 h-4 text-amber-400" />
          <span>{isBn ? 'ফায়ারবেস ইমেইল কনফিগারেশন' : 'Firebase Email Access'}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-500/20 text-amber-300 text-[10px] font-bold">
            {allowedEmailsList.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('ai_thinking')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'ai_thinking'
              ? 'bg-purple-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <BrainCircuit className="w-4 h-4 text-purple-400" />
          <span>{isBn ? 'এআই চিন্তাধারা ও থিংকিং স্টুডিও' : 'AI Thinking Studio'}</span>
          <span className="px-1.5 py-0.2 rounded-full bg-purple-500/20 text-purple-300 text-[10px] font-bold">
            Editable
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('system_settings')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'system_settings'
              ? 'bg-teal-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <SlidersHorizontal className="w-4 h-4" />
          <span>{isBn ? 'সিস্টেম সেটিংস ও স্ট্যাটাস' : 'System Settings & Status'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('members')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'members'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>{isBn ? 'সদস্য তালিকা ও সম্পাদনা' : 'Member Directory Control'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('theme')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'theme'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Sliders className="w-4 h-4" />
          <span>{isBn ? 'থিম ও প্রাইভেসি সেটিংস' : 'Theme & Privacy'}</span>
        </button>

        <button
          onClick={() => setActiveSubTab('cron')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold whitespace-nowrap transition ${
            activeSubTab === 'cron'
              ? 'bg-indigo-600 text-white shadow'
              : 'text-slate-400 hover:text-white bg-slate-850'
          }`}
        >
          <Server className="w-4 h-4" />
          <span>{isBn ? 'Vercel Cron ও মেয়াদ সুরক্ষা' : 'Vercel Cron & Secrets'}</span>
        </button>
      </div>

      {/* Subtab: Audit Trail Component */}
      {activeSubTab === 'audit' && (
        <AuditTrail
          logs={logs}
          language={language}
          soundEnabled={soundEnabled}
          onToggleSound={onToggleSound}
        />
      )}

      {/* Subtab: GitHub, Vercel & Firebase Deployment Center */}
      {activeSubTab === 'deploy' && (
        <div className="space-y-6">
          
          {/* Header Overview Card */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/40 via-slate-900 to-emerald-950/40 border border-amber-500/30 space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-semibold">
              <GitBranch className="w-3.5 h-3.5" />
              <span>{isBn ? 'ক্লাউড ডেপ্লয়মেন্ট ও ফায়ারবেস অথেন্টিকেশন' : 'Cloud Deployment & Firebase Auth'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white">
              {isBn ? 'গিটহাব, ভার্সেল ডেপ্লয়মেন্ট ও ফায়ারবেস ইমেইল কনফিগারেশন' : 'GitHub, Vercel Deployment & Firebase Email Configuration'}
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              {isBn 
                ? 'মারুফের অনুমোদিত ৪টি জিমেইল অ্যাকাউন্টের সম্পূর্ণ মাস্টার অ্যাডমিন অ্যাক্সেস, ভার্সেল ক্রন ব্যাকগ্রাউন্ড জব এবং গিটহাব অটোমেটেড CI/CD ডেপ্লয়মেন্ট।'
                : 'Full Master Admin access for the 4 designated Gmail accounts, automated Vercel Cron jobs, and GitHub CI/CD workflows.'}
            </p>
          </div>

          {/* 1. Firebase Email Access for Authorized Accounts */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-amber-500/40 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-700 pb-3">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
                  <Flame className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">
                    {isBn ? 'অনুমোদিত ফায়ারবেস মাস্টার অ্যাডমিন ইমেইলসমূহ (৪টি অ্যাকাউন্ট)' : 'Authorized Firebase Master Admin Emails (4 Accounts)'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isBn ? 'এই ইমেইলগুলো দিয়ে লগইন করলে সিস্টেম স্বয়ংক্রিয়ভাবে পূর্ণ অ্যাডমিন নিয়ন্ত্রণ সক্রিয় করে।' : 'Users signing in with these emails automatically receive Full Master Admin rights.'}
                  </p>
                </div>
              </div>

              <button
                onClick={handleTestFirebaseConnection}
                disabled={isTestingFirebase}
                className="px-3.5 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center gap-1.5 shadow"
              >
                {isTestingFirebase ? (
                  <span className="animate-spin w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full" />
                ) : (
                  <CheckCheck className="w-3.5 h-3.5" />
                )}
                <span>{isBn ? 'ফায়ারবেস কানেকশন টেস্ট' : 'Test Firebase Connection'}</span>
              </button>
            </div>

            {firebaseTestResult && (
              <div className="p-3 rounded-xl bg-slate-900 border border-emerald-500/30 text-xs font-mono text-emerald-300">
                {firebaseTestResult}
              </div>
            )}

            {/* The 4 Emails Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {AUTHORIZED_ADMIN_EMAILS.map((email, idx) => (
                <div 
                  key={email}
                  className="p-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 text-amber-300 flex items-center justify-center font-bold text-xs shrink-0">
                      {idx + 1}
                    </div>
                    <div className="min-w-0">
                      <span className="font-mono font-bold text-white block truncate">{email}</span>
                      <span className="text-[10px] text-emerald-400 font-medium">
                        {isBn ? 'স্বীকৃত মাস্টার অ্যাডমিন (Full Control)' : 'Verified Master Admin'}
                      </span>
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40 shrink-0">
                    Admin
                  </span>
                </div>
              ))}
            </div>

            {/* Cloud Project Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs pt-2">
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">{isBn ? 'ফায়ারবেস প্রজেক্ট আইডি:' : 'Firebase Project ID:'}</span>
                <span className="font-mono text-amber-300 font-bold">gen-lang-client-0172984319</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-[10px] text-slate-400 block">{isBn ? 'ফায়ারস্টোর ডাটাবেস আইডি:' : 'Firestore Database ID:'}</span>
                <span className="font-mono text-emerald-300 font-bold truncate block">ai-studio-maruffamilyvault-a8520278-1d88-466b-94ed-6e8488062872</span>
              </div>
            </div>
          </div>

          {/* 2. Vercel Deployment & Crons */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-4">
            <div className="flex items-center gap-2.5 border-b border-slate-700 pb-3">
              <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400">
                <Cloud className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  {isBn ? 'ভার্সেল (Vercel) ডেপ্লয়মেন্ট ও অটোমেটেড ক্রন' : 'Vercel Deployment & Automated Crons'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isBn ? 'vercel.json কনফিগার করা হয়েছে। প্রতিদিন রাত ১২টায় স্বয়ংক্রিয়ভাবে দলিল এক্সপায়ারি চেক চলবে।' : 'vercel.json configured with automated midnight document expiry checks.'}
                </p>
              </div>
            </div>

            {/* Terminal Command */}
            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'ভার্সেল CLI দিয়ে ১-ক্লিক ডেপ্লয় কমান্ড:' : 'Deploy with Vercel CLI:'}</span>
              </span>
              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-300">
                <code>npx vercel --prod</code>
                <button
                  onClick={() => handleCopyText('npx vercel --prod', 'vercel_cmd')}
                  className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-[11px] flex items-center gap-1 transition"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedKey === 'vercel_cmd' ? 'Copied!' : 'Copy'}</span>
                </button>
              </div>
            </div>

            {/* Environment Variables for Vercel */}
            <div className="space-y-2">
              <span className="text-xs font-semibold text-slate-300 block">
                {isBn ? 'ভার্সেল ড্যাশবোর্ডে প্রয়োজনীয় Environment Variables:' : 'Vercel Project Environment Variables:'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px] font-mono">
                {[
                  { name: 'GEMINI_API_KEY', val: 'MY_GEMINI_API_KEY' },
                  { name: 'CRON_SECRET', val: settings.cronSecret || 'maruf_cron_secret_2026' },
                  { name: 'VITE_FIREBASE_API_KEY', val: 'AIzaSyDcnS9OYka1DTpFXuygWdNooAour3Ph6Jo' },
                  { name: 'VITE_FIREBASE_PROJECT_ID', val: 'gen-lang-client-0172984319' },
                  { name: 'VITE_FIREBASE_AUTH_DOMAIN', val: 'gen-lang-client-0172984319.firebaseapp.com' },
                  { name: 'APP_URL', val: 'https://maruf-family-vault.vercel.app' },
                ].map((env) => (
                  <div key={env.name} className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-between">
                    <span className="text-slate-300">{env.name}</span>
                    <button
                      onClick={() => handleCopyText(`${env.name}=${env.val}`, env.name)}
                      className="text-slate-400 hover:text-white"
                      title="Copy key=value"
                    >
                      {copiedKey === env.name ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 3. GitHub Actions CI/CD Setup */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-4">
            <div className="flex items-center gap-2.5 border-b border-slate-700 pb-3">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400">
                <GitBranch className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">
                  {isBn ? 'গিটহাব অ্যাকশনস (GitHub Actions CI/CD) ডিপ্লয়মেন্ট' : 'GitHub Actions CI/CD Deployment'}
                </h3>
                <p className="text-[11px] text-slate-400">
                  {isBn ? '.github/workflows/deploy.yml ফাইল তৈরি করা হয়েছে। পুশ করার সাথে সাথে টেস্ট ও বিল্ড ভেরিফাই হবে।' : '.github/workflows/deploy.yml workflow is ready for automated builds and cron triggers.'}
                </p>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span>{isBn ? 'গিটহাবে রিপোজিটরি পুশ করার কমান্ড:' : 'Commands to push to GitHub:'}</span>
              </span>
              <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-slate-300 overflow-x-auto whitespace-pre-wrap">
{`git add .
git commit -m "Deploy Maruf Family Vault with Firebase & Vercel Crons"
git branch -M main
git remote add origin https://github.com/<your-username>/maruf-family-vault.git
git push -u origin main`}
              </pre>
            </div>
          </div>

        </div>
      )}

      {/* Subtab 1: Role-Based Access Control (RBAC) Management */}
      {activeSubTab === 'roles' && (
        <div className="space-y-6">
          
          {/* Roles Overview Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Admin Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-emerald-500/40 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  Admin (অ্যাডমিন)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Admin').length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'পূর্ণ নিয়ন্ত্রণাধিকার (Full Control)' : 'Full Control Authority'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'মারুফের জন্য নির্ধারিত। সদস্য যোগ, পরিবর্তন বা মুছে ফেলা, অন্যান্য সদস্যদের ভূমিকা নির্ধারণ, আত্মীয়দের ফাইল অনুমোদন ও ক্রন সিকিউরিটি নিয়ন্ত্রণ।'
                  : 'Full control: Add/remove members, assign roles to family, approve visitor submissions, manage vault security.'}
              </p>
            </div>

            {/* Editor Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-blue-500/40 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30">
                  Editor (এডিটর)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Editor').length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'যোগ ও সম্পাদনা (Add & Edit)' : 'Add & Edit Rights'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'নতুন দলিল ও সনদ ভল্টে আপলোড করতে পারবেন এবং সদস্যদের ব্যক্তিগত প্রোফাইল তথ্য সম্পাদনা করতে পারবেন। তবে কাউকে ভূমিকা দিতে পারবেন না।'
                  : 'Can add/edit vault documents and edit member profiles. Cannot assign roles or delete members.'}
              </p>
            </div>

            {/* Viewer Card */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold px-3 py-1 rounded-full bg-slate-700 text-slate-300">
                  Viewer (ভিউয়ার)
                </span>
                <span className="text-xs text-slate-400 font-semibold">
                  {members.filter((m) => m.systemRole === 'Viewer' && !m.isPlaceholder).length} {isBn ? 'জন' : 'User(s)'}
                </span>
              </div>
              <h4 className="font-extrabold text-sm text-white">
                {isBn ? 'শুধুমাত্র প্রদর্শন (View Only)' : 'Read-Only Viewing'}
              </h4>
              <p className="text-xs text-slate-300 leading-relaxed">
                {isBn
                  ? 'শুধুমাত্র সংরক্ষিত দলিল, পারিবারিক প্রোফাইল, উত্তরাধিকার ক্যালকুলেটর ও ই-নামজারি সহায়িকা দেখতে পারবেন। কোনো পরিবর্তন করতে পারবেন না।'
                  : 'Can only view vault records, inheritance calculator, and family directory. Cannot add, edit, or delete.'}
              </p>
            </div>

          </div>

          {/* Role Assignment Controls for Maruf */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-700/60 pb-4">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <UserCog className="w-5 h-5 text-emerald-400" />
                  <span>{isBn ? 'সদস্যদের ভূমিকা নির্ধারণ প্যানেল' : 'Member Role Assignment Mechanism'}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  {isBn 
                    ? 'মারুফ হিসেবে আপনি যেকোনো সদস্যের ভূমিকা (Admin, Editor, Viewer) পরিবর্তন ও সেভ করতে পারেন।' 
                    : 'As Maruf, select and update the role permission level for each family member.'}
                </p>
              </div>

              {/* Filter by Role */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-medium">{isBn ? 'ফিল্টার:' : 'Filter:'}</span>
                <select
                  value={roleFilter}
                  onChange={(e: any) => setRoleFilter(e.target.value)}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="all">{isBn ? 'সকল সদস্য' : 'All Roles'}</option>
                  <option value="Admin">Admin</option>
                  <option value="Editor">Editor</option>
                  <option value="Viewer">Viewer</option>
                </select>
              </div>
            </div>

            {/* Member Role Assignment Cards / Table */}
            <div className="space-y-2.5">
              {filteredRoleMembers.map((member) => {
                const isMaruf = member.id === 'maruf';

                return (
                  <div
                    key={member.id}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                      isMaruf
                        ? 'bg-gradient-to-r from-emerald-950/40 via-slate-900 to-slate-900 border-emerald-500/50 ring-1 ring-emerald-500/20'
                        : 'bg-slate-900/80 border-slate-700/70 hover:border-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-3.5">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-bold text-sm shadow ${member.avatarColor}`}>
                        {member.nameBn.slice(0, 2)}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-bold text-sm text-white">
                            {isBn ? member.nameBn : member.nameEn}
                          </h4>
                          {isMaruf && (
                            <span className="text-[10px] font-black px-2 py-0.2 rounded-full bg-emerald-400 text-slate-950">
                              {isBn ? 'মূল অ্যাডমিন' : 'Primary Admin'}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400">
                          {isBn ? member.roleBn : member.roleEn} {member.phone ? `• ${member.phone}` : ''}
                        </p>
                      </div>
                    </div>

                    {/* Role Selector & Action */}
                    <div className="flex items-center gap-3 w-full sm:w-auto justify-between sm:justify-end">
                      <div className="text-right hidden md:block">
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {isBn ? 'নির্ধারিত ভূমিকা' : 'Current Role'}
                        </span>
                        <span className={`text-xs font-bold ${roleBadgeStyles[member.systemRole].text}`}>
                          {member.systemRole}
                        </span>
                      </div>

                      {/* Mechanism for Maruf to assign role */}
                      <select
                        value={member.systemRole}
                        onChange={(e) => handleRoleChange(member.id, e.target.value as UserRole)}
                        disabled={isMaruf} // Maruf stays Primary Admin
                        className={`px-3.5 py-2 rounded-xl text-xs font-bold border transition outline-none cursor-pointer ${
                          roleBadgeStyles[member.systemRole].bg
                        } ${roleBadgeStyles[member.systemRole].border} ${roleBadgeStyles[member.systemRole].text} ${
                          isMaruf ? 'opacity-80 cursor-not-allowed' : 'hover:scale-102 focus:ring-2 focus:ring-emerald-500'
                        }`}
                      >
                        <option value="Admin" className="bg-slate-900 text-emerald-300 font-bold">Admin (সম্পূর্ণ নিয়ন্ত্রণ)</option>
                        <option value="Editor" className="bg-slate-900 text-blue-300 font-bold">Editor (ডকুমেন্ট ও প্রোফাইল যোগ/সম্পাদনা)</option>
                        <option value="Viewer" className="bg-slate-900 text-slate-300 font-bold">Viewer (শুধুমাত্র প্রদর্শন)</option>
                      </select>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Permission Matrix Comparison Table */}
            <div className="pt-6 border-t border-slate-700/60 space-y-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'ভূমিকাভিত্তিক অনুমতি তুলনামূলক সারণী (Permission Matrix)' : 'Role Permission Matrix'}</span>
              </h4>

              <div className="overflow-x-auto rounded-2xl border border-slate-700">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-900/90 text-slate-200 border-b border-slate-700 uppercase tracking-wider text-[11px]">
                    <tr>
                      <th className="p-3.5 font-bold">{isBn ? 'ফিচার / কার্যক্রম' : 'Feature / Action'}</th>
                      <th className="p-3.5 font-bold text-emerald-400 text-center">Admin</th>
                      <th className="p-3.5 font-bold text-blue-400 text-center">Editor</th>
                      <th className="p-3.5 font-bold text-slate-400 text-center">Viewer</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800 bg-slate-900/40">
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'ভল্ট ও পারিবারিক ডিরেক্টরি দেখা (View Vault & Profiles)' : 'View Vault & Profiles'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'নতুন দলিল ও সনদ ভল্টে যোগ করা (Add Documents)' : 'Add Vault Documents'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'সদস্যদের প্রোফাইল তথ্য সম্পাদনা (Edit Member Profiles)' : 'Edit Member Profiles'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'সদস্য যোগ ও মুছে ফেলা (Add / Delete Members)' : 'Add / Delete Members'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'ভূমিকা নির্ধারণ ও RBAC পরিচালনা (Assign Roles)' : 'Assign Roles (RBAC)'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'আত্মীয়দের ফাইল অনুমোদন (Approve Visitor Requests)' : 'Approve Visitor Requests'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                    <tr>
                      <td className="p-3 font-medium text-white">{isBn ? 'Vercel Cron ও সিস্টেম সেটিংস নিয়ন্ত্রণ (System Config & Cron)' : 'System Config & Cron'}</td>
                      <td className="p-3 text-center text-emerald-400 font-bold">✓</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                      <td className="p-3 text-center text-rose-500 font-bold">✗</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>

        </div>
      )}

      {/* Subtab 2: Visitor Query & Document Upload Approvals */}
      {activeSubTab === 'requests' && (
        <div className="space-y-4">
          
          {/* Header & Filter Controls */}
          <div className="p-4 sm:p-5 rounded-3xl bg-slate-850 border border-slate-700 space-y-3 shadow">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <FileCheck2 className="w-5 h-5 text-emerald-400" />
                  <span>
                    {isBn ? 'ইউজার ও ভিজিটর অনুরোধ এবং ফাইল অনুমোদন' : 'User Requests & Document Approvals'}
                  </span>
                  {pendingRequests.length > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-xs font-black animate-pulse">
                      {pendingRequests.length} {isBn ? 'পেন্ডিং' : 'Pending'}
                    </span>
                  )}
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn 
                    ? 'আত্মীয় ও ভিজিটরদের প্রেরিত সকল ফাইল ও আবেদন মারুফ ভাইয়ের ডিজিটাল অনুমোদন ছাড়া কার্যকর হবে না।' 
                    : 'All user submissions remain in quarantine until digitally approved by Admin Maruf.'}
                </p>
              </div>

              {/* Status Filter Pills */}
              <div className="flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-750 text-xs">
                {(['all', 'pending', 'approved', 'rejected'] as const).map((st) => (
                  <button
                    key={st}
                    onClick={() => setRequestFilter(st)}
                    className={`px-3 py-1.5 rounded-xl font-semibold capitalize transition ${
                      requestFilter === st
                        ? 'bg-emerald-600 text-white shadow'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {st === 'all' ? (isBn ? 'সকল' : 'All')
                      : st === 'pending' ? (isBn ? 'পেন্ডিং' : 'Pending')
                      : st === 'approved' ? (isBn ? 'অনুমোদিত' : 'Approved')
                      : (isBn ? 'প্রত্যাখ্যাত' : 'Rejected')}
                  </button>
                ))}
              </div>
            </div>

            {/* Search filter */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={requestSearch}
                onChange={(e) => setRequestSearch(e.target.value)}
                placeholder={isBn ? 'আবেদনকারী, শিরোনাম বা ফোন নম্বর দিয়ে খুঁজুন...' : 'Search applicant name, title or phone...'}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-750 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Requests List */}
          {requests
            .filter((r) => {
              const matchesSt = requestFilter === 'all' || r.status === requestFilter;
              const q = requestSearch.toLowerCase().trim();
              const matchesQ = !q || r.submitterName.toLowerCase().includes(q) || r.title.toLowerCase().includes(q) || r.submitterPhone.includes(q);
              return matchesSt && matchesQ;
            })
            .length > 0 ? (
            <div className="space-y-3">
              {requests
                .filter((r) => {
                  const matchesSt = requestFilter === 'all' || r.status === requestFilter;
                  const q = requestSearch.toLowerCase().trim();
                  const matchesQ = !q || r.submitterName.toLowerCase().includes(q) || r.title.toLowerCase().includes(q) || r.submitterPhone.includes(q);
                  return matchesSt && matchesQ;
                })
                .map((req) => (
                <div
                  key={req.id}
                  className={`p-5 rounded-3xl border transition-all duration-300 shadow space-y-3.5 ${
                    req.status === 'pending'
                      ? 'bg-slate-850 border-amber-500/50 shadow-amber-950/20'
                      : req.status === 'approved'
                      ? 'bg-slate-850/80 border-emerald-500/40 opacity-90'
                      : 'bg-slate-850/60 border-rose-500/30 opacity-75'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className={`text-[10px] font-bold px-2.5 py-0.5 rounded-full border ${
                        req.status === 'pending'
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/30'
                          : req.status === 'approved'
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          : 'bg-rose-500/20 text-rose-300 border-rose-500/30'
                      }`}>
                        {req.status === 'pending' ? (isBn ? 'অপেক্ষমাণ' : 'Pending')
                          : req.status === 'approved' ? (isBn ? '✓ অনুমোদিত' : 'Approved')
                          : (isBn ? '✗ প্রত্যাখ্যাত' : 'Rejected')}
                      </span>

                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700">
                        {req.requestType === 'document_upload' ? (isBn ? '📁 দলিল আপলোড' : 'Document Upload')
                          : req.requestType === 'role_upgrade' ? (isBn ? '🛡️ রোল আপগ্রেড' : 'Role Upgrade')
                          : req.requestType === 'vault_unlock' ? (isBn ? '🔓 ভল্ট আনলক' : 'Vault Unlock')
                          : (isBn ? '✏️ তথ্য সংশোধন' : 'Info Update')}
                      </span>

                      {req.urgency === 'critical' && (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 animate-pulse">
                          {isBn ? 'জরুরি (Critical)' : 'Critical'}
                        </span>
                      )}
                    </div>

                    <span className="text-[11px] text-slate-400 font-mono">{req.submittedAt}</span>
                  </div>

                  <div>
                    <h4 className="font-bold text-sm sm:text-base text-white">{req.title}</h4>
                    <p className="text-xs text-slate-300 mt-0.5">
                      {isBn ? 'আবেদনকারী:' : 'Submitter:'} <span className="font-semibold text-white">{req.submitterName}</span> ({req.submitterPhone}) • <span className="text-slate-400">{req.relationClaimBn}</span>
                      {req.submitterEmail && <span className="text-slate-400 font-mono ml-1">({req.submitterEmail})</span>}
                    </p>
                  </div>

                  <p className="text-xs text-slate-200 bg-slate-900/80 p-3.5 rounded-2xl border border-slate-800 leading-relaxed">
                    "{req.description}"
                  </p>

                  {/* Attached File Preview if present (Supports all formats) */}
                  {req.fileAttachmentName && (
                    <div className="p-3 rounded-2xl bg-slate-900 border border-slate-750 flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <Paperclip className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div>
                          <p className="font-bold text-white text-xs">{req.fileAttachmentName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{req.fileAttachmentSize || 'All Format Support'}</p>
                        </div>
                      </div>

                      {req.fileAttachmentDataUrl && (
                        <a
                          href={req.fileAttachmentDataUrl}
                          download={req.fileAttachmentName}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white transition text-xs font-semibold"
                        >
                          <Download className="w-3.5 h-3.5" />
                          <span>{isBn ? 'সংযুক্তি ডাউনলোড' : 'Download File'}</span>
                        </a>
                      )}
                    </div>
                  )}

                  {/* Action Buttons for Pending Requests */}
                  {req.status === 'pending' && (
                    <div className="flex items-center justify-end gap-2 pt-1 border-t border-slate-750">
                      <button
                        onClick={() => onRejectRequest(req.id)}
                        className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-800 hover:bg-rose-950 text-rose-300 border border-slate-700 hover:border-rose-700 text-xs font-semibold transition"
                      >
                        <X className="w-3.5 h-3.5" />
                        <span>{isBn ? 'প্রত্যাখ্যান করুন' : 'Reject'}</span>
                      </button>

                      <button
                        onClick={() => onApproveRequest(req.id)}
                        className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/40 transition hover:scale-[1.02]"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isBn ? 'অনুমোদন দিন ও কার্যকর করুন' : 'Approve & Publish'}</span>
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <div className="p-8 rounded-3xl bg-slate-850 border border-dashed border-slate-700 text-center space-y-2">
              <Check className="w-8 h-8 text-emerald-400 mx-auto" />
              <p className="text-xs text-slate-300 font-semibold">
                {isBn ? 'এই ফিল্টারে কোনো আবেদন পাওয়া যায়নি।' : 'No approval requests found in this filter.'}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Subtab: Firebase Manual Email Login Configurations */}
      {activeSubTab === 'firebase_auth' && (
        <div className="space-y-6">
          
          {/* Header Banner */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-amber-950/80 via-slate-900 to-orange-950/80 border border-amber-500/40 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-semibold">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'ফায়ারবেস ইমেইল লগইন ও অ্যাক্সেস কনফিগারেশন' : 'Firebase Email Login & Access Configuration'}</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  {isBn ? 'অনুমোদিত ইমেইল তালিকা ও লগইন পারমিশন ব্যবস্থাপনা' : 'Authorized Login Emails & RBAC Permissions'}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                  {isBn 
                    ? 'মারুফ মাস্টার অ্যাডমিন হিসেবে আপনি যেকোনো ব্যক্তির ইমেইল যুক্ত, ভূমিকা নির্ধারণ, সক্রিয়/নিষ্ক্রিয় অথবা মুছে ফেলতে পারেন। অনুমোদিত ইমেইলগুলো ফায়ারবেস অথেন্টিকেশনে স্বয়ংক্রিয়ভাবে নির্ধারিত ভূমিকা লাভ করবে।' 
                    : 'Configure authorized email accounts for Firebase Authentication. Assign custom RBAC roles, toggle access, and manage strict login restrictions.'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleOpenAddEmailModal()}
                  className="px-4 py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-lg shadow-amber-950/40 transition flex items-center gap-1.5"
                >
                  <UserPlus className="w-4 h-4" />
                  <span>{isBn ? 'নতুন ইমেইল যোগ করুন' : 'Add Login Email'}</span>
                </button>
              </div>
            </div>

            {/* Quick Metrics Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-amber-500/20 text-xs">
              <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{isBn ? 'মোট কনফিগার করা ইমেইল:' : 'Total Configured Emails:'}</span>
                <span className="text-base font-bold text-white font-mono">{allowedEmailsList.length} {isBn ? 'টি' : 'accounts'}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{isBn ? 'মাস্টার অ্যাডমিন একাউন্ট:' : 'Master Admin Accounts:'}</span>
                <span className="text-base font-bold text-amber-300 font-mono">
                  {allowedEmailsList.filter((e) => e.role === 'Admin').length} {isBn ? 'টি' : 'Admins'}
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{isBn ? 'লগইন গেটকিপার মোড:' : 'Gatekeeper Security:'}</span>
                <span className={`text-xs font-bold font-mono ${strictLoginMode ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {strictLoginMode ? (isBn ? 'কঠোর মোড (Strict)' : 'Strict Mode') : (isBn ? 'উন্মুক্ত (Open)' : 'Open Access')}
                </span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-950/60 border border-slate-800">
                <span className="text-slate-400 text-[10px] block">{isBn ? 'ফায়ারস্টোর কানেকশন:' : 'Firestore Sync:'}</span>
                <span className="text-xs font-bold text-emerald-400 flex items-center gap-1 font-mono">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সংযুক্ত ও সক্রিয়' : 'Connected'}</span>
                </span>
              </div>
            </div>
          </div>

          {/* Master 4 Gmail Accounts Highlights */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-700/60 pb-3">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Flame className="w-4 h-4 text-amber-400" />
                  <span>{isBn ? 'মারুফের অনুমোদিত মূল ৪টি জিমেইল মাস্টার অ্যাকাউন্ট' : 'Designated 4 Master Admin Gmail Accounts'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn ? 'এই অ্যাকাউন্টগুলো দিয়ে লগইন করলে সিস্টেম স্বয়ংক্রিয়ভাবে ফুল অ্যাডমিন প্রিভিলেজ প্রদান করে।' : 'These 4 primary emails have full administrative control.'}
                </p>
              </div>
              <button
                type="button"
                onClick={handleTestFirebaseConnection}
                disabled={isTestingFirebase}
                className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-bold flex items-center gap-1.5 transition"
              >
                {isTestingFirebase ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CheckCheck className="w-3.5 h-3.5 text-amber-400" />}
                <span>{isBn ? 'কানেকশন টেস্ট' : 'Test Connection'}</span>
              </button>
            </div>

            {firebaseTestResult && (
              <div className="p-3 rounded-2xl bg-slate-900 border border-emerald-500/40 text-xs font-mono text-emerald-300">
                {firebaseTestResult}
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {AUTHORIZED_ADMIN_EMAILS.map((email, idx) => {
                const conf = allowedEmailsList.find((e) => e.email.toLowerCase() === email.toLowerCase());
                return (
                  <div
                    key={email}
                    className="p-3.5 rounded-2xl bg-slate-900/90 border border-amber-500/30 flex items-center justify-between gap-3 text-xs"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center font-bold text-xs shrink-0">
                        {idx + 1}
                      </div>
                      <div className="min-w-0">
                        <span className="font-mono font-bold text-white block truncate">{email}</span>
                        <span className="text-[10px] text-slate-400 block truncate">
                          {conf?.displayName || 'মারুফ মাস্টার অ্যাডমিন'}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-black">
                        Master Admin
                      </span>
                      <button
                        type="button"
                        onClick={() => handleCopyText(email, `email_${idx}`)}
                        className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-400 hover:text-white"
                        title="Copy Email"
                      >
                        {copiedKey === `email_${idx}` ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Full Allowed Emails List & Controls */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-4">
            
            {/* Filter and Mode Bar */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 border-b border-slate-700/60 pb-4">
              <div className="flex items-center gap-3">
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Users className="w-4 h-4 text-emerald-400" />
                  <span>{isBn ? 'সকল অনুমোদিত ইমেইল তালিকা' : 'All Authorized Login Emails'}</span>
                </h4>
                <span className="text-xs text-slate-400">({allowedEmailsList.length})</span>
              </div>

              {/* Strict Mode Gatekeeper Toggle */}
              <div className="flex items-center gap-3 p-2 rounded-2xl bg-slate-900 border border-slate-750">
                <div className="text-right">
                  <span className="text-xs font-bold text-white block">
                    {isBn ? 'কঠোর মোড (Strict Login)' : 'Strict Login Gatekeeper'}
                  </span>
                  <span className="text-[10px] text-slate-400 block">
                    {strictLoginMode 
                      ? (isBn ? 'শুধুমাত্র তালিকার ইমেইলগুলো লগইন করতে পারবে' : 'Only listed emails can login') 
                      : (isBn ? 'অন্যান্যরা ভিউয়ার হিসেবে ঢুকতে পারবে' : 'Open access as Viewer')}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    const newVal = !strictLoginMode;
                    setStrictLoginMode(newVal);
                    handleSaveSystemSettings({ strictLoginMode: newVal });
                  }}
                  className={`p-1.5 rounded-xl border transition ${
                    strictLoginMode 
                      ? 'bg-rose-600 text-white border-rose-500' 
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                >
                  {strictLoginMode ? <ToggleRight className="w-6 h-6" /> : <ToggleLeft className="w-6 h-6" />}
                </button>
              </div>
            </div>

            {/* Search Box */}
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={emailSearchQuery}
                onChange={(e) => setEmailSearchQuery(e.target.value)}
                placeholder={isBn ? 'ইমেইল বা নাম দিয়ে খুঁজুন...' : 'Search by email or name...'}
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white text-xs outline-none focus:ring-2 focus:ring-amber-500"
              />
            </div>

            {/* Emails Table / Cards */}
            <div className="space-y-2.5">
              {allowedEmailsList
                .filter((item) => {
                  const q = emailSearchQuery.toLowerCase().trim();
                  return !q || item.email.toLowerCase().includes(q) || item.displayName.toLowerCase().includes(q);
                })
                .map((item) => {
                  const isPrimary = item.isMasterAccount && item.email.toLowerCase() === 'habiburmaruf@gmail.com';

                  return (
                    <div
                      key={item.id}
                      className={`p-4 rounded-2xl border transition flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 ${
                        item.isActive
                          ? 'bg-slate-900/80 border-slate-750 hover:border-slate-650'
                          : 'bg-slate-900/40 border-slate-800 opacity-60'
                      }`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-xs shrink-0 ${
                          item.role === 'Admin' ? 'bg-amber-500/20 text-amber-300' : item.role === 'Editor' ? 'bg-blue-500/20 text-blue-300' : 'bg-slate-800 text-slate-300'
                        }`}>
                          <AtSign className="w-5 h-5" />
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-mono font-bold text-white text-xs">{item.email}</span>
                            <span className={`px-2 py-0.2 rounded-full text-[10px] font-bold border ${roleBadgeStyles[item.role].bg} ${roleBadgeStyles[item.role].text} ${roleBadgeStyles[item.role].border}`}>
                              {item.role}
                            </span>
                            {item.isMasterAccount && (
                              <span className="px-1.5 py-0.2 rounded bg-amber-400/20 text-amber-300 text-[9px] font-bold">
                                Master
                              </span>
                            )}
                            {!item.isActive && (
                              <span className="px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 text-[9px] font-bold">
                                Disabled
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5 truncate">
                            {item.displayName} {item.notes ? `• ${item.notes}` : ''} • {item.addedAt}
                          </p>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex items-center gap-2 self-end sm:self-center shrink-0">
                        {/* Role Selector */}
                        <select
                          value={item.role}
                          onChange={(e) => {
                            const newRole = e.target.value as UserRole;
                            const updated = allowedEmailsList.map((x) => x.id === item.id ? { ...x, role: newRole } : x);
                            setAllowedEmailsList(updated);
                            handleSaveSystemSettings({ allowedEmails: updated });
                          }}
                          disabled={isPrimary}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-xs font-semibold text-white outline-none"
                        >
                          <option value="Admin">Admin</option>
                          <option value="Editor">Editor</option>
                          <option value="Viewer">Viewer</option>
                        </select>

                        {/* Active Toggle */}
                        <button
                          type="button"
                          onClick={() => handleToggleEmailActive(item.id)}
                          className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition ${
                            item.isActive 
                              ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/60 hover:bg-emerald-900' 
                              : 'bg-slate-800 text-slate-400 border-slate-700 hover:text-white'
                          }`}
                        >
                          {item.isActive ? (isBn ? 'সক্রিয়' : 'Active') : (isBn ? 'নিষ্ক্রিয়' : 'Inactive')}
                        </button>

                        {/* Edit Button */}
                        <button
                          type="button"
                          onClick={() => handleOpenAddEmailModal(item)}
                          className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 transition"
                          title="Edit"
                        >
                          <Edit3 className="w-3.5 h-3.5" />
                        </button>

                        {/* Delete Button */}
                        {!item.isMasterAccount && (
                          <button
                            type="button"
                            onClick={() => handleDeleteEmailConfig(item.id)}
                            className="p-1.5 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 transition"
                            title="Delete"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>

          {/* Interactive Tools: Email Permission Tester & Password Reset Sender */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Tool 1: Login Authorization Tester */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-slate-700 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'ইমেইল পারমিশন সিমুলেটর (Login Permission Tester)' : 'Login Permission Tester'}</span>
              </h4>
              <p className="text-[11px] text-slate-400">
                {isBn ? 'যেকোনো ইমেইল লিখে পরীক্ষা করুন এটি সিস্টেমে প্রবেশাধিকার পাবে কিনা এবং কোন ভূমিকা লাভ করবে।' : 'Test whether an email qualifies for access and what role it receives.'}
              </p>
              
              <div className="flex gap-2">
                <input
                  type="email"
                  value={testLoginEmail}
                  onChange={(e) => setTestLoginEmail(e.target.value)}
                  placeholder="name@gmail.com"
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-750 text-white font-mono text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                />
                <button
                  type="button"
                  onClick={handleTestLoginCheck}
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition"
                >
                  {isBn ? 'যাচাই করুন' : 'Test Check'}
                </button>
              </div>

              {testLoginResult && (
                <div className={`p-3 rounded-xl border text-xs font-semibold ${
                  testLoginResult.allowed 
                    ? 'bg-emerald-950/60 border-emerald-500/40 text-emerald-300' 
                    : 'bg-rose-950/60 border-rose-500/40 text-rose-300'
                }`}>
                  {testLoginResult.message}
                </div>
              )}
            </div>

            {/* Tool 2: Manual Password Reset Sender */}
            <div className="p-5 rounded-3xl bg-slate-850 border border-slate-700 space-y-3">
              <h4 className="text-xs font-bold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-amber-400" />
                <span>{isBn ? 'ম্যানুয়াল পাসওয়ার্ড রিসেট লিংক পাঠান' : 'Send Password Reset Email'}</span>
              </h4>
              <p className="text-[11px] text-slate-400">
                {isBn ? 'ব্যবহারকারী পাসওয়ার্ড ভুলে গেলে ফায়ারবেস পাসওয়ার্ড রিসেট ইমেইল ট্রিগার করুন।' : 'Trigger a Firebase password reset email to any user.'}
              </p>
              
              <div className="flex gap-2">
                <input
                  type="email"
                  value={passwordResetEmail}
                  onChange={(e) => setPasswordResetEmail(e.target.value)}
                  placeholder="habiburmaruf@gmail.com"
                  className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-750 text-white font-mono text-xs outline-none focus:ring-2 focus:ring-amber-500"
                />
                <button
                  type="button"
                  onClick={handleSendResetEmail}
                  disabled={isSendingReset}
                  className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center gap-1.5"
                >
                  {isSendingReset ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  <span>{isBn ? 'পাঠান' : 'Send'}</span>
                </button>
              </div>

              {passwordResetFeedback && (
                <div className="p-3 rounded-xl bg-slate-900 border border-amber-500/40 text-xs font-mono text-amber-300">
                  {passwordResetFeedback}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* Subtab: AI Thinking & Reasoning Engine Studio ("all thinking are editeble") */}
      {activeSubTab === 'ai_thinking' && (
        <div className="space-y-6">
          
          {/* Header Banner */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-purple-950/80 via-slate-900 to-indigo-950/80 border border-purple-500/40 shadow-xl space-y-3">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div className="space-y-1">
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/40 text-xs font-semibold">
                  <BrainCircuit className="w-4 h-4 text-purple-400" />
                  <span>{isBn ? 'এআই থিংকিং ও চিন্তাধারা স্টুডিও (All Thinking are Editable)' : 'AI Thinking & Reasoning Engine Studio'}</span>
                </div>
                <h3 className="text-xl sm:text-2xl font-black text-white">
                  {isBn ? 'সকল কৃত্রিম বুদ্ধিমত্তা চিন্তাধারা ও নির্দেশিকা সম্পাদনা' : 'Editable AI Reasoning Directives & Chain-of-Thought'}
                </h3>
                <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                  {isBn 
                    ? 'মারুফ মাস্টার অ্যাডমিন হিসেবে আপনি এআই-এর চিন্তার নিয়মাবলি, ফারায়েয গণিতের যুক্তি, ভূমি জরিপ খতিয়ান যাচাই এবং জাল দলিল সনাক্তকরণের প্রতিটি চিন্তাধারা নিজের ইচ্ছামতো সম্পাদনা ও সেভ করতে পারেন।' 
                    : 'Full editorial control over AI reasoning instructions, Farayez inheritance logic, land title chain audits, and document fraud verification rules.'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleResetThinkingDefaults}
                  className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700 text-xs font-bold transition flex items-center gap-1.5"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ডিফল্ট পুনরুদ্ধার' : 'Reset Defaults'}</span>
                </button>

                <button
                  type="button"
                  onClick={handleSaveThinkingPrompts}
                  className="px-5 py-2 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-950/40 transition flex items-center gap-1.5 hover:scale-[1.02]"
                >
                  <Check className="w-4 h-4" />
                  <span>{isBn ? 'সকল চিন্তাধারা সেভ করুন' : 'Save All Thinking'}</span>
                </button>
              </div>
            </div>

            {/* Thinking Modules Sub-Selector */}
            <div className="flex flex-wrap gap-2 pt-2 border-t border-purple-500/20">
              {[
                { id: 'system', labelBn: 'সার্বিক সিস্টেম চিন্তাধারা', labelEn: 'System Directive', icon: BrainCircuit },
                { id: 'farayez', labelBn: 'ফারায়েয গণিত চিন্তাধারা', labelEn: 'Farayez Inheritance CoT', icon: Sparkles },
                { id: 'land', labelBn: 'ই-নামজারি ও রেকর্ড চেইন', labelEn: 'Land Title Chain', icon: BookOpen },
                { id: 'deed', labelBn: 'দলিল সত্যতা ও জালিয়াতি অডিট', labelEn: 'Deed Fraud Audit', icon: ShieldCheck },
                { id: 'params', labelBn: 'মডেল ও থিংকিং বাজেট', labelEn: 'Parameters & Budget', icon: Sliders },
              ].map((tab) => {
                const Icon = tab.icon;
                const isActive = activeThinkingTab === tab.id;
                return (
                  <button
                    type="button"
                    key={tab.id}
                    onClick={() => setActiveThinkingTab(tab.id as any)}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                      isActive 
                        ? 'bg-purple-500 text-white shadow' 
                        : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 border border-slate-750'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    <span>{isBn ? tab.labelBn : tab.labelEn}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Thinking Prompt Editor Box */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-4">
            
            {/* Tab 1: System Prompt Thinking */}
            {activeThinkingTab === 'system' && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isBn ? 'সার্বিক এআই পরামর্শদাতা সিস্টেম চিন্তাধারা (System Reasoning Protocol)' : 'Master System Reasoning Protocol'}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {isBn ? 'প্রতিটি উত্তরের পেছনে এআই কীভাবে চিন্তা ও বিবেচনা করবে তার মূল নির্দেশিকা।' : 'Core chain-of-thought directives governing all AI decisions.'}
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-purple-400 font-semibold">
                    {aiThinking.systemPromptThinking.length} chars
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={aiThinking.systemPromptThinking}
                  onChange={(e) => handleUpdateThinkingField('systemPromptThinking', e.target.value)}
                  className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
            )}

            {/* Tab 2: Farayez Thinking */}
            {activeThinkingTab === 'farayez' && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isBn ? 'ফারায়েয ও উত্তরাধিকার গণিত চিন্তাধারা (Farayez Chain-of-Thought)' : 'Farayez Inheritance Calculation Thinking'}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {isBn ? 'ইসলামি উত্তরাধিকার আইন ও পবিত্র কুরআনের আয়াতের আলোকে ধাপে ধাপে হিস্যা বিশ্লেষণের চিন্তাধারা।' : 'Step-by-step mathematical division principles according to Islamic & Bangladesh law.'}
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-purple-400 font-semibold">
                    {aiThinking.farayezThinkingPrompt.length} chars
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={aiThinking.farayezThinkingPrompt}
                  onChange={(e) => handleUpdateThinkingField('farayezThinkingPrompt', e.target.value)}
                  className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
            )}

            {/* Tab 3: Land Mutation Thinking */}
            {activeThinkingTab === 'land' && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isBn ? 'ভূমি জরিপ ও খতিয়ান চেইন চিন্তাধারা (Land Mutation & Title Protocol)' : 'Land Records & Mutation Chain-of-Title Thinking'}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {isBn ? 'সিএস, এসএ, আরএস, বিএস জরিপ ও নামজারি খতিয়ানের ধারাবাহিক স্বত্ব মেলানোর চিন্তাধারা।' : 'Verification workflow across CS, SA, RS, BS khatians and mutation chains.'}
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-purple-400 font-semibold">
                    {aiThinking.landMutationThinkingPrompt.length} chars
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={aiThinking.landMutationThinkingPrompt}
                  onChange={(e) => handleUpdateThinkingField('landMutationThinkingPrompt', e.target.value)}
                  className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
            )}

            {/* Tab 4: Deed Verification Thinking */}
            {activeThinkingTab === 'deed' && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <div>
                    <h4 className="text-sm font-bold text-white">
                      {isBn ? 'দলিল সত্যতা ও জালিয়াতি নিরীক্ষা চিন্তাধারা (Deed Fraud Audit)' : 'Deed Authenticity & Fraud Audit Protocol'}
                    </h4>
                    <p className="text-xs text-slate-400">
                      {isBn ? 'ভলিউম নম্বর, বায়া দলিল, সাব-রেজিস্ট্রি সিল ও স্ট্যাম্প মেলানোর চিন্তাধারা।' : 'Authenticity verification heuristics for registration seals, stamp duties, and chain deeds.'}
                    </p>
                  </div>
                  <span className="text-[11px] font-mono text-purple-400 font-semibold">
                    {aiThinking.deedVerificationThinkingPrompt.length} chars
                  </span>
                </div>

                <textarea
                  rows={8}
                  value={aiThinking.deedVerificationThinkingPrompt}
                  onChange={(e) => handleUpdateThinkingField('deedVerificationThinkingPrompt', e.target.value)}
                  className="w-full p-4 rounded-2xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm leading-relaxed focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
            )}

            {/* Tab 5: Model Parameters & Budget */}
            {activeThinkingTab === 'params' && (
              <div className="space-y-5">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  
                  {/* Temperature Slider */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <div className="flex justify-between text-xs">
                      <span className="font-semibold text-slate-300">{isBn ? 'টেম্পারেচার (Temperature):' : 'Temperature:'}</span>
                      <span className="font-mono text-purple-400 font-bold">{aiThinking.temperature}</span>
                    </div>
                    <input
                      type="range"
                      min="0.1"
                      max="0.9"
                      step="0.05"
                      value={aiThinking.temperature}
                      onChange={(e) => handleUpdateThinkingField('temperature', parseFloat(e.target.value))}
                      className="w-full accent-purple-500 cursor-pointer"
                    />
                    <p className="text-[10px] text-slate-400">
                      {aiThinking.temperature <= 0.3 ? (isBn ? 'কঠোর আইনি যথার্থতা (Strict Precision)' : 'Strict Legal Precision') : (isBn ? 'সৃজনশীল পরামর্শ (Creative Advice)' : 'Creative Exploration')}
                    </p>
                  </div>

                  {/* Thinking Token Budget */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <span className="font-semibold text-slate-300 text-xs block">{isBn ? 'থিংকিং টোকেন বাজেট:' : 'Thinking Token Budget:'}</span>
                    <select
                      value={aiThinking.thinkingBudget}
                      onChange={(e) => handleUpdateThinkingField('thinkingBudget', parseInt(e.target.value))}
                      className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs outline-none"
                    >
                      <option value={512}>512 Tokens ({isBn ? 'দ্রুত প্রতিক্রিয়া' : 'Fast Response'})</option>
                      <option value={1024}>1024 Tokens ({isBn ? 'ভারসাম্যপূর্ণ গভীর চিন্তা' : 'Balanced Deep CoT'})</option>
                      <option value={2048}>2048 Tokens ({isBn ? 'সর্বোচ্চ আইনি গবেষণা' : 'Maximum Legal Research'})</option>
                    </select>
                    <p className="text-[10px] text-slate-400">
                      {isBn ? 'জটিল ওয়ারিশি হিসাবের জন্য ১০২৪ বা ২০৪৮ প্রস্তাবিত।' : '1024 or 2048 recommended for complex Farayez.'}
                    </p>
                  </div>

                  {/* Language Mode */}
                  <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                    <span className="font-semibold text-slate-300 text-xs block">{isBn ? 'আউটপুট ভাষা মোড:' : 'Output Language:'}</span>
                    <select
                      value={aiThinking.responseLanguage}
                      onChange={(e) => handleUpdateThinkingField('responseLanguage', e.target.value as any)}
                      className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs outline-none"
                    >
                      <option value="bn">বাংলা (Bengali First)</option>
                      <option value="en">English (ইংরেজি)</option>
                      <option value="bilingual">দ্বৈতভাষিক (Bilingual BN + EN)</option>
                    </select>
                    <p className="text-[10px] text-slate-400">
                      {isBn ? 'পারিবারিক সদস্যদের সুবিধার জন্য বাংলা ডিফল্ট।' : 'Bengali default for family clarity.'}
                    </p>
                  </div>

                </div>

                {/* Show CoT Toggle */}
                <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-white">
                      {isBn ? 'ইউজারের স্ক্রিনে চিন্তার ধাপসমূহ প্রদর্শন (Show Step-by-Step CoT in UI)' : 'Show Reasoning Steps in UI'}
                    </h5>
                    <p className="text-[11px] text-slate-400">
                      {isBn ? 'চালু থাকলে উত্তর দেওয়ার আগে এআই কীভাবে ভেবেছে তা ধাপে ধাপে দেখা যাবে।' : 'Display the step-by-step thinking process before the final verdict.'}
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleUpdateThinkingField('showCoTInUi', !aiThinking.showCoTInUi)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
                      aiThinking.showCoTInUi ? 'bg-purple-600 text-white border-purple-500' : 'bg-slate-800 text-slate-400 border-slate-700'
                    }`}
                  >
                    {aiThinking.showCoTInUi ? (isBn ? 'প্রদর্শন চালু' : 'Visible') : (isBn ? 'লুকানো' : 'Hidden')}
                  </button>
                </div>

              </div>
            )}

            {/* Save Buttons Bar */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                {isBn ? '💡 যেকোনো পরিবর্তন তাৎক্ষণিকভাবে এআই ল্যাব ও লিগ্যাল অ্যাসিস্ট্যান্টে কার্যকর হবে।' : '💡 Changes apply immediately to AI Lab and Legal Assistant.'}
              </span>
              <button
                type="button"
                onClick={handleSaveThinkingPrompts}
                className="px-5 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold shadow-lg shadow-purple-950/40 transition flex items-center gap-1.5"
              >
                <Check className="w-4 h-4" />
                <span>{isBn ? 'পরিবর্তন সেভ করুন' : 'Save Changes'}</span>
              </button>
            </div>

          </div>

          {/* Interactive Live Thinking Test Sandbox */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-4">
            <div className="flex items-center gap-2 border-b border-slate-700/60 pb-3">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h4 className="text-sm font-bold text-white">
                {isBn ? 'লাইভ থিংকিং টেস্ট স্যান্ডবক্স (Interactive Thinking Sandbox)' : 'Live Thinking Sandbox'}
              </h4>
            </div>
            <p className="text-xs text-slate-400">
              {isBn ? 'আপনার সম্পাদিত চিন্তাধারা অনুযায়ী এআই কীভাবে ভাবছে তা এখনই টেস্ট করুন।' : 'Test how the AI reasons using your newly edited thinking protocol.'}
            </p>

            <div className="flex gap-2">
              <input
                type="text"
                value={testThinkingInput}
                onChange={(e) => setTestThinkingInput(e.target.value)}
                placeholder="একটি আইনি বা ফারায়েয প্রশ্ন লিখুন..."
                className="flex-1 px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white text-xs outline-none focus:ring-2 focus:ring-purple-500"
              />
              <button
                type="button"
                onClick={handleSimulateThinking}
                disabled={isSimulatingThinking}
                className="px-5 py-2.5 rounded-2xl bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-xs font-bold transition flex items-center gap-2 shadow"
              >
                {isSimulatingThinking ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>{isBn ? 'চিন্তা করছে...' : 'Thinking...'}</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 fill-white" />
                    <span>{isBn ? 'থিংকিং রান করুন' : 'Run Thinking'}</span>
                  </>
                )}
              </button>
            </div>

            {testThinkingOutput && (
              <div className="p-4 rounded-2xl bg-slate-950 border border-purple-500/40 space-y-3 animate-fade-in">
                
                {/* Step-by-step reasoning steps */}
                <div className="space-y-1.5">
                  <span className="text-[11px] font-bold text-purple-300 uppercase tracking-wider flex items-center gap-1.5">
                    <BrainCircuit className="w-3.5 h-3.5" />
                    <span>{isBn ? 'এআই চিন্তার ধাপসমূহ (Chain-of-Thought Reasoning):' : 'Chain-of-Thought Reasoning Steps:'}</span>
                  </span>
                  <div className="space-y-1 pl-2 border-l-2 border-purple-500/50">
                    {testThinkingOutput.reasoning.map((step, idx) => (
                      <p key={idx} className="text-xs text-slate-300 font-mono leading-relaxed">
                        {step}
                      </p>
                    ))}
                  </div>
                </div>

                {/* Final Verdict */}
                <div className="pt-2 border-t border-slate-800">
                  <span className="text-[11px] font-bold text-emerald-400 block mb-1">
                    {isBn ? 'চূড়ান্ত সিদ্ধান্ত ও পরামর্শ:' : 'Final Advice & Verdict:'}
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed font-semibold">
                    {testThinkingOutput.verdict}
                  </p>
                </div>

              </div>
            )}

          </div>

        </div>
      )}

      {/* Modal: Add or Edit Allowed Email Configuration */}
      {isAddEmailModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-md rounded-3xl bg-slate-900 border border-slate-700/80 p-6 space-y-4 shadow-2xl relative">
            <button
              onClick={() => setIsAddEmailModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="space-y-1">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-amber-400" />
                <span>{editingEmailId ? (isBn ? 'ইমেইল পারমিশন সম্পাদনা' : 'Edit Email Permission') : (isBn ? 'নতুন অনুমোদিত ইমেইল যুক্ত করুন' : 'Add Authorized Email')}</span>
              </h3>
              <p className="text-xs text-slate-400">
                {isBn ? 'এই ইমেইলটি ফায়ারবেস লগইনে নির্ধারিত ভূমিকা লাভ করবে।' : 'This email will receive the designated role in Firebase Auth.'}
              </p>
            </div>

            <form onSubmit={handleSaveEmailConfig} className="space-y-3.5">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ইমেইল ঠিকানা (Email Address)' : 'Email Address'} *
                </label>
                <input
                  type="email"
                  value={emailFormInput}
                  onChange={(e) => setEmailFormInput(e.target.value)}
                  placeholder="relative@gmail.com"
                  required
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white font-mono text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'প্রদর্শন নাম বা পরিচিতি (Display Name)' : 'Display Name / Identity'}
                </label>
                <input
                  type="text"
                  value={displayNameFormInput}
                  onChange={(e) => setDisplayNameFormInput(e.target.value)}
                  placeholder={isBn ? 'যেমন: ফারুক ভাই / অ্যাডভোকেট রহমান' : 'e.g. Faruque Bhai'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'নির্ধারিত সিস্টেম ভূমিকা (RBAC Role)' : 'Assigned Role'}
                </label>
                <select
                  value={roleFormInput}
                  onChange={(e) => setRoleFormInput(e.target.value as UserRole)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs font-bold outline-none"
                >
                  <option value="Admin">Admin (পূর্ণ নিয়ন্ত্রণাধিকার)</option>
                  <option value="Editor">Editor (দলিল ও সদস্য তথ্য যোগ/সম্পাদনা)</option>
                  <option value="Viewer">Viewer (শুধুমাত্র প্রদর্শন)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'মন্তব্য বা উদ্দেশ্য (Notes)' : 'Notes'}
                </label>
                <input
                  type="text"
                  value={notesFormInput}
                  onChange={(e) => setNotesFormInput(e.target.value)}
                  placeholder={isBn ? 'যেমন: পারিবারিক আইনজীবী / ভূমির সার্ভেয়ার' : 'e.g. Legal advisor'}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddEmailModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-750"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold shadow-lg shadow-amber-950/40"
                >
                  {editingEmailId ? (isBn ? 'আপডেট করুন' : 'Update') : (isBn ? 'সংরক্ষণ করুন' : 'Save Email')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Subtab: System Settings & Web Status (ALL OPTIONAL) */}
      {activeSubTab === 'system_settings' && (
        <div className="space-y-6">
          
          {/* Important Optional Disclaimer Banner */}
          <div className="p-5 rounded-3xl bg-gradient-to-r from-teal-950/80 via-slate-900 to-indigo-950/80 border border-teal-500/40 shadow-xl space-y-2">
            <div className="flex items-center gap-2 text-teal-300 font-bold text-xs uppercase tracking-wider">
              <ShieldCheck className="w-4 h-4 text-teal-400" />
              <span>{isBn ? 'সকল সেটিংস ও এপিআই কি ১০০% ঐচ্ছিক (All Settings Optional)' : 'All Settings & API Keys are 100% Optional'}</span>
            </div>
            <h3 className="text-base sm:text-lg font-extrabold text-white">
              {isBn ? 'সিস্টেম স্ট্যাটাস পরিবর্তন ও কাস্টম এপিআই কি ব্যবস্থাপনা' : 'System Status Changes & Optional API Keys'}
            </h3>
            <p className="text-xs text-slate-300 leading-relaxed">
              {isBn 
                ? 'এই ওয়েব অ্যাপ্লিকেশন ব্যবহারের জন্য কোনো এপিআই কি দেওয়া বাধ্যতামূলক নয়। ডিফল্টভাবে ব্যাকএন্ড সার্ভার বা ব্রাউজারের স্মার্ট এআই অফলাইন সিন্থেসিস স্বয়ংক্রিয়ভাবে কাজ করে। মারুফ মাস্টার অ্যাডমিন হিসেবে আপনি যে-কোনো সময় কি যুক্ত বা মুছে ফেলতে পারেন এবং ওয়েবের স্ট্যাটাস পরিবর্তন করতে পারেন।' 
                : 'No API keys are required to use this application. The built-in backend proxy and local fallbacks handle all features seamlessly.'}
            </p>
          </div>

          {/* Web App Status Controls (Live, Maintenance, Emergency Lockdown, Read-Only) */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-5">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 border-b border-slate-700/60 pb-3">
              <div>
                <h4 className="text-sm font-bold text-white flex items-center gap-2">
                  <Radio className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>{isBn ? 'ওয়েব অ্যাপ স্ট্যাটাস কন্ট্রোল (Live Status Changes)' : 'Web App Status Control'}</span>
                </h4>
                <p className="text-xs text-slate-400 mt-0.5">
                  {isBn ? 'বর্তমান স্ট্যাটাস অনুযায়ী ভিজিটর ও সাধারণ সদস্যদের জন্য ভল্ট নিয়ন্ত্রণ করুন।' : 'Control web application state and access permissions.'}
                </p>
              </div>

              {/* Current Active Status Badge */}
              <div className="flex items-center gap-2">
                <span className="text-xs text-slate-400 font-medium">{isBn ? 'বর্তমান অবস্থা:' : 'Current:'}</span>
                <span className={`px-3 py-1 rounded-full text-xs font-bold border ${
                  (settings.webStatus || 'live') === 'live'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                    : settings.webStatus === 'maintenance'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : settings.webStatus === 'lockdown'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                    : 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                }`}>
                  {(settings.webStatus || 'live') === 'live' ? (isBn ? '🟢 অনলাইন ও উন্মুক্ত' : '🟢 Live & Operational')
                    : settings.webStatus === 'maintenance' ? (isBn ? '🟡 রক্ষণাবেক্ষণ মোড' : '🟡 Maintenance Mode')
                    : settings.webStatus === 'lockdown' ? (isBn ? '🔴 জরুরি লকডাউন' : '🔴 Emergency Lockdown')
                    : (isBn ? '🔵 শুধুমাত্র পাঠযোগ্য' : '🔵 Read-Only Archive')}
                </span>
              </div>
            </div>

            {/* Status Change Selector Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              
              {/* Option 1: Live */}
              <div 
                onClick={() => handleWebStatusChange('live')}
                className={`p-4 rounded-2xl border cursor-pointer transition hover:scale-[1.02] ${
                  (settings.webStatus || 'live') === 'live'
                    ? 'bg-emerald-950/40 border-emerald-500 shadow-lg shadow-emerald-950/30'
                    : 'bg-slate-900 border-slate-750 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-emerald-400">সক্রিয় (Live)</span>
                  {(settings.webStatus || 'live') === 'live' && <CheckCircle2 className="w-4 h-4 text-emerald-400" />}
                </div>
                <h5 className="font-bold text-sm text-white mb-1">{isBn ? 'অনলাইন ও সক্রিয়' : 'Live & Active'}</h5>
                <p className="text-[11px] text-slate-400 leading-snug">
                  {isBn ? 'সকল ফিচার, ভল্ট আপলোড ও অডিট লগ পূর্ণাঙ্গভাবে সক্রিয় থাকবে।' : 'Normal operations for all family members.'}
                </p>
              </div>

              {/* Option 2: Maintenance */}
              <div 
                onClick={() => handleWebStatusChange('maintenance')}
                className={`p-4 rounded-2xl border cursor-pointer transition hover:scale-[1.02] ${
                  settings.webStatus === 'maintenance'
                    ? 'bg-amber-950/40 border-amber-500 shadow-lg shadow-amber-950/30'
                    : 'bg-slate-900 border-slate-750 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-amber-400">রক্ষণাবেক্ষণ (Maintenance)</span>
                  {settings.webStatus === 'maintenance' && <CheckCircle2 className="w-4 h-4 text-amber-400" />}
                </div>
                <h5 className="font-bold text-sm text-white mb-1">{isBn ? 'রক্ষণাবেক্ষণ মোড' : 'Maintenance Mode'}</h5>
                <p className="text-[11px] text-slate-400 leading-snug">
                  {isBn ? 'হেডারে নোটিশ দেখাবে, সাধারণ ব্যবহারকারীরা পাঠযোগ্য মোডে থাকবে।' : 'Displays maintenance banner across the app.'}
                </p>
              </div>

              {/* Option 3: Emergency Lockdown */}
              <div 
                onClick={() => handleWebStatusChange('lockdown')}
                className={`p-4 rounded-2xl border cursor-pointer transition hover:scale-[1.02] ${
                  settings.webStatus === 'lockdown'
                    ? 'bg-rose-950/40 border-rose-500 shadow-lg shadow-rose-950/30'
                    : 'bg-slate-900 border-slate-750 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-rose-400">জরুরি লকডাউন (Lockdown)</span>
                  {settings.webStatus === 'lockdown' && <CheckCircle2 className="w-4 h-4 text-rose-400" />}
                </div>
                <h5 className="font-bold text-sm text-white mb-1">{isBn ? 'হাই-সিকিউরিটি লকডাউন' : 'Emergency Lockdown'}</h5>
                <p className="text-[11px] text-slate-400 leading-snug">
                  {isBn ? 'শুধুমাত্র মারুফ ছাড়া অন্য কেউ ভল্টের গোপন নথি দেখতে পারবে না।' : 'Only Master Admin Maruf can view vault documents.'}
                </p>
              </div>

              {/* Option 4: Read-Only */}
              <div 
                onClick={() => handleWebStatusChange('readonly')}
                className={`p-4 rounded-2xl border cursor-pointer transition hover:scale-[1.02] ${
                  settings.webStatus === 'readonly'
                    ? 'bg-blue-950/40 border-blue-500 shadow-lg shadow-blue-950/30'
                    : 'bg-slate-900 border-slate-750 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-bold text-blue-400">পাঠযোগ্য (Read-Only)</span>
                  {settings.webStatus === 'readonly' && <CheckCircle2 className="w-4 h-4 text-blue-400" />}
                </div>
                <h5 className="font-bold text-sm text-white mb-1">{isBn ? 'শুধুমাত্র প্রদর্শনী আর্কাইভ' : 'Read-Only Archive'}</h5>
                <p className="text-[11px] text-slate-400 leading-snug">
                  {isBn ? 'কোনো নতুন আপলোড বা সম্পাদনা নেওয়া হবে না, কেবল দেখা যাবে।' : 'Disables new uploads or edits for non-admins.'}
                </p>
              </div>

            </div>

            {settings.lastStatusChange && (
              <p className="text-[11px] text-slate-400 font-mono">
                {isBn ? `সর্বশেষ স্ট্যাটাস পরিবর্তন: ${settings.lastStatusChange}` : `Last status updated: ${settings.lastStatusChange}`}
              </p>
            )}
          </div>

          {/* System API Key Add, Test & Remove */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-6">
            <div className="border-b border-slate-700/60 pb-3">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-teal-400" />
                <span>{isBn ? 'সিস্টেম এপিআই কি যোগ ও অপসারণ (API Keys Add & Remove)' : 'System API Key Configuration'}</span>
              </h4>
              <p className="text-xs text-slate-400 mt-0.5">
                {isBn 
                  ? 'আপনার নিজস্ব Google Gemini এপিআই কি ব্যবহার করতে চাইলে নিচে ইনপুট দিয়ে টেস্ট ও সেভ করুন, অথবা মুছে ফেলুন।' 
                  : 'Add or remove custom Gemini AI and cloud integration keys.'}
              </p>
            </div>

            {/* Gemini API Key Box */}
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-200 flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-teal-400" />
                  <span>Google Gemini API Key (ঐচ্ছিক / Optional)</span>
                </label>
                {settings.customGeminiApiKey && (
                  <span className="text-[11px] text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                    {isBn ? 'কাস্টম কি সক্রিয়' : 'Custom Key Active'}
                  </span>
                )}
              </div>

              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type={showGeminiKey ? 'text' : 'password'}
                    value={geminiApiKeyInput}
                    onChange={(e) => setGeminiApiKeyInput(e.target.value)}
                    placeholder="AIzaSy..."
                    className="w-full px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white font-mono text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGeminiKey(!showGeminiKey)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                  >
                    {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleTestApiKey}
                  disabled={isTestingKey}
                  className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-750 text-teal-300 border border-teal-500/40 text-xs font-bold transition flex items-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isTestingKey ? 'animate-spin' : ''}`} />
                  <span>{isTestingKey ? (isBn ? 'টেস্ট...' : 'Testing...') : (isBn ? 'টেস্ট কি' : 'Test Key')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => handleSaveSystemSettings()}
                  className="px-5 py-2.5 rounded-2xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow transition"
                >
                  {isBn ? 'সংরক্ষণ' : 'Save'}
                </button>

                {settings.customGeminiApiKey && (
                  <button
                    type="button"
                    onClick={() => handleRemoveApiKey('gemini')}
                    className="p-2.5 rounded-2xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 transition"
                    title={isBn ? 'কি মুছে ফেলুন' : 'Remove Key'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>

              {keyTestResult && (
                <div className={`p-3 rounded-2xl border text-xs font-semibold ${
                  keyTestResult.valid 
                    ? 'bg-emerald-950/40 border-emerald-500/50 text-emerald-300' 
                    : 'bg-rose-950/40 border-rose-500/50 text-rose-300'
                }`}>
                  {keyTestResult.message}
                </div>
              )}
            </div>

            {/* Google Maps API Key Box */}
            <div className="space-y-2 pt-2 border-t border-slate-750">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                <Globe className="w-4 h-4 text-indigo-400" />
                <span>Google Maps API Key (ঐচ্ছিক / Optional)</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={mapsApiKeyInput}
                  onChange={(e) => setMapsApiKeyInput(e.target.value)}
                  placeholder="AIzaSy... (মৌজা ম্যাপ স্যাটেলাইট ভিউয়ের জন্য)"
                  className="flex-1 px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white font-mono text-xs focus:ring-2 focus:ring-indigo-500 outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleSaveSystemSettings()}
                  className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                >
                  {isBn ? 'সেভ' : 'Save'}
                </button>
                {settings.customMapsApiKey && (
                  <button
                    type="button"
                    onClick={() => handleRemoveApiKey('maps')}
                    className="p-2.5 rounded-2xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Webhook / Cloud Storage Box */}
            <div className="space-y-2 pt-2 border-t border-slate-750">
              <label className="text-xs font-semibold text-slate-300 flex items-center gap-2">
                <HardDrive className="w-4 h-4 text-amber-400" />
                <span>Custom Cloud Storage Webhook (ঐচ্ছিক / Optional)</span>
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={webhookUrlInput}
                  onChange={(e) => setWebhookUrlInput(e.target.value)}
                  placeholder="https://storage-api.maruffamily.com/vault-backup"
                  className="flex-1 px-4 py-2.5 rounded-2xl bg-slate-900 border border-slate-750 text-white font-mono text-xs focus:ring-2 focus:ring-amber-500 outline-none"
                />
                <button
                  type="button"
                  onClick={() => handleSaveSystemSettings()}
                  className="px-4 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold"
                >
                  {isBn ? 'সেভ' : 'Save'}
                </button>
                {settings.customWebhookUrl && (
                  <button
                    type="button"
                    onClick={() => handleRemoveApiKey('webhook')}
                    className="p-2.5 rounded-2xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

          </div>

          {/* Cloud Storage Quota & Visitor Gatekeeper Controls */}
          <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 shadow space-y-4">
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              <HardDrive className="w-4 h-4 text-emerald-400" />
              <span>{isBn ? 'ক্লাউড স্টোরেজ কোটা ও সাধারণ গেটকিপার' : 'Cloud Storage Quota & Gatekeeper'}</span>
            </h4>

            {/* Storage Progress */}
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-semibold">{isBn ? 'ভল্ট এনক্রিপ্টেড স্টোরেজ ব্যবহৃত:' : 'Storage Used:'}</span>
                <span className="font-mono text-emerald-400 font-bold">14.8 MB / 50.0 GB (0.03%)</span>
              </div>
              <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-emerald-500 to-teal-400 rounded-full w-[3%]" />
              </div>
              <p className="text-[10px] text-slate-400">
                {isBn 
                  ? 'সামরিক মানের AES-256 এনক্রিপশনে সুরক্ষিত ৫০ গিগাবাইট হাইপার-ক্লাউড স্পেস।' 
                  : '50GB AES-256 encrypted storage allocation.'}
              </p>
            </div>

            {/* Visitor Request Toggle */}
            <div className="flex items-center justify-between pt-2">
              <div>
                <h5 className="text-xs font-bold text-white">
                  {isBn ? 'পাবলিক ভিজিটরদের ফাইল ও তথ্য জমার অনুরোধ পোর্টাল' : 'Public Visitor Request Submission Gate'}
                </h5>
                <p className="text-[11px] text-slate-400">
                  {isBn ? 'চালু থাকলে আত্মীয় বা ভিজিটররা অনুমোদনের জন্য ফাইল জমা দিতে পারবে।' : 'Allow relatives to submit files for admin verification.'}
                </p>
              </div>
              <button
                type="button"
                onClick={() => handleSaveSystemSettings({ allowVisitorRequests: !settings.allowVisitorRequests })}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition border ${
                  settings.allowVisitorRequests !== false
                    ? 'bg-emerald-600 text-white border-emerald-500'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                {settings.allowVisitorRequests !== false ? (isBn ? 'সক্রিয় (Active)' : 'Enabled') : (isBn ? 'বন্ধ (Disabled)' : 'Disabled')}
              </button>
            </div>

          </div>

          {/* Toast */}
          {settingsSavedToast && (
            <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-950 border border-emerald-500 text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{settingsSavedToast}</span>
            </div>
          )}

        </div>
      )}

      {/* Subtab 3: Member Directory Management */}
      {activeSubTab === 'members' && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-slate-850 border border-slate-700 flex justify-between items-center">
            <h3 className="text-sm font-bold text-white">
              {isBn ? `পরিবারের সকল সদস্য (${members.length} জন)` : `All Family Members (${members.length})`}
            </h3>
            <button
              onClick={onOpenAddMemberModal}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-xl"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{isBn ? 'নতুন সদস্য' : 'Add Member'}</span>
            </button>
          </div>

          <div className="space-y-2">
            {members.map((m) => (
              <div
                key={m.id}
                className="p-3.5 rounded-2xl bg-slate-850 border border-slate-700/70 flex items-center justify-between text-xs"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-xl flex items-center justify-center font-bold text-xs ${m.avatarColor}`}>
                    {m.nameBn.slice(0, 2)}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-white">{isBn ? m.nameBn : m.nameEn}</h4>
                      <span className={`px-2 py-0.2 rounded-full text-[10px] font-bold border ${roleBadgeStyles[m.systemRole].bg} ${roleBadgeStyles[m.systemRole].text} ${roleBadgeStyles[m.systemRole].border}`}>
                        {m.systemRole}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400">
                      {isBn ? m.roleBn : m.roleEn} {m.phone ? `• ${m.phone}` : ''}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {m.id !== 'maruf' && m.id !== 'barek_bhuyan' && (
                    <button
                      onClick={() => onDeleteMember(m.id)}
                      title={isBn ? 'মুছে ফেলুন' : 'Delete Member'}
                      className="p-2 rounded-xl bg-slate-800 hover:bg-rose-950 text-slate-400 hover:text-rose-300 border border-slate-700 transition"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Subtab 4: Theme & Privacy Settings */}
      {activeSubTab === 'theme' && (
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-6">
          <h3 className="text-sm font-bold text-white border-b border-slate-700 pb-3">
            {isBn ? 'থিম কাস্টমাইজেশন ও গোপনীয়তা কন্ট্রোল' : 'Theme Customization & Privacy Settings'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'প্রাইমারি কালার অ্যাকসেন্ট' : 'Primary Color Accent'}
              </label>
              <select
                value={settings.accentColor}
                onChange={(e: any) => onUpdateSettings({ ...settings, accentColor: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none"
              >
                <option value="emerald">{isBn ? 'এমারেল্ড গ্রীন (আইনি ও সম্পত্তি)' : 'Emerald Legal Green'}</option>
                <option value="sapphire">{isBn ? 'রয়্যাল স্যাফায়ার ব্লু' : 'Royal Sapphire Blue'}</option>
                <option value="amber">{isBn ? 'ওয়ার্ম গোল্ড ও অ্যাম্বার' : 'Warm Gold & Amber'}</option>
                <option value="slate">{isBn ? 'ক্লাসিক স্লট ডার্ক' : 'Classic Slate Dark'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'লেআউট ডেনসিটি' : 'Layout Density'}
              </label>
              <select
                value={settings.layoutDensity}
                onChange={(e: any) => onUpdateSettings({ ...settings, layoutDensity: e.target.value })}
                className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs outline-none"
              >
                <option value="comfortable">{isBn ? 'কম্ফোর্টেবল (প্রস্তাবিত)' : 'Comfortable (Recommended)'}</option>
                <option value="compact">{isBn ? 'কম্প্যাক্ট (ঘন বিন্যাস)' : 'Compact'}</option>
                <option value="spacious">{isBn ? 'স্পেসিয়াস (প্রশস্ত)' : 'Spacious'}</option>
              </select>
            </div>
          </div>

          {/* Privacy Toggle */}
          <div className="pt-4 border-t border-slate-700/60 flex items-center justify-between">
            <div>
              <h4 className="text-xs font-bold text-white">
                {isBn ? 'অতিথিদের জন্য সংবেদনশীল তথ্য গোপন রাখুন' : 'Hide Sensitive Data for Guests'}
              </h4>
              <p className="text-[11px] text-slate-400">
                {isBn ? 'এনআইডি নম্বর ও ব্যক্তিগত ফোন নম্বর শুধুমাত্র অ্যাডমিন দেখলে দৃশ্যমান হবে।' : 'Hide NIDs and phones for non-admin viewers.'}
              </p>
            </div>
            <button
              onClick={() => onUpdateSettings({ ...settings, hideSensitiveDataForGuests: !settings.hideSensitiveDataForGuests })}
              className={`p-2 rounded-xl border text-xs font-bold flex items-center gap-1.5 transition ${
                settings.hideSensitiveDataForGuests
                  ? 'bg-emerald-600 text-white border-emerald-500'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}
            >
              {settings.hideSensitiveDataForGuests ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              <span>{settings.hideSensitiveDataForGuests ? (isBn ? 'গোপন চালু' : 'Hidden') : (isBn ? 'উন্মুক্ত' : 'Visible')}</span>
            </button>
          </div>
        </div>
      )}

      {/* Subtab 5: Vercel Cron & Secrets Configuration */}
      {activeSubTab === 'cron' && (
        <div className="p-6 rounded-3xl bg-slate-850 border border-slate-700 space-y-6">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Server className="w-4 h-4 text-emerald-400" />
              <span>{isBn ? 'Vercel Cron ব্যাকগ্রাউন্ড এক্সপায়ারি জব ও সিকিউরিটি' : 'Vercel Cron Expiry Job Security'}</span>
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn 
                ? 'সার্ভারলেস পরিবেশে অননুমোদিত ইউজার যেন বারবার এক্সপায়ারি নোটিফিকেশন ট্রিগার করতে না পারে, সেজন্য Bearer CRON_SECRET অথরাইজেশন হেডার প্রয়োগ করা হয়েছে।'
                : 'Securing serverless cron jobs to prevent unauthorized triggering and email spam via Bearer Token authentication.'}
            </p>
          </div>

          {/* Configuration Code Preview */}
          <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-[11px] font-mono font-bold text-emerald-400">vercel.json configuration:</span>
            <pre className="text-[11px] font-mono text-slate-300 bg-slate-950 p-3 rounded-xl overflow-x-auto">
{`{
  "crons": [
    {
      "path": "/api/cron/check-expiry",
      "schedule": "0 0 * * *"
    }
  ]
}`}
            </pre>
          </div>

          <div className="space-y-3">
            <label className="block text-xs font-semibold text-slate-300">
              {isBn ? 'এনভায়রনমেন্ট সিক্রেট টোকেন (CRON_SECRET)' : 'CRON_SECRET Environment Token'}
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={settings.cronSecret}
                onChange={(e) => onUpdateSettings({ ...settings, cronSecret: e.target.value })}
                className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
              />
              <button
                onClick={testVercelCron}
                disabled={isTestingCron}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl shadow transition"
              >
                {isTestingCron ? (isBn ? 'পরীক্ষা চলছে...' : 'Testing...') : (isBn ? 'অথরাইজেশন টেস্ট করুন' : 'Test Secret Auth')}
              </button>
            </div>
          </div>

          {cronTestResponse && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-emerald-500/30 text-xs font-mono space-y-1">
              <span className="text-emerald-400 font-bold block">{isBn ? 'সার্ভার রেসপন্স:' : 'Server Response:'}</span>
              <pre className="text-slate-300 text-[11px] overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(cronTestResponse, null, 2)}
              </pre>
            </div>
          )}
        </div>
      )}

    </div>
  );
};
