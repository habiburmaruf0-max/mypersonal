import React, { useState } from 'react';
import { Lock, X, ShieldCheck, KeyRound, Sparkles, Mail, CheckCircle2, AlertTriangle, ArrowRight, RefreshCw, Flame } from 'lucide-react';
import { Language, UserRole } from '../types/family';
import { 
  loginWithEmail, 
  registerWithEmail, 
  sendResetPassword, 
  isAuthorizedAdminEmail, 
  AUTHORIZED_ADMIN_EMAILS 
} from '../services/firebase';

interface AdminLoginModalProps {
  language: Language;
  onClose: () => void;
  onSuccessLogin: (userRole?: UserRole, userEmail?: string) => void;
}

export const AdminLoginModal: React.FC<AdminLoginModalProps> = ({
  language,
  onClose,
  onSuccessLogin,
}) => {
  const isBn = language === 'bn';
  const [authMode, setAuthMode] = useState<'firebase_email' | 'pin_passcode' | 'register'>('firebase_email');
  
  // Firebase Auth Form State
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [isResetSent, setIsResetSent] = useState(false);

  // Quick Passcode State
  const [pin, setPin] = useState('');
  const [pinError, setPinError] = useState(false);

  // Handle Firebase Email Login
  const handleFirebaseLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setErrorMessage(isBn ? 'অনুগ্রহ করে ইমেইল ও পাসওয়ার্ড প্রদান করুন।' : 'Please enter your email and password.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);
    setSuccessMessage(null);

    try {
      const res = await loginWithEmail(email.trim(), password.trim());
      setSuccessMessage(isBn ? `স্বাগতম! সফলভাবে লগইন হয়েছে (${res.profile.role})` : `Welcome! Logged in as ${res.profile.role}`);
      setTimeout(() => {
        onSuccessLogin(res.profile.role, res.user.email || undefined);
        onClose();
      }, 700);
    } catch (err: any) {
      console.error('Firebase login error:', err);
      let msg = err.message || 'Login failed';
      if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential') {
        msg = isBn ? 'ভুল ইমেইল বা পাসওয়ার্ড। পুনরায় চেষ্টা করুন অথবা পিন ব্যবহার করুন।' : 'Invalid credentials. Please verify or use Quick Passcode.';
      } else if (err.code === 'auth/wrong-password') {
        msg = isBn ? 'ভুল পাসওয়ার্ড। ভুলে গেলে রিসেট বাটনে চাপ দিন।' : 'Incorrect password. Click forgot password to reset.';
      } else if (err.code === 'auth/network-request-failed') {
        msg = isBn ? 'ইন্টারনেট সংযোগে ত্রুটি। অফলাইন পিন ব্যবহার করতে পারেন।' : 'Network connection error. You may use Quick Passcode.';
      }
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Firebase Registration
  const handleFirebaseRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setErrorMessage(isBn ? 'ইমেইল ও পাসওয়ার্ড দেওয়া আবশ্যক।' : 'Email and password required.');
      return;
    }
    if (password.length < 6) {
      setErrorMessage(isBn ? 'পাসওয়ার্ড ন্যূনতম ৬ অক্ষরের হতে হবে।' : 'Password must be at least 6 characters.');
      return;
    }

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await registerWithEmail(email.trim(), password.trim(), displayName.trim() || undefined);
      setSuccessMessage(isBn ? `অ্যাকাউন্ট তৈরি সম্পন্ন! ভূমিকা: ${res.profile.role}` : `Account created as ${res.profile.role}!`);
      setTimeout(() => {
        onSuccessLogin(res.profile.role, res.user.email || undefined);
        onClose();
      }, 800);
    } catch (err: any) {
      console.error('Firebase register error:', err);
      let msg = err.message || 'Registration failed';
      if (err.code === 'auth/email-already-in-use') {
        msg = isBn ? 'এই ইমেইলটি পূর্বেই ব্যবহৃত হয়েছে। অনুগ্রহ করে লগইন করুন।' : 'Email already in use. Please sign in instead.';
      }
      setErrorMessage(msg);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Password Reset
  const handleForgotPassword = async () => {
    if (!email.trim()) {
      setErrorMessage(isBn ? 'পাসওয়ার্ড রিসেটের জন্য প্রথমে আপনার ইমেইল লিখুন।' : 'Enter your email above to receive password reset link.');
      return;
    }
    setIsLoading(true);
    try {
      await sendResetPassword(email.trim());
      setIsResetSent(true);
      setSuccessMessage(isBn ? 'পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে।' : 'Password reset link sent to your email.');
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to send reset email.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Quick PIN Form
  const handlePinSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = pin.trim().toLowerCase();
    if (clean === 'maruf123' || clean === '1985' || clean === 'maruf' || clean === 'admin') {
      onSuccessLogin('Admin', 'habiburmaruf@gmail.com');
      onClose();
    } else {
      setPinError(true);
    }
  };

  const handleSelectQuickEmail = (selectedEmail: string) => {
    setEmail(selectedEmail);
    setPassword('maruf123'); // Default convenience for testing
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-750 p-6 sm:p-8 space-y-5 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Top Header */}
        <div className="text-center space-y-1.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center mx-auto shadow-md">
            <Flame className="w-6 h-6" />
          </div>
          <h3 className="text-xl font-extrabold text-white">
            {isBn ? 'ফায়ারবেস অথেন্টিকেশন ও অ্যাডমিন পোর্টাল' : 'Firebase Authentication & Admin Portal'}
          </h3>
          <p className="text-xs text-slate-400">
            {isBn 
              ? 'মারুফের অনুমোদিত মাস্টার জিমেইল বা ফায়ারবেস ইমেইল-পাসওয়ার্ড দিয়ে প্রবেশ করুন।' 
              : 'Sign in with an authorized master Gmail account or Firebase credentials.'}
          </p>
        </div>

        {/* Auth Mode Tabs */}
        <div className="flex rounded-2xl bg-slate-950 p-1 border border-slate-800 text-xs font-bold">
          <button
            type="button"
            onClick={() => { setAuthMode('firebase_email'); setErrorMessage(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              authMode === 'firebase_email' ? 'bg-amber-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Mail className="w-3.5 h-3.5" />
            <span>{isBn ? 'ইমেইল লগইন' : 'Email Sign In'}</span>
          </button>

          <button
            type="button"
            onClick={() => { setAuthMode('pin_passcode'); setErrorMessage(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              authMode === 'pin_passcode' ? 'bg-indigo-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <KeyRound className="w-3.5 h-3.5" />
            <span>{isBn ? 'দ্রুত পিন কোড' : 'Quick Passcode'}</span>
          </button>

          <button
            type="button"
            onClick={() => { setAuthMode('register'); setErrorMessage(null); }}
            className={`flex-1 py-2 rounded-xl transition flex items-center justify-center gap-1.5 ${
              authMode === 'register' ? 'bg-emerald-600 text-white shadow' : 'text-slate-400 hover:text-white'
            }`}
          >
            <span>{isBn ? 'নিবন্ধন' : 'Sign Up'}</span>
          </button>
        </div>

        {/* Feedback Alerts */}
        {errorMessage && (
          <div className="p-3 rounded-2xl bg-rose-950/70 border border-rose-600/60 text-xs text-rose-300 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {successMessage && (
          <div className="p-3 rounded-2xl bg-emerald-950/70 border border-emerald-500/60 text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{successMessage}</span>
          </div>
        )}

        {/* Tab 1: Firebase Email Login Form */}
        {authMode === 'firebase_email' && (
          <form onSubmit={handleFirebaseLogin} className="space-y-4">
            
            {/* 1-Click Quick Select from Authorized Master Accounts */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-semibold text-slate-400 block">
                {isBn ? 'মারুফের অনুমোদিত মাস্টার ইমেইল নির্বাচন করুন:' : 'Quick Select Authorized Master Email:'}
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {AUTHORIZED_ADMIN_EMAILS.map((admEmail) => (
                  <button
                    type="button"
                    key={admEmail}
                    onClick={() => handleSelectQuickEmail(admEmail)}
                    className={`p-2 rounded-xl text-left border text-[11px] font-mono transition flex items-center justify-between ${
                      email.toLowerCase() === admEmail.toLowerCase()
                        ? 'bg-amber-950/60 border-amber-500 text-amber-300'
                        : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <span className="truncate">{admEmail}</span>
                    <span className="text-[9px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 font-sans font-bold">Admin</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'ফায়ারবেস ইমেইল ঠিকানা' : 'Firebase Email Address'}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="habiburmaruf@gmail.com"
                required
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <div>
              <div className="flex justify-between items-center mb-1">
                <label className="text-xs font-semibold text-slate-300">
                  {isBn ? 'পাসওয়ার্ড' : 'Password'}
                </label>
                <button
                  type="button"
                  onClick={handleForgotPassword}
                  className="text-[11px] text-amber-400 hover:underline"
                >
                  {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot password?'}
                </button>
              </div>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs sm:text-sm focus:ring-2 focus:ring-amber-500 outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl bg-amber-600 hover:bg-amber-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold shadow-lg shadow-amber-950/40 transition flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isBn ? 'যাচাই করা হচ্ছে...' : 'Verifying...'}</span>
                </>
              ) : (
                <>
                  <Lock className="w-4 h-4" />
                  <span>{isBn ? 'ফায়ারবেস ইমেইল দিয়ে লগইন' : 'Sign in with Firebase'}</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* Tab 2: Quick Passcode Form */}
        {authMode === 'pin_passcode' && (
          <form onSubmit={handlePinSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'অ্যাডমিন পাসওয়ার্ড বা পিন' : 'Admin Passphrase or PIN'}
              </label>
              <input
                type="password"
                value={pin}
                onChange={(e) => {
                  setPin(e.target.value);
                  setPinError(false);
                }}
                placeholder={isBn ? 'পাসওয়ার্ড লিখুন (যেমন: maruf123)' : 'Enter password (e.g. maruf123)'}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 outline-none"
                autoFocus
              />
              {pinError && (
                <p className="text-xs text-rose-400 mt-1">
                  {isBn ? 'ভুল পাসওয়ার্ড! সঠিক পাসওয়ার্ড দিন।' : 'Incorrect passphrase! Please try again.'}
                </p>
              )}
              <p className="text-[11px] text-slate-500 mt-1">
                {isBn ? 'ডিফল্ট পিন: ' : 'Default PIN: '}
                <code className="text-indigo-400">maruf123</code>
              </p>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold shadow-lg shadow-indigo-950/40 transition"
            >
              {isBn ? 'পিন দিয়ে আনলক করুন' : 'Unlock with PIN'}
            </button>
          </form>
        )}

        {/* Tab 3: Firebase Registration Form */}
        {authMode === 'register' && (
          <form onSubmit={handleFirebaseRegister} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'পূর্ণ নাম' : 'Full Name'}
              </label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                placeholder={isBn ? 'যেমন: ওমর ফারুক' : 'e.g. Omar Faruque'}
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'ইমেইল ঠিকানা' : 'Email Address'}
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@gmail.com"
                required
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white font-mono text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'পাসওয়ার্ড (ন্যূনতম ৬ অক্ষর)' : 'Password (min 6 chars)'}
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-750 text-white text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs sm:text-sm font-bold shadow-lg shadow-emerald-950/40 transition flex items-center justify-center gap-2"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>{isBn ? 'তৈরি করা হচ্ছে...' : 'Creating...'}</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isBn ? 'নতুন অ্যাকাউন্ট নিবন্ধন করুন' : 'Register Account'}</span>
                </>
              )}
            </button>
          </form>
        )}

        {/* 1-Click Demo Shortcut */}
        <div className="pt-2 border-t border-slate-800">
          <button
            type="button"
            onClick={() => {
              onSuccessLogin('Admin', 'habiburmaruf@gmail.com');
              onClose();
            }}
            className="w-full py-2 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{isBn ? '১-ক্লিক দ্রুত অ্যাডমিন অ্যাক্সেস (মারুফ)' : '1-Click Fast Admin Access (Maruf)'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};

