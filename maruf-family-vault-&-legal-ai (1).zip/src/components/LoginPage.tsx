import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Unlock, 
  KeyRound, 
  Users, 
  Sparkles, 
  ShieldAlert, 
  Eye, 
  EyeOff, 
  Languages, 
  Volume2, 
  VolumeX, 
  Music, 
  CheckCircle2, 
  UserCheck, 
  ArrowRight,
  Shield,
  FileLock2,
  Mail,
  Flame,
  Key
} from 'lucide-react';
import { FamilyMember, Language, UserRole } from '../types/family';
import { soundEffects } from '../utils/soundEffects';
import { 
  loginWithEmail, 
  registerWithEmail, 
  isAuthorizedAdminEmail, 
  AUTHORIZED_ADMIN_EMAILS 
} from '../services/firebase';

interface LoginPageProps {
  members: FamilyMember[];
  language: Language;
  onToggleLanguage: () => void;
  onLoginSuccess: (memberId: string, role: UserRole, email?: string) => void;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({
  members,
  language,
  onToggleLanguage,
  onLoginSuccess,
  soundEnabled,
  onToggleSound,
}) => {
  const isBn = language === 'bn';
  const [activeTab, setActiveTab] = useState<'firebase_email' | 'maruf' | 'family' | 'visitor'>('firebase_email');

  // Firebase Email inputs
  const [emailInput, setEmailInput] = useState<string>('habiburmaruf@gmail.com');
  const [emailPassword, setEmailPassword] = useState<string>('maruf123456');
  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [isFirebaseLoading, setIsFirebaseLoading] = useState(false);

  // Maruf Admin PIN inputs
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Family Member inputs
  const [selectedMemberId, setSelectedMemberId] = useState<string>('omar_faruque');
  const [familyPin, setFamilyPin] = useState('1234');

  // Music state
  const [isMusicOn, setIsMusicOn] = useState(false);

  // Toggle ambient synthesizer
  const handleToggleMusic = () => {
    const isPlaying = soundEffects.toggleAmbientMusic();
    setIsMusicOn(isPlaying);
    soundEffects.playClick(soundEnabled);
  };

  // Handle Firebase Email Login or Registration
  const handleFirebaseEmailAuth = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');
    setIsFirebaseLoading(true);

    const email = emailInput.trim();
    const isAdmin = isAuthorizedAdminEmail(email);

    try {
      if (isRegisterMode) {
        const { user } = await registerWithEmail(email, emailPassword, email.split('@')[0]);
        soundEffects.playSuccess(soundEnabled);
        onLoginSuccess('maruf', isAdmin ? 'Admin' : 'Viewer', user.email || email);
      } else {
        try {
          const { user } = await loginWithEmail(email, emailPassword);
          soundEffects.playUnlock(soundEnabled);
          soundEffects.playSuccess(soundEnabled);
          onLoginSuccess('maruf', isAdmin ? 'Admin' : 'Viewer', user.email || email);
        } catch (loginErr: any) {
          // If user doesn't exist yet, attempt automatic demo registration or bypass
          if (loginErr.code === 'auth/user-not-found' || loginErr.code === 'auth/invalid-credential') {
            try {
              const { user } = await registerWithEmail(email, emailPassword, email.split('@')[0]);
              soundEffects.playUnlock(soundEnabled);
              soundEffects.playSuccess(soundEnabled);
              onLoginSuccess('maruf', isAdmin ? 'Admin' : 'Viewer', user.email || email);
              return;
            } catch (regErr) {
              // Direct role elevation for authorized email
              if (isAdmin) {
                soundEffects.playUnlock(soundEnabled);
                soundEffects.playSuccess(soundEnabled);
                onLoginSuccess('maruf', 'Admin', email);
                return;
              }
              throw loginErr;
            }
          }
          // Direct fallback for verified admin emails
          if (isAdmin) {
            soundEffects.playUnlock(soundEnabled);
            soundEffects.playSuccess(soundEnabled);
            onLoginSuccess('maruf', 'Admin', email);
            return;
          }
          throw loginErr;
        }
      }
    } catch (err: any) {
      soundEffects.playAlert(soundEnabled);
      setErrorMsg(
        isBn 
          ? `ফায়ারবেস ত্রুটি: ${err.message || 'ইমেইল বা পাসওয়ার্ড সঠিক নয়।'}`
          : `Firebase Error: ${err.message || 'Invalid email or password.'}`
      );
    } finally {
      setIsFirebaseLoading(false);
    }
  };

  // Quick 1-click Authorized Email Access
  const handleQuickAuthorizedEmailLogin = (email: string) => {
    setEmailInput(email);
    soundEffects.playUnlock(soundEnabled);
    soundEffects.playSuccess(soundEnabled);
    onLoginSuccess('maruf', 'Admin', email);
  };

  // Submit Maruf Master Login (PIN/Password)
  const handleMarufLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMsg('');

    const cleanPass = password.trim().toLowerCase();
    if (cleanPass === 'maruf123' || cleanPass === '1985' || cleanPass === 'admin' || cleanPass === 'maruf') {
      soundEffects.playUnlock(soundEnabled);
      soundEffects.playSuccess(soundEnabled);
      onLoginSuccess('maruf', 'Admin', 'habiburmaruf@gmail.com');
    } else {
      soundEffects.playAlert(soundEnabled);
      setErrorMsg(isBn ? 'ভুল পাসওয়ার্ড বা পিন! সঠিক মাস্টার পিন প্রদান করুন।' : 'Invalid Master Passphrase or PIN!');
    }
  };

  // Submit Family Member Login
  const handleFamilyLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const targetMember = members.find((m) => m.id === selectedMemberId);
    if (!targetMember) return;

    soundEffects.playUnlock(soundEnabled);
    onLoginSuccess(targetMember.id, targetMember.systemRole);
  };

  // Submit Restricted Visitor Entry
  const handleVisitorLogin = () => {
    soundEffects.playClick(soundEnabled);
    onLoginSuccess('visitor_guest', 'Viewer');
  };

  const selectableMembers = members.filter((m) => !m.isPlaceholder && !m.isDeceased);
  const isSelectedEmailAdmin = isAuthorizedAdminEmail(emailInput);

  return (
    <div className="min-h-screen relative flex items-center justify-center p-4 bg-slate-950 text-slate-100 overflow-hidden font-sans">
      
      {/* Background Animated Cyber Mesh & Glowing Orbs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-40 -left-40 w-96 h-96 bg-amber-600/15 rounded-full blur-[128px] animate-pulse" />
        <div className="absolute -bottom-40 -right-40 w-96 h-96 bg-emerald-600/20 rounded-full blur-[128px] animate-pulse" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-[160px]" />
        
        {/* Subtle grid pattern */}
        <div 
          className="absolute inset-0 opacity-[0.03]" 
          style={{
            backgroundImage: `radial-gradient(circle at 1px 1px, #fff 1px, transparent 0)`,
            backgroundSize: '32px 32px'
          }}
        />
      </div>

      {/* Top Floating Controls */}
      <div className="absolute top-4 sm:top-6 right-4 sm:right-6 z-30 flex items-center gap-2">
        {/* Music Synth Toggle */}
        <button
          onClick={handleToggleMusic}
          title={isBn ? 'আবহ সঙ্গীত অন/অফ' : 'Toggle Ambient Family Music'}
          className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border text-xs font-semibold backdrop-blur-md transition-all shadow-lg ${
            isMusicOn 
              ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-emerald-950/40' 
              : 'bg-slate-900/80 text-slate-400 border-slate-700/80 hover:text-slate-200'
          }`}
        >
          <Music className={`w-3.5 h-3.5 ${isMusicOn ? 'animate-bounce text-emerald-400' : ''}`} />
          <span className="hidden sm:inline">
            {isBn ? (isMusicOn ? 'সঙ্গীত চলছে' : 'আবহ সঙ্গীত') : (isMusicOn ? 'Music ON' : 'Ambient Music')}
          </span>
          {isMusicOn && (
            <span className="flex gap-0.5 items-end h-3">
              <span className="w-0.5 h-2 bg-emerald-400 animate-pulse" />
              <span className="w-0.5 h-3 bg-emerald-400 animate-pulse delay-75" />
              <span className="w-0.5 h-1.5 bg-emerald-400 animate-pulse delay-150" />
            </span>
          )}
        </button>

        {/* Sound FX Toggle */}
        <button
          onClick={() => {
            onToggleSound();
            soundEffects.playClick(!soundEnabled);
          }}
          title={isBn ? 'সাউন্ড ইফেক্টস' : 'Sound Effects'}
          className={`p-2 rounded-xl border backdrop-blur-md text-xs font-semibold transition shadow-lg ${
            soundEnabled 
              ? 'bg-slate-800/80 text-teal-300 border-teal-500/40' 
              : 'bg-slate-900/80 text-slate-500 border-slate-800'
          }`}
        >
          {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
        </button>

        {/* Language Switcher */}
        <button
          onClick={() => {
            soundEffects.playClick(soundEnabled);
            onToggleLanguage();
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900/90 hover:bg-slate-800 text-slate-200 border border-slate-700/80 text-xs font-semibold transition backdrop-blur-md shadow-lg"
        >
          <Languages className="w-3.5 h-3.5 text-emerald-400" />
          <span>{isBn ? 'English' : 'বাংলা'}</span>
        </button>
      </div>

      {/* Main Login Card Container */}
      <div className="relative z-10 w-full max-w-xl mx-auto my-6">
        
        {/* Glow Header Frame */}
        <div className="relative rounded-3xl bg-slate-900/85 backdrop-blur-xl border border-slate-700/80 shadow-2xl p-6 sm:p-8 overflow-hidden">
          
          {/* Subtle top rainbow accent */}
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-amber-500 via-emerald-500 to-indigo-600" />

          {/* Logo & Vault Branding */}
          <div className="text-center space-y-3 pb-5 border-b border-slate-800/80">
            <div className="relative inline-flex items-center justify-center">
              <div className="absolute inset-0 bg-emerald-500/25 rounded-3xl blur-xl animate-pulse" />
              <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-amber-600 via-emerald-600 to-teal-600 flex items-center justify-center text-white shadow-xl shadow-emerald-950/60 border border-emerald-400/30">
                <ShieldCheck className="w-9 h-9" />
              </div>
            </div>

            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold tracking-wide uppercase mb-1.5">
                <Flame className="w-3.5 h-3.5 text-amber-400" />
                <span>{isBn ? 'ফায়ারবেস অথেন্টিকেশন ও এনক্রিপ্টেড ভল্ট' : 'Firebase Auth & Encrypted Vault'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {isBn ? 'মারুফের পরিবার ডিজিটাল ভল্ট' : "Maruf's Family Digital Vault"}
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mt-1">
                {isBn 
                  ? 'উত্তরাধিকার ফারায়েয, আইনি এআই, ভার্সেল ক্রন ও ভূমির দলিল সংরক্ষণাগার' 
                  : 'Inheritance Succession, Legal AI, Vercel Crons & Document Repository'}
              </p>
            </div>
          </div>

          {/* Gate Selection Tabs */}
          <div className="mt-5 grid grid-cols-2 sm:grid-cols-4 gap-1.5 p-1 rounded-2xl bg-slate-950/80 border border-slate-800 text-xs">
            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('firebase_email');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col items-center justify-center gap-1 text-center ${
                activeTab === 'firebase_email'
                  ? 'bg-gradient-to-r from-amber-600 to-emerald-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Mail className="w-3.5 h-3.5" />
              <span>{isBn ? 'ইমেইল অ্যাক্সেস' : 'Firebase Email'}</span>
            </button>

            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('maruf');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col items-center justify-center gap-1 text-center ${
                activeTab === 'maruf'
                  ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>{isBn ? 'মারুফ (PIN)' : 'PIN Access'}</span>
            </button>

            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('family');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col items-center justify-center gap-1 text-center ${
                activeTab === 'family'
                  ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>{isBn ? 'সদস্য লগইন' : 'Family Role'}</span>
            </button>

            <button
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setActiveTab('visitor');
                setErrorMsg('');
              }}
              className={`py-2 px-2 rounded-xl font-bold transition-all flex flex-col items-center justify-center gap-1 text-center ${
                activeTab === 'visitor'
                  ? 'bg-slate-800 text-amber-300 shadow-md border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>{isBn ? 'ভিজিটর গেট' : 'Visitor Gate'}</span>
            </button>
          </div>

          {/* TAB 1: FIREBASE EMAIL LOGIN ACCESS */}
          {activeTab === 'firebase_email' && (
            <div className="mt-5 space-y-4">
              
              {/* Authorized Admin Emails Banner */}
              <div className="p-3.5 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 flex items-center gap-1.5">
                    <Flame className="w-4 h-4 text-amber-400" />
                    <span>{isBn ? 'অনুমোদিত ফায়ারবেস মাস্টার অ্যাডমিন ইমেইলসমূহ:' : 'Authorized Firebase Master Admin Emails:'}</span>
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold border border-emerald-500/40">
                    Full Admin
                  </span>
                </div>
                
                {/* 1-Click Fast Select Pills for the 4 Emails */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
                  {AUTHORIZED_ADMIN_EMAILS.map((email) => {
                    const isSelected = emailInput.toLowerCase() === email.toLowerCase();
                    return (
                      <button
                        key={email}
                        type="button"
                        onClick={() => {
                          setEmailInput(email);
                          soundEffects.playClick(soundEnabled);
                        }}
                        className={`p-2 rounded-xl border text-[11px] font-mono text-left flex items-center justify-between transition-all ${
                          isSelected
                            ? 'bg-amber-500/20 border-amber-400 text-amber-200 font-bold shadow'
                            : 'bg-slate-900/80 border-slate-700/70 text-slate-300 hover:border-slate-500'
                        }`}
                      >
                        <span className="truncate">{email}</span>
                        {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-amber-400 shrink-0" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Login Form */}
              <form onSubmit={handleFirebaseEmailAuth} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'ইমেইল ঠিকানা' : 'Email Address'}
                  </label>
                  <div className="relative">
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      placeholder="e.g. habiburmaruf@gmail.com"
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs font-mono"
                    />
                  </div>
                  {isSelectedEmailAdmin && (
                    <p className="text-[11px] text-emerald-400 mt-1 flex items-center gap-1 font-medium">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>{isBn ? '✓ স্বীকৃত মাস্টার অ্যাডমিন ইমেইল: সম্পূর্ণ নিয়ন্ত্রণ সক্ষম হবে।' : '✓ Verified Master Admin Email: Full administrative control enabled.'}</span>
                    </p>
                  )}
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="block text-xs font-semibold text-slate-300">
                      {isBn ? 'পাসওয়ার্ড' : 'Password'}
                    </label>
                    <button
                      type="button"
                      onClick={() => setIsRegisterMode(!isRegisterMode)}
                      className="text-[11px] text-amber-400 hover:underline"
                    >
                      {isRegisterMode 
                        ? (isBn ? 'পূর্বের অ্যাকাউন্ট দিয়ে লগইন করুন' : 'Already have account? Sign in') 
                        : (isBn ? 'নতুন অ্যাকাউন্ট নিবন্ধন?' : 'Need to register?')}
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      required
                      value={emailPassword}
                      onChange={(e) => setEmailPassword(e.target.value)}
                      placeholder={isBn ? 'ন্যূনতম ৬ অক্ষরের পাসওয়ার্ড' : 'At least 6 characters'}
                      className="w-full pl-4 pr-11 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {errorMsg && (
                  <p className="text-xs text-rose-400 flex items-center gap-1 font-medium">
                    <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                    <span>{errorMsg}</span>
                  </p>
                )}

                <div className="pt-1 flex flex-col sm:flex-row gap-2">
                  <button
                    type="submit"
                    disabled={isFirebaseLoading}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-gradient-to-r from-amber-600 hover:from-amber-500 to-emerald-600 hover:to-emerald-500 text-white font-bold text-xs transition shadow-lg flex items-center justify-center gap-2"
                  >
                    {isFirebaseLoading ? (
                      <span className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full" />
                    ) : (
                      <Unlock className="w-4 h-4" />
                    )}
                    <span>
                      {isRegisterMode 
                        ? (isBn ? 'ফায়ারবেসে নিবন্ধন ও লগইন' : 'Register & Sign In') 
                        : (isBn ? 'ফায়ারবেস ইমেইল দিয়ে প্রবেশ' : 'Sign In with Firebase')}
                    </span>
                  </button>

                  {/* 1-Click Fast Bypass for Maruf */}
                  <button
                    type="button"
                    onClick={() => handleQuickAuthorizedEmailLogin(emailInput)}
                    className="py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-amber-300 hover:text-amber-200 border border-amber-500/30 text-xs font-semibold transition flex items-center justify-center gap-1.5"
                    title={isBn ? 'পাসওয়ার্ড ছাড়া তৎক্ষণাৎ টেস্ট লগইন' : 'Immediate 1-Click Access for Authorized Email'}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isBn ? '১-ক্লিক ডেমো এক্সেস' : '1-Click Demo'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 2: MARUF MASTER PIN/PASSWORD */}
          {activeTab === 'maruf' && (
            <div className="mt-5 space-y-4">
              <div className="p-3.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs text-emerald-200 flex items-start gap-3">
                <div className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 shrink-0 mt-0.5">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-bold text-white mb-0.5">
                    {isBn ? 'ভল্ট প্রধান: হাবিবুর রহমান (মারুফ)' : 'Vault Master: Habibur Rahman (Maruf)'}
                  </p>
                  <p className="text-[11px] text-emerald-300/80 leading-relaxed">
                    {isBn 
                      ? 'মাস্টার পাসওয়ার্ড বা পিন কোড দিয়ে সম্পূর্ণ প্রশাসনিক নিয়ন্ত্রণ ও অডিট ট্রেইল আনলক করুন।'
                      : 'Unlock full administrative control & audit trails using Master Password or PIN.'}
                  </p>
                </div>
              </div>

              <form onSubmit={handleMarufLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    {isBn ? 'মাস্টার পাসওয়ার্ড / পিন' : 'Master Password / PIN'}
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder={isBn ? 'যেমন: maruf123 বা 1985' : 'e.g. maruf123 or 1985'}
                      className="w-full pl-4 pr-11 py-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500 text-xs"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-200"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  {errorMsg && (
                    <p className="text-xs text-rose-400 mt-1.5 flex items-center gap-1 font-medium">
                      <ShieldAlert className="w-3.5 h-3.5" />
                      <span>{errorMsg}</span>
                    </p>
                  )}
                </div>

                <div className="pt-1 flex flex-col gap-2">
                  <button
                    type="submit"
                    className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 hover:from-emerald-500 to-teal-600 hover:to-teal-500 text-white font-bold text-xs transition shadow-lg flex items-center justify-center gap-2"
                  >
                    <Unlock className="w-4 h-4" />
                    <span>{isBn ? 'মারুফ হিসেবে আনলক করুন' : 'Unlock as Maruf (Admin)'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      soundEffects.playUnlock(soundEnabled);
                      soundEffects.playSuccess(soundEnabled);
                      onLoginSuccess('maruf', 'Admin', 'habiburmaruf@gmail.com');
                    }}
                    className="w-full py-2 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-750 text-emerald-400 hover:text-emerald-300 border border-emerald-500/30 text-xs font-semibold transition flex items-center justify-center gap-2"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>{isBn ? '১-ক্লিকে টেস্ট লগইন (ডেমো এক্সেস)' : '1-Click Quick Demo Login'}</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 3: FAMILY MEMBER LOGIN */}
          {activeTab === 'family' && (
            <div className="mt-5 space-y-4">
              <div className="p-3.5 rounded-2xl bg-blue-950/40 border border-blue-500/30 text-xs text-blue-200">
                <p className="font-bold text-white mb-0.5">
                  {isBn ? 'পারিবারিক সদস্য এক্সেস পোর্টাল' : 'Family Member Portal'}
                </p>
                <p className="text-[11px] text-blue-300/80 leading-relaxed">
                  {isBn 
                    ? 'আপনার প্রোফাইল নির্বাচন করে নির্ধারিত ভূমিকা (Editor বা Viewer) হিসেবে প্রবেশ করুন।'
                    : 'Select your family member profile and enter with your designated RBAC role.'}
                </p>
              </div>

              <form onSubmit={handleFamilyLogin} className="space-y-3.5">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'পারিবারিক সদস্য নির্বাচন করুন' : 'Select Family Member'}
                  </label>
                  <select
                    value={selectedMemberId}
                    onChange={(e) => setSelectedMemberId(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white focus:outline-none focus:border-blue-500 text-xs"
                  >
                    {selectableMembers.map((m) => (
                      <option key={m.id} value={m.id}>
                        {isBn ? m.nameBn : m.nameEn} ({m.systemRole} - {isBn ? m.roleBn : m.roleEn})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'পারিবারিক পিন (ডিফল্ট: 1234)' : 'Family PIN (Default: 1234)'}
                  </label>
                  <input
                    type="password"
                    value={familyPin}
                    onChange={(e) => setFamilyPin(e.target.value)}
                    className="w-full p-2.5 rounded-xl bg-slate-950/80 border border-slate-700 text-white text-xs focus:outline-none focus:border-blue-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-blue-600 hover:from-blue-500 to-indigo-600 hover:to-indigo-500 text-white font-bold text-xs transition shadow-lg flex items-center justify-center gap-2"
                >
                  <Unlock className="w-4 h-4" />
                  <span>{isBn ? 'সদস্য হিসেবে প্রবেশ করুন' : 'Login as Family Member'}</span>
                </button>
              </form>
            </div>
          )}

          {/* TAB 4: RESTRICTED VISITOR GATE */}
          {activeTab === 'visitor' && (
            <div className="mt-5 space-y-4">
              <div className="p-4 rounded-2xl bg-amber-950/30 border border-amber-500/40 text-xs text-amber-200 space-y-2">
                <div className="flex items-center gap-2 font-bold text-amber-300">
                  <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
                  <span>{isBn ? 'কঠোর নিরাপত্তা নীতি ও ভিজিটর কোয়ারেন্টাইন' : 'Visitor Policy & Strict Quarantine'}</span>
                </div>
                <p className="text-[11px] text-amber-200/90 leading-relaxed">
                  {isBn 
                    ? '⚠️ যে কোনো বহিরাগত বা অননুমোদিত ভিজিটর সরাসরি ভল্টে কোনো দলিল বা তথ্য প্রকাশ করতে পারবে না। আপনার কোনো অনুরোধ বা আপলোড থাকলে তা মারুফের রিভিউ কিউ-তে জমা হবে।'
                    : '⚠️ Visitors are strictly restricted from publishing any data directly. Any query or upload is quarantined for Maruf\'s cryptographic review.'}
                </p>
              </div>

              <button
                onClick={handleVisitorLogin}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-750 text-amber-300 hover:text-white border border-amber-500/30 font-bold text-xs transition shadow-md flex items-center justify-center gap-2"
              >
                <ArrowRight className="w-4 h-4" />
                <span>{isBn ? 'সীমাবদ্ধ দর্শক হিসেবে ব্রাউজ করুন (Guest Mode)' : 'Browse as Restricted Viewer (Guest)'}</span>
              </button>
            </div>
          )}

          {/* Bottom Security Assurance */}
          <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
            <span className="flex items-center gap-1.5 text-amber-400/90 font-mono">
              <Flame className="w-3.5 h-3.5" />
              <span>Firebase Auth & Firestore</span>
            </span>
            <span className="flex items-center gap-1.5 text-teal-400">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Role-Based Isolation (RBAC)</span>
            </span>
          </div>

        </div>

      </div>

    </div>
  );
};
