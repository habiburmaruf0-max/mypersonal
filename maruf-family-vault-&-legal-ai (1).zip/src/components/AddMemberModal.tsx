import React, { useState } from 'react';
import { X, UserPlus, Sparkles } from 'lucide-react';
import { FamilyMember, Language, BranchCategory, UserRole } from '../types/family';

interface AddMemberModalProps {
  language: Language;
  onClose: () => void;
  onAddMember: (member: FamilyMember) => void;
}

export const AddMemberModal: React.FC<AddMemberModalProps> = ({
  language,
  onClose,
  onAddMember,
}) => {
  const isBn = language === 'bn';
  const [nameBn, setNameBn] = useState('');
  const [nameEn, setNameEn] = useState('');
  const [roleBn, setRoleBn] = useState('');
  const [roleEn, setRoleEn] = useState('');
  const [systemRole, setSystemRole] = useState<UserRole>('Viewer');
  const [branch, setBranch] = useState<BranchCategory>('maruf');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [phone, setPhone] = useState('');
  const [bloodGroup, setBloodGroup] = useState('B+');
  const [occupationBn, setOccupationBn] = useState('');
  const [notesBn, setNotesBn] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameBn) return;

    const newMember: FamilyMember = {
      id: `member-${Date.now()}`,
      nameBn,
      nameEn: nameEn || nameBn,
      roleBn: roleBn || (isBn ? 'সদস্য' : 'Member'),
      roleEn: roleEn || roleBn || 'Family Member',
      systemRole,
      branch,
      generation: branch === 'parents' ? 1 : 3,
      gender,
      phone,
      bloodGroup,
      occupationBn,
      notesBn,
      avatarColor: gender === 'male' ? 'bg-blue-700 text-blue-100' : 'bg-pink-700 text-pink-100',
      relationships: {},
      documentCount: 0,
    };

    onAddMember(newMember);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-700 p-6 sm:p-8 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="space-y-1">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <UserPlus className="w-5 h-5 text-emerald-400" />
            <span>{isBn ? 'নতুন পারিবারিক সদস্য যোগ করুন' : 'Add New Family Member'}</span>
          </h3>
          <p className="text-xs text-slate-400">
            {isBn ? 'মারুফের পরিবারের ডিরেক্টরি ও পোর্টালে নতুন সদস্য অন্তর্ভুক্ত করুন।' : 'Add a new member to Maruf family directory.'}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'নাম (বাংলা)' : 'Name (Bangla)'}
              </label>
              <input
                type="text"
                value={nameBn}
                onChange={(e) => setNameBn(e.target.value)}
                placeholder="যেমন: তানভীর"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'নাম (English)' : 'Name (English)'}
              </label>
              <input
                type="text"
                value={nameEn}
                onChange={(e) => setNameEn(e.target.value)}
                placeholder="e.g. Tanvir"
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'পারিবারিক শাখা' : 'Family Branch'}
              </label>
              <select
                value={branch}
                onChange={(e: any) => setBranch(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="maruf">{isBn ? 'মারুফের পরিবার' : "Maruf's Family"}</option>
                <option value="omar_faruque">{isBn ? 'বড় ভাই ওমর ফারুক' : 'Omar Faruque'}</option>
                <option value="abdul_kader">{isBn ? 'মেজো ভাই আব্দুল কাদের' : 'Abdul Kader'}</option>
                <option value="farjana">{isBn ? 'ছোট বোন ফারজানা' : 'Farjana Hossain'}</option>
                <option value="in_laws">{isBn ? 'আত্মীয়স্বজন' : 'In-Laws'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'সম্পর্ক / পদবি' : 'Role / Relation'}
              </label>
              <input
                type="text"
                value={roleBn}
                onChange={(e) => setRoleBn(e.target.value)}
                placeholder={isBn ? 'যেমন: পুত্র / কন্যা / ভাতিজা' : 'e.g. Son, Daughter'}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'সিস্টেম ভূমিকা (RBAC)' : 'System Role'}
              </label>
              <select
                value={systemRole}
                onChange={(e: any) => setSystemRole(e.target.value as UserRole)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-emerald-400 font-bold text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="Viewer">Viewer (শুধুমাত্র প্রদর্শন)</option>
                <option value="Editor">Editor (যোগ ও সম্পাদনা)</option>
                <option value="Admin">Admin (পূর্ণ নিয়ন্ত্রণ)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'লিঙ্গ' : 'Gender'}
              </label>
              <select
                value={gender}
                onChange={(e: any) => setGender(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="male">{isBn ? 'পুরুষ' : 'Male'}</option>
                <option value="female">{isBn ? 'মহিলা' : 'Female'}</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'রক্তের গ্রুপ' : 'Blood Group'}
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="A+">A+</option>
                <option value="B+">B+</option>
                <option value="O+">O+</option>
                <option value="AB+">AB+</option>
                <option value="A-">A-</option>
                <option value="B-">B-</option>
                <option value="O-">O-</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                {isBn ? 'মোবাইল নম্বর' : 'Phone'}
              </label>
              <input
                type="text"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+880 1..."
                className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-300 mb-1">
              {isBn ? 'পেশা' : 'Occupation'}
            </label>
            <input
              type="text"
              value={occupationBn}
              onChange={(e) => setOccupationBn(e.target.value)}
              placeholder={isBn ? 'যেমন: সফটওয়্যার ইঞ্জিনিয়ার / শিক্ষার্থী' : 'e.g. Student'}
              className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
            >
              {isBn ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
            >
              {isBn ? 'সদস্য সংরক্ষণ করুন' : 'Save Member'}
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
