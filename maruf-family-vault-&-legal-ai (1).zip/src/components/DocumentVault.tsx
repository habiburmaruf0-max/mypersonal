import React, { useState, useRef } from 'react';
import { 
  FolderLock, 
  Search, 
  Plus, 
  ShieldCheck, 
  AlertTriangle, 
  Calendar, 
  Download, 
  Eye, 
  Lock, 
  Filter, 
  FileText, 
  RefreshCw,
  CheckCircle2,
  Clock,
  Sparkles,
  Server,
  Upload,
  FileSpreadsheet,
  FileCode,
  Image as ImageIcon,
  Film,
  Music,
  Archive,
  Compass,
  FileCheck,
  File,
  X,
  Trash2,
  Send,
  LockKeyhole,
  Check
} from 'lucide-react';
import { VaultDocument, Language, FamilyMember, UserRole, SupportedFileType } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface DocumentVaultProps {
  documents: VaultDocument[];
  members: FamilyMember[];
  language: Language;
  userRole: UserRole;
  soundEnabled?: boolean;
  onAddDocument: (doc: VaultDocument) => void;
  onDeleteDocument?: (id: string) => void;
  onRequestUpload?: () => void;
  isAdminLoggedIn: boolean;
}

export const DocumentVault: React.FC<DocumentVaultProps> = ({
  documents,
  members,
  language,
  userRole,
  soundEnabled = true,
  onAddDocument,
  onDeleteDocument,
  onRequestUpload,
  isAdminLoggedIn,
}) => {
  const isBn = language === 'bn';
  const canAdd = userRole === 'Admin' || userRole === 'Editor';
  const canDelete = userRole === 'Admin';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedFormat, setSelectedFormat] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [cronReport, setCronReport] = useState<any | null>(null);
  const [isCheckingCron, setIsCheckingCron] = useState(false);
  const [previewDoc, setPreviewDoc] = useState<VaultDocument | null>(null);
  const [downloadSuccessToast, setDownloadSuccessToast] = useState<string | null>(null);

  // New Document Form State
  const [newTitleBn, setNewTitleBn] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newCategory, setNewCategory] = useState<VaultDocument['category']>('land');
  const [newMemberId, setNewMemberId] = useState('');
  const [newDocNumber, setNewDocNumber] = useState('');
  const [newExpiryDate, setNewExpiryDate] = useState('');
  const [newNotesBn, setNewNotesBn] = useState('');
  const [uploadedFile, setUploadedFile] = useState<{
    name: string;
    size: string;
    type: SupportedFileType;
    dataUrl?: string;
    extension?: string;
  } | null>(null);

  // Helper to detect file type from extension/mime
  const detectFileType = (fileName: string, mimeType?: string): SupportedFileType => {
    const ext = fileName.split('.').pop()?.toLowerCase() || '';
    if (ext === 'pdf') return 'pdf';
    if (['doc', 'docx'].includes(ext)) return 'docx';
    if (['xls', 'xlsx', 'csv'].includes(ext)) return 'xlsx';
    if (['ppt', 'pptx'].includes(ext)) return 'pptx';
    if (['jpg', 'jpeg', 'png', 'webp', 'svg', 'gif'].includes(ext)) return 'image';
    if (['mp4', 'mov', 'mkv', 'avi'].includes(ext)) return 'video';
    if (['mp3', 'wav', 'm4a', 'aac'].includes(ext)) return 'audio';
    if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) return 'archive';
    if (['txt', 'md', 'rtf'].includes(ext)) return 'text';
    if (['json', 'xml', 'html', 'js', 'ts'].includes(ext)) return 'json';
    if (['dwg', 'dxf', 'kml', 'geojson'].includes(ext)) return 'cad';
    if (fileName.toLowerCase().includes('deed') || fileName.toLowerCase().includes('দলিল')) return 'deed';
    return 'other';
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    soundEffects.playClick(soundEnabled);
    const ext = file.name.split('.').pop()?.toUpperCase() || 'FILE';
    const type = detectFileType(file.name, file.type);
    const sizeStr = file.size > 1024 * 1024 
      ? `${(file.size / (1024 * 1024)).toFixed(1)} MB` 
      : `${Math.round(file.size / 1024)} KB`;

    const reader = new FileReader();
    reader.onload = () => {
      setUploadedFile({
        name: file.name,
        size: sizeStr,
        type,
        extension: ext,
        dataUrl: reader.result as string,
      });
      if (!newTitleBn) {
        setNewTitleBn(file.name.replace(/\.[^/.]+$/, ''));
      }
    };
    reader.readAsDataURL(file);
  };

  // Calculate days left
  const getDaysLeft = (expiryDate?: string) => {
    if (!expiryDate) return null;
    const exp = new Date(expiryDate).getTime();
    const now = new Date().getTime();
    return Math.ceil((exp - now) / (1000 * 60 * 60 * 24));
  };

  // Get format visual styling and icon
  const getFormatDetails = (type: SupportedFileType) => {
    switch (type) {
      case 'pdf':
        return { icon: FileText, color: 'text-rose-400 bg-rose-500/15 border-rose-500/30', label: 'PDF' };
      case 'doc':
      case 'docx':
        return { icon: FileText, color: 'text-blue-400 bg-blue-500/15 border-blue-500/30', label: 'Word (DOCX)' };
      case 'xls':
      case 'xlsx':
        return { icon: FileSpreadsheet, color: 'text-emerald-400 bg-emerald-500/15 border-emerald-500/30', label: 'Excel (XLSX)' };
      case 'ppt':
      case 'pptx':
        return { icon: FileText, color: 'text-amber-400 bg-amber-500/15 border-amber-500/30', label: 'PowerPoint' };
      case 'image':
        return { icon: ImageIcon, color: 'text-purple-400 bg-purple-500/15 border-purple-500/30', label: 'Image' };
      case 'video':
        return { icon: Film, color: 'text-indigo-400 bg-indigo-500/15 border-indigo-500/30', label: 'Video' };
      case 'audio':
        return { icon: Music, color: 'text-pink-400 bg-pink-500/15 border-pink-500/30', label: 'Audio' };
      case 'archive':
        return { icon: Archive, color: 'text-orange-400 bg-orange-500/15 border-orange-500/30', label: 'Archive (ZIP)' };
      case 'cad':
        return { icon: Compass, color: 'text-teal-400 bg-teal-500/15 border-teal-500/30', label: 'CAD / Map' };
      case 'deed':
        return { icon: FileCheck, color: 'text-teal-400 bg-teal-500/15 border-teal-500/30', label: 'Deed / দলিল' };
      case 'json':
        return { icon: FileCode, color: 'text-cyan-400 bg-cyan-500/15 border-cyan-500/30', label: 'Data / JSON' };
      default:
        return { icon: File, color: 'text-slate-400 bg-slate-500/15 border-slate-500/30', label: 'Document' };
    }
  };

  // Filter documents
  const filteredDocs = documents.filter((doc) => {
    const matchesCat = selectedCategory === 'all' || doc.category === selectedCategory;
    const matchesFmt = selectedFormat === 'all' || doc.fileType === selectedFormat;
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = 
      !query ||
      doc.titleBn.toLowerCase().includes(query) ||
      doc.titleEn.toLowerCase().includes(query) ||
      (doc.memberNameBn && doc.memberNameBn.toLowerCase().includes(query)) ||
      (doc.documentNumber && doc.documentNumber.toLowerCase().includes(query));

    return matchesCat && matchesFmt && matchesQuery;
  });

  const handleCreateDocument = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleBn) return;

    soundEffects.playSuccess(soundEnabled);
    const assignedMember = members.find((m) => m.id === newMemberId);

    const newDoc: VaultDocument = {
      id: `doc-${Date.now()}`,
      titleBn: newTitleBn,
      titleEn: newTitleEn || newTitleBn,
      category: newCategory,
      memberId: newMemberId || undefined,
      memberNameBn: assignedMember?.nameBn,
      memberNameEn: assignedMember?.nameEn,
      documentNumber: newDocNumber || `DOC-${Math.floor(100000 + Math.random() * 900000)}`,
      issueDate: new Date().toISOString().split('T')[0],
      expiryDate: newExpiryDate || undefined,
      fileType: uploadedFile?.type || 'pdf',
      fileSize: uploadedFile?.size || `${(Math.random() * 2 + 0.5).toFixed(1)} MB`,
      originalFileName: uploadedFile?.name,
      fileExtension: uploadedFile?.extension,
      previewUrl: uploadedFile?.dataUrl,
      isEncrypted: true,
      encryptionHash: `AES256:${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
      notesBn: newNotesBn,
      verified: true,
    };

    onAddDocument(newDoc);
    setIsAddModalOpen(false);
    // Reset
    setNewTitleBn('');
    setNewTitleEn('');
    setNewCategory('land');
    setNewMemberId('');
    setNewDocNumber('');
    setNewExpiryDate('');
    setNewNotesBn('');
    setUploadedFile(null);
  };

  // Run live check on /api/cron/check-expiry
  const handleRunCronCheck = async () => {
    setIsCheckingCron(true);
    soundEffects.playCyberPulse(soundEnabled);
    try {
      const res = await fetch('/api/cron/check-expiry');
      const data = await res.json();
      setCronReport(data);
      soundEffects.playSuccess(soundEnabled);
    } catch (e: any) {
      setCronReport({ error: e.message });
    } finally {
      setIsCheckingCron(false);
    }
  };

  const handleDownload = (doc: VaultDocument) => {
    soundEffects.playClick(soundEnabled);
    if (doc.previewUrl) {
      const link = document.createElement('a');
      link.href = doc.previewUrl;
      link.download = doc.originalFileName || `${doc.titleEn || doc.titleBn}.${doc.fileType}`;
      link.click();
    }
    const msg = isBn 
      ? `"${doc.titleBn}" ডিক্রিপ্ট করা হয়েছে। ডাউনলোড শুরু হয়েছে।` 
      : `Decrypted "${doc.titleEn}". Download initiated.`;
    setDownloadSuccessToast(msg);
    setTimeout(() => setDownloadSuccessToast(null), 3000);
  };

  const handleDelete = (doc: VaultDocument) => {
    if (!onDeleteDocument) return;
    const confirmMsg = isBn ? `আপনি কি নিশ্চিতভাবে "${doc.titleBn}" ভল্ট থেকে মুছে ফেলতে চান?` : `Are you sure you want to delete "${doc.titleEn}"?`;
    if (window.confirm(confirmMsg)) {
      soundEffects.playClick(soundEnabled);
      onDeleteDocument(doc.id);
    }
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Toast Notification */}
      {downloadSuccessToast && (
        <div className="fixed bottom-6 right-6 z-50 p-4 rounded-2xl bg-emerald-950 border border-emerald-500 text-white text-xs font-bold shadow-2xl flex items-center gap-2 animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{downloadSuccessToast}</span>
        </div>
      )}

      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-slate-850 to-emerald-950 border border-slate-700/60 p-6 sm:p-8 shadow-xl">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-xs font-bold uppercase tracking-wider">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isBn ? 'সামরিক মানের AES-256 এনক্রিপ্টেড ভল্ট' : 'Military-Grade AES-256 Vault'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'পারিবারিক ডিজিটাল ডকুমেন্ট ও দলিল ভল্ট' : 'Family Digital Document & Deed Vault'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              {isBn 
                ? 'পৈতৃক জমি-জমার কবলা, বায়া দলিল, আরএস/সিএস পর্চা, স্মার্ট এনআইডি, পাসপোর্ট, ওয়ারিশ সনদ ও ব্যাংক রেকর্ড। সকল ফরম্যাট (PDF, Word, Excel, Images, ZIP, CAD) সম্পূর্ণ সুরক্ষিত।' 
                : 'All format documents (PDF, Word, Excel, Images, Deeds, CAD) preserved with automated expiry warnings.'}
            </p>
          </div>

          {/* Action buttons */}
          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {canAdd ? (
              <button
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  setIsAddModalOpen(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition hover:scale-[1.02] active:scale-[0.98]"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'যেকোনো ফাইল আপলোড করুন' : 'Upload Any File'}</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  if (onRequestUpload) onRequestUpload();
                }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-950/40 transition"
              >
                <Send className="w-4 h-4" />
                <span>{isBn ? 'দলিল জমার অনুরোধ পাঠান' : 'Request Upload Approval'}</span>
              </button>
            )}

            <button
              onClick={handleRunCronCheck}
              disabled={isCheckingCron}
              className="flex items-center gap-2 px-3.5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 text-xs font-semibold transition"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isCheckingCron ? 'animate-spin text-emerald-400' : ''}`} />
              <span className="hidden sm:inline">{isBn ? 'মেয়াদ চেক' : 'Check Expiry'}</span>
            </button>
          </div>
        </div>

        {/* Ambient background decoration */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Cron Report Notification if run */}
      {cronReport && (
        <div className="p-4 rounded-2xl bg-slate-850 border border-emerald-500/40 shadow-lg flex items-start justify-between gap-3 animate-fade-in">
          <div className="flex items-start gap-3">
            <Server className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-white">
                {isBn ? 'Vercel ক্রন রুট ফলাফল: মেয়াদ ট্র্যাকিং সক্রিয়' : 'Cron Job Expiry Check Completed'}
              </h4>
              <p className="text-[11px] text-slate-300">
                {cronReport.checkedCount ? (
                  isBn 
                    ? `মোট ${cronReport.checkedCount}টি দলিল স্ক্যান করা হয়েছে। ${cronReport.alertsTriggered}টি অ্যালার্ট সক্রিয়।`
                    : `Scanned ${cronReport.checkedCount} documents. ${cronReport.alertsTriggered} alerts active.`
                ) : JSON.stringify(cronReport)}
              </p>
            </div>
          </div>
          <button onClick={() => setCronReport(null)} className="text-slate-400 hover:text-white text-xs">
            ✕
          </button>
        </div>
      )}

      {/* Search and Category Filter Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isBn ? 'দলিলের নাম, নম্বর, মালিকের নাম বা ফাইল টাইপ অনুসন্ধান...' : 'Search document title, number, owner...'}
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-850 border border-slate-700/80 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <span className="text-xs text-slate-400 shrink-0 self-center">
            {isBn ? `মোট ${filteredDocs.length}টি ফাইল সংরক্ষিত` : `${filteredDocs.length} files in vault`}
          </span>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {[
            { id: 'all', labelBn: 'সকল ফাইল', labelEn: 'All Files' },
            { id: 'land', labelBn: 'জমি ও পর্চা', labelEn: 'Land Deeds & Khatians' },
            { id: 'identity', labelBn: 'এনআইডি ও পাসপোর্ট', labelEn: 'Identity & Passports' },
            { id: 'inheritance', labelBn: 'ওয়ারিশ ও বণ্টননামা', labelEn: 'Inheritance & Sanad' },
            { id: 'financial', labelBn: 'ব্যাংক ও আর্থিক', labelEn: 'Financial & Bank' },
            { id: 'multimedia', labelBn: 'অডিও/ভিডিও/ছবি', labelEn: 'Multimedia' },
            { id: 'internet_archive', labelBn: 'ইন্টারনেট আর্কাইভ', labelEn: 'Web Archive' },
            { id: 'academic', labelBn: 'শিক্ষাগত ও অন্যান্য', labelEn: 'Academic & Other' },
          ].map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setSelectedCategory(cat.id);
              }}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition ${
                selectedCategory === cat.id
                  ? 'bg-emerald-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {isBn ? cat.labelBn : cat.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Documents Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDocs.map((doc) => {
          const daysLeft = getDaysLeft(doc.expiryDate);
          const isUrgent = daysLeft !== null && daysLeft <= 7 && daysLeft >= 0;
          const isWarning = daysLeft !== null && daysLeft <= 30 && daysLeft > 7;
          const formatDetails = getFormatDetails(doc.fileType);
          const FormatIcon = formatDetails.icon;

          return (
            <div
              key={doc.id}
              className={`p-5 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                isUrgent
                  ? 'bg-rose-950/20 border-rose-700/60 hover:border-rose-500 shadow-lg shadow-rose-950/20'
                  : isWarning
                  ? 'bg-amber-950/20 border-amber-700/60 hover:border-amber-500 shadow-lg shadow-amber-950/20'
                  : 'bg-slate-850 border-slate-700/60 hover:border-slate-600 shadow'
              }`}
            >
              <div>
                {/* Header & Badges */}
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className={`p-3 rounded-2xl border ${formatDetails.color}`}>
                    <FormatIcon className="w-5 h-5" />
                  </div>
                  
                  {/* Expiry Badge */}
                  {daysLeft !== null ? (
                    isUrgent ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold animate-pulse">
                        <AlertTriangle className="w-3 h-3" />
                        <span>{isBn ? `${daysLeft} দিন বাকি (জরুরি)` : `${daysLeft}d left (Urgent)`}</span>
                      </span>
                    ) : isWarning ? (
                      <span className="flex items-center gap-1 px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-bold">
                        <Clock className="w-3 h-3" />
                        <span>{isBn ? `${daysLeft} দিন বাকি` : `${daysLeft}d left`}</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-full bg-slate-700 text-slate-300 text-[10px] font-medium">
                        {isBn ? `মেয়াদ: ${doc.expiryDate}` : `Exp: ${doc.expiryDate}`}
                      </span>
                    )
                  ) : (
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                      {isBn ? 'স্থায়ী রেকর্ড' : 'Permanent'}
                    </span>
                  )}
                </div>

                {/* Title & Format pill */}
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-400 border border-slate-700">
                    {formatDetails.label}
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    {doc.fileSize}
                  </span>
                </div>

                <h3 className="font-bold text-sm text-white leading-snug">
                  {isBn ? doc.titleBn : doc.titleEn}
                </h3>
                <p className="text-xs text-slate-400 mt-1 font-mono">
                  {doc.documentNumber}
                </p>

                {doc.memberNameBn && (
                  <div className="mt-2 text-xs text-slate-300 font-medium">
                    👤 {isBn ? doc.memberNameBn : doc.memberNameEn}
                  </div>
                )}

                {doc.notesBn && (
                  <p className="text-[11px] text-slate-400 italic mt-2 line-clamp-2">
                    {isBn ? doc.notesBn : doc.notesEn}
                  </p>
                )}
              </div>

              {/* Card Footer: Preview, Encryption & Download */}
              <div className="mt-4 pt-3 border-t border-slate-700/50 flex items-center justify-between text-xs gap-1">
                <div className="flex items-center gap-1 text-slate-400">
                  <Lock className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span className="text-[10px] font-mono truncate max-w-[80px]">{doc.encryptionHash}</span>
                </div>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => {
                      soundEffects.playClick(soundEnabled);
                      setPreviewDoc(doc);
                    }}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white transition"
                    title={isBn ? 'প্রিভিউ দেখুন' : 'Preview Document'}
                  >
                    <Eye className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleDownload(doc)}
                    className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-200 hover:text-white transition text-xs font-semibold"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>{isBn ? 'ডাউনলোড' : 'Download'}</span>
                  </button>

                  {canDelete && (
                    <button
                      onClick={() => handleDelete(doc)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-600 text-slate-400 hover:text-white transition"
                      title={isBn ? 'মুছে ফেলুন' : 'Delete'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Document Preview Modal */}
      {previewDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <FolderLock className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {isBn ? previewDoc.titleBn : previewDoc.titleEn}
                  </h3>
                  <p className="text-xs text-slate-400 font-mono">{previewDoc.documentNumber}</p>
                </div>
              </div>
              <button
                onClick={() => setPreviewDoc(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Decryption status header */}
            <div className="p-3 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 flex items-center justify-between text-xs">
              <div className="flex items-center gap-2 text-emerald-300">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>{isBn ? 'নিরাপদ ডিক্রিপশন সম্পন্ন (AES-256 Validated)' : 'Decrypted Securely with AES-256 Key'}</span>
              </div>
              <span className="font-mono text-[10px] text-slate-400">{previewDoc.encryptionHash}</span>
            </div>

            {/* Render Preview by file format */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 min-h-[160px] flex flex-col items-center justify-center text-center">
              {previewDoc.previewUrl && previewDoc.fileType === 'image' ? (
                <img
                  src={previewDoc.previewUrl}
                  alt={previewDoc.titleEn}
                  className="max-h-[350px] w-auto rounded-xl object-contain shadow"
                />
              ) : previewDoc.fileType === 'audio' ? (
                <div className="w-full space-y-3 p-4">
                  <Music className="w-8 h-8 text-pink-400 mx-auto" />
                  <p className="text-xs text-slate-300">{previewDoc.titleBn}</p>
                  <audio controls className="w-full">
                    {previewDoc.previewUrl && <source src={previewDoc.previewUrl} />}
                    Your browser does not support audio.
                  </audio>
                </div>
              ) : previewDoc.fileType === 'video' ? (
                <div className="w-full space-y-3">
                  <video controls className="w-full max-h-[300px] rounded-xl">
                    {previewDoc.previewUrl && <source src={previewDoc.previewUrl} />}
                    Your browser does not support video.
                  </video>
                </div>
              ) : (
                <div className="space-y-3 py-6">
                  <FileText className="w-12 h-12 text-teal-400 mx-auto" />
                  <div className="space-y-1">
                    <p className="text-sm font-bold text-white">
                      {previewDoc.originalFileName || `${previewDoc.titleEn}.${previewDoc.fileType}`}
                    </p>
                    <p className="text-xs text-slate-400">
                      {isBn ? `ফাইলের আকার: ${previewDoc.fileSize} | ফরম্যাট: ${previewDoc.fileType.toUpperCase()}` : `Size: ${previewDoc.fileSize} | Format: ${previewDoc.fileType.toUpperCase()}`}
                    </p>
                  </div>
                  <p className="text-[11px] text-slate-400 max-w-md mx-auto">
                    {isBn 
                      ? 'অফিসিয়াল সিল ও কিউআর যাচাইকৃত এনক্রিপ্টেড কপি। সম্পূর্ণ ফাইল দেখতে ডাউনলোড অপশন ব্যবহার করুন।' 
                      : 'Encrypted master record with cryptographic hash verification.'}
                  </p>
                </div>
              )}
            </div>

            {/* Details Meta */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">{isBn ? 'ইস্যু তারিখ' : 'Issue Date'}</span>
                <span className="font-semibold text-white">{previewDoc.issueDate || 'N/A'}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">{isBn ? 'মেয়াদ উত্তীর্ণ' : 'Expiry Date'}</span>
                <span className="font-semibold text-white">{previewDoc.expiryDate || (isBn ? 'স্থায়ী' : 'Permanent')}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-800/60 border border-slate-700/60">
                <span className="text-[10px] text-slate-400 block">{isBn ? 'সংশ্লিষ্ট সদস্য' : 'Family Member'}</span>
                <span className="font-semibold text-white">{previewDoc.memberNameBn || 'পারিবারিক এস্টেট'}</span>
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="flex items-center justify-between pt-2">
              <button
                onClick={() => setPreviewDoc(null)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold"
              >
                {isBn ? 'বন্ধ করুন' : 'Close'}
              </button>
              <button
                onClick={() => handleDownload(previewDoc)}
                className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition"
              >
                <Download className="w-4 h-4" />
                <span>{isBn ? 'ফাইল ডাউনলোড করুন' : 'Download Master File'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Document Modal (Supports ALL Formats) */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <FolderLock className="w-5 h-5 text-emerald-400" />
                <span>{isBn ? 'ভল্টে নতুন ফাইল আপলোড (সকল ফরম্যাট)' : 'Upload Any File to Vault'}</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateDocument} className="space-y-3.5">
              
              {/* Universal File Selector Dropzone */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ফাইল নির্বাচন করুন (PDF, DOCX, XLSX, Images, ZIP, CAD)' : 'Select File (All Formats Supported)'}
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileUpload}
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-emerald-500 rounded-2xl p-4 bg-slate-800/40 hover:bg-slate-800/70 cursor-pointer transition text-center space-y-1"
                >
                  {uploadedFile ? (
                    <div className="flex items-center justify-between px-2">
                      <div className="flex items-center gap-2 text-left">
                        <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-white truncate max-w-[200px]">{uploadedFile.name}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{uploadedFile.size} • {uploadedFile.type.toUpperCase()}</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        {isBn ? 'রেডি' : 'Ready'}
                      </span>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-6 h-6 text-emerald-400 mx-auto" />
                      <p className="text-xs font-bold text-slate-200">
                        {isBn ? 'ফাইল নির্বাচন করতে ক্লিক করুন বা ড্রপ করুন' : 'Click to Browse or Drag File'}
                      </p>
                      <p className="text-[10px] text-slate-400">
                        PDF, Word (.docx), Excel (.xlsx), PPT, JPG, PNG, WEBP, ZIP, CAD
                      </p>
                    </>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'দলিল বা ফাইলের শিরোনাম (বাংলা) *' : 'Document Title (Bangla) *'}
                </label>
                <input
                  type="text"
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  placeholder="যেমন: পৈতৃক জমি কবলা দলিল / স্মার্ট এনআইডি"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'শিরোনাম (English)' : 'Title (English)'}
                </label>
                <input
                  type="text"
                  value={newTitleEn}
                  onChange={(e) => setNewTitleEn(e.target.value)}
                  placeholder="e.g., Ancestral Land Sale Deed"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e: any) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="land">{isBn ? 'জমি ও পর্চা' : 'Land & Khatian'}</option>
                    <option value="identity">{isBn ? 'এনআইডি ও পাসপোর্ট' : 'Identity & Passport'}</option>
                    <option value="inheritance">{isBn ? 'ওয়ারিশ ও বণ্টননামা' : 'Inheritance & Sanad'}</option>
                    <option value="financial">{isBn ? 'ব্যাংক ও আর্থিক' : 'Financial & Bank'}</option>
                    <option value="multimedia">{isBn ? 'মাল্টিমিডিয়া (ছবি/ভিডিও)' : 'Multimedia'}</option>
                    <option value="internet_archive">{isBn ? 'ইন্টারনেট আর্কাইভ' : 'Web Archive'}</option>
                    <option value="academic">{isBn ? 'অন্যান্য' : 'Other'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'সংশ্লিষ্ট সদস্য' : 'Assign to Member'}
                  </label>
                  <select
                    value={newMemberId}
                    onChange={(e) => setNewMemberId(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">{isBn ? '-- সার্বিক পারিবারিক এস্টেট --' : '-- Family Estate --'}</option>
                    {members
                      .filter((m) => !m.isPlaceholder)
                      .map((m) => (
                        <option key={m.id} value={m.id}>
                          {isBn ? m.nameBn : m.nameEn}
                        </option>
                      ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'দলিল/স্মার্ট নম্বর' : 'Doc/ID Number'}
                  </label>
                  <input
                    type="text"
                    value={newDocNumber}
                    onChange={(e) => setNewDocNumber(e.target.value)}
                    placeholder="e.g. DEED-88231 / NID"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'মেয়াদ উত্তীর্ণের তারিখ (ঐচ্ছিক)' : 'Expiry Date (Optional)'}
                  </label>
                  <input
                    type="date"
                    value={newExpiryDate}
                    onChange={(e) => setNewExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'সংক্ষিপ্ত নোট বা দাগ খতিয়ান হিস্যা' : 'Notes & Plot Details'}
                </label>
                <textarea
                  value={newNotesBn}
                  onChange={(e) => setNewNotesBn(e.target.value)}
                  rows={2}
                  placeholder="যেমন: খতিয়ান নম্বর ১২৩, দাগ নম্বর ৪৫৬, সাব-রেজিস্ট্রি অফিসে নথিভুক্ত..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-emerald-500 outline-none resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg shadow-emerald-950/40"
                >
                  {isBn ? 'ভল্টে সংরক্ষণ করুন' : 'Save to Vault'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
