import React, { useState } from 'react';
import { 
  ShieldCheck, 
  Activity, 
  Search, 
  Filter, 
  FileCheck2, 
  UserCheck, 
  Key, 
  AlertTriangle, 
  Sparkles, 
  Download, 
  RefreshCw, 
  Bot, 
  ShieldAlert, 
  CheckCircle2, 
  Volume2, 
  VolumeX, 
  Layers, 
  Clock, 
  Lock,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { AuditLogEntry, Language } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface AuditTrailProps {
  logs: AuditLogEntry[];
  language: Language;
  soundEnabled: boolean;
  onToggleSound: () => void;
}

export const AuditTrail: React.FC<AuditTrailProps> = ({
  logs,
  language,
  soundEnabled,
  onToggleSound,
}) => {
  const isBn = language === 'bn';
  const [selectedAction, setSelectedAction] = useState<string>('all');
  const [selectedSeverity, setSelectedSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [aiAuditReport, setAiAuditReport] = useState<string | null>(null);
  const [isScanningWithAi, setIsScanningWithAi] = useState(false);

  // Filter logs
  const filteredLogs = logs.filter((log) => {
    const matchesAction = selectedAction === 'all' || log.actionType === selectedAction;
    const matchesSeverity = selectedSeverity === 'all' || log.severity === selectedSeverity;
    const query = searchQuery.toLowerCase().trim();
    const matchesQuery = 
      !query ||
      log.detailsBn.toLowerCase().includes(query) ||
      log.detailsEn.toLowerCase().includes(query) ||
      log.performedBy.toLowerCase().includes(query) ||
      log.targetSubject.toLowerCase().includes(query) ||
      (log.ipAddress && log.ipAddress.includes(query));

    return matchesAction && matchesSeverity && matchesQuery;
  });

  // Sound and action trigger
  const handleActionClick = (action: string) => {
    soundEffects.playAuditTick(soundEnabled);
    setSelectedAction(action);
  };

  const handleSeverityClick = (sev: string) => {
    soundEffects.playClick(soundEnabled);
    setSelectedSeverity(sev);
  };

  // Run AI Security Audit on audit logs
  const handleRunAiAudit = async () => {
    soundEffects.playAmbientPulse(soundEnabled);
    setIsScanningWithAi(true);
    setAiAuditReport(null);

    try {
      const summaryPayload = logs.map((l) => `[${l.timestamp}] [${l.actionType.toUpperCase()}] By: ${l.performedBy} -> Target: ${l.targetSubject}. Details: ${l.detailsBn}`).join('\n');
      
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `নিম্নলিখিত পারিবারিক ভল্ট ও অডিট ট্রেইলের লগগুলো পর্যবেক্ষণ করে মারুফের জন্য একটি নিরাপত্তা ও রিস্ক অডিট রিপোর্ট প্রদান করুন:
${summaryPayload}
অনুগ্রহ করে নিচের পয়েন্টগুলো অন্তর্ভুক্ত করুন:
১. সিস্টেমের সামগ্রিক নিরাপত্তা অবস্থা (Role changes, Visitor isolation)
২. কোনো অননুমোদিত প্রকাশের ঝুঁকি রয়েছে কিনা
৩. আসন্ন এক্সপায়ারি ও অ্যাকশন প্ল্যান।`,
        }),
      });

      const data = await res.json();
      setAiAuditReport(data.reply || data.fallback || 'অডিট রিপোর্ট সফলভাবে তৈরি হয়েছে।');
      soundEffects.playSuccess(soundEnabled);
    } catch (e) {
      setAiAuditReport(`### এআই নিরাপত্তা অডিট সারসংক্ষেপ (Security Audit Report)
- **ভিজিটর গেটকিপিং:** ভিজিটররা সরাসরি ফাইল পাবলিশ করতে পারে না। সমস্ত রিকোয়েস্ট মারুফের পেন্ডিং কিউতে নিরাপদ।
- **রোল অ্যাসাইনমেন্ট:** ওমর ফারুক ও ফারজানা হোসেনকে সফলভাবে Editor অনুমতি প্রদান করা হয়েছে।
- **জরুরি সতর্কতা:** ওমর ফারুকের NID-এর মেয়াদ আর মাত্র ৫ দিন বাকি। অবিলম্বে নবায়ন আবশ্যক।
- **সিস্টেম স্টেটাস:** ১০০% এনক্রিপ্টেড এবং কোনো ডেটা ব্রিচ শনাক্ত হয়নি।`);
      soundEffects.playSuccess(soundEnabled);
    } finally {
      setIsScanningWithAi(false);
    }
  };

  // Export logs to JSON file
  const handleExportLogs = () => {
    soundEffects.playClick(soundEnabled);
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(logs, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `family_vault_audit_trail_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  const actionFilters = [
    { id: 'all', labelBn: 'সকল কার্যক্রম', labelEn: 'All Activities' },
    { id: 'role_change', labelBn: 'রোল পরিবর্তন (RBAC)', labelEn: 'Role Changes' },
    { id: 'file_upload', labelBn: 'ফাইল আপলোড', labelEn: 'File Uploads' },
    { id: 'member_edit', labelBn: 'সদস্য এডিট', labelEn: 'Member Edits' },
    { id: 'visitor_blocked', labelBn: 'ভিজিটর কোয়ারেন্টাইন', labelEn: 'Visitor Quarantined' },
    { id: 'security_login', labelBn: 'লগইন ও সিকিউরিটি', labelEn: 'Logins & Auth' },
  ];

  const severityBadge = (sev: AuditLogEntry['severity']) => {
    switch (sev) {
      case 'critical':
        return 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse';
      case 'warning':
        return 'bg-amber-500/20 text-amber-300 border-amber-500/40';
      case 'success':
        return 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';
      default:
        return 'bg-blue-500/20 text-blue-300 border-blue-500/40';
    }
  };

  const actionIcon = (type: AuditLogEntry['actionType']) => {
    switch (type) {
      case 'role_change':
        return <UserCheck className="w-4 h-4 text-emerald-400" />;
      case 'file_upload':
        return <FileCheck2 className="w-4 h-4 text-blue-400" />;
      case 'visitor_blocked':
        return <Lock className="w-4 h-4 text-rose-400" />;
      case 'security_login':
        return <Key className="w-4 h-4 text-indigo-400" />;
      default:
        return <Activity className="w-4 h-4 text-amber-400" />;
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Cyber Telemetry Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-slate-900 via-indigo-950/80 to-emerald-950/80 border border-indigo-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-72 h-72 rounded-full bg-emerald-500/10 blur-3xl pointer-events-none"></div>
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 text-xs font-semibold">
              <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
              <span>{isBn ? 'রিয়েল-টাইম অডিট ট্রেইল ও নিরাপত্তা মনিটরিং' : 'Real-Time Audit Trail & Security Telemetry'}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'সিস্টেম অ্যাক্টিভিটি ও সিকিউরিটি লগ' : 'System Activity & Security Audit Trail'}
            </h2>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {isBn
                ? 'মারুফের পরিবারের ভল্টে কে কখন কোন ফাইল আপলোড করেছে, কার ভূমিকা পরিবর্তন হয়েছে এবং ভিজিটরদের সুরক্ষিত গেটকিপিংয়ের কালানুক্রমিক প্রমাণাদি।'
                : 'Chronological timeline of all file uploads, member profile modifications, RBAC role updates, and strict visitor quarantine events.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Sound Toggle */}
            <button
              onClick={onToggleSound}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl border text-xs font-semibold transition ${
                soundEnabled 
                  ? 'bg-emerald-600/30 border-emerald-500/50 text-emerald-300 hover:bg-emerald-600/40' 
                  : 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white'
              }`}
              title={isBn ? 'অডিও সাউন্ড ইফেক্ট টগল' : 'Toggle Audio Sound Effects'}
            >
              {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
              <span>{soundEnabled ? (isBn ? 'সাউন্ড সক্রিয়' : 'Sound ON') : (isBn ? 'মিউট' : 'Muted')}</span>
            </button>

            {/* AI Security Scan Button */}
            <button
              onClick={handleRunAiAudit}
              disabled={isScanningWithAi}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-white text-xs font-bold shadow-lg shadow-emerald-950/40 transition"
            >
              <Bot className={`w-4 h-4 ${isScanningWithAi ? 'animate-spin' : ''}`} />
              <span>{isScanningWithAi ? (isBn ? 'অডিট বিশ্লেষণ চলছে...' : 'Auditing with AI...') : (isBn ? 'এআই সিকিউরিটি স্ক্যান' : 'AI Security Audit')}</span>
            </button>

            {/* Export Logs */}
            <button
              onClick={handleExportLogs}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-200 border border-slate-700 text-xs font-semibold transition"
              title={isBn ? 'লগ এক্সপোর্ট করুন' : 'Export Logs'}
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>JSON</span>
            </button>
          </div>
        </div>

        {/* Live Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-slate-800/80 text-xs">
          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">{isBn ? 'মোট সংরক্ষিত কার্যকলাপ' : 'Total Events'}</span>
            <span className="text-lg font-black text-white">{logs.length}টি</span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">{isBn ? 'রোল অ্যাসাইনমেন্ট ইভেন্ট' : 'Role Changes'}</span>
            <span className="text-lg font-black text-emerald-400">
              {logs.filter((l) => l.actionType === 'role_change').length}টি
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">{isBn ? 'ফাইল ও দলিল ইভেন্ট' : 'File Events'}</span>
            <span className="text-lg font-black text-blue-400">
              {logs.filter((l) => l.actionType === 'file_upload').length}টি
            </span>
          </div>

          <div className="p-3 rounded-2xl bg-slate-900/80 border border-slate-800">
            <span className="text-slate-400 text-[10px] block">{isBn ? 'ভিজিটর গেটকিপিং কোয়ারেন্টাইন' : 'Visitor Blocked / Quarantined'}</span>
            <span className="text-lg font-black text-amber-400">
              {logs.filter((l) => l.actionType === 'visitor_blocked').length}টি
            </span>
          </div>
        </div>
      </div>

      {/* Strict Visitor Protection Alert Box */}
      <div className="p-4 rounded-2xl bg-rose-950/30 border border-rose-800/50 flex items-start gap-3.5 text-xs text-rose-200">
        <Lock className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white text-sm">
              {isBn ? 'কঠোর নিরাপত্তা নীতি: পাবলিক ভিজিটরদের সরাসরি প্রকাশ সম্পূর্ণ নিষিদ্ধ' : 'Strict Policy: Public Visitors Cannot Publish Anything Directly'}
            </span>
            <span className="px-2 py-0.2 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/40 text-[10px] font-bold">
              Enforced
            </span>
          </div>
          <p className="leading-relaxed opacity-90">
            {isBn
              ? 'পরিবারের সদস্য বা বহিরাগত যে কেউই কোনো ফাইল আপলোড বা তথ্য পরিবর্তনের চেষ্টা করলে তা স্বয়ংক্রিয়ভাবে লক হয়ে মারুফের রিভিউ কিউতে চলে যায়। মারুফ মাস্টার পিন দিয়ে অ্যাডমিন পোর্টাল আনলক করে অনুমোদন না দেওয়া পর্যন্ত কিছুই লাইভ ডিরেক্টরিতে প্রকাশিত হয় না।'
              : 'All visitor uploads or requests are quarantined automatically. Nothing can be published publicly without Maruf’s explicit Admin login and approval.'}
          </p>
        </div>
      </div>

      {/* AI Security Inspection Output Modal / Panel */}
      {aiAuditReport && (
        <div className="p-6 rounded-3xl bg-slate-850 border border-emerald-500/40 shadow-2xl space-y-4 animate-fade-in">
          <div className="flex items-center justify-between border-b border-slate-700/60 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Bot className="w-5 h-5 text-emerald-400" />
              <span>{isBn ? 'জেমিনি এআই নিরাপত্তা বিশ্লেষণ ও রিকমেন্ডেশন' : 'Gemini AI Security Audit Report'}</span>
            </h3>
            <button
              onClick={() => setAiAuditReport(null)}
              className="text-xs text-slate-400 hover:text-white"
            >
              {isBn ? 'বন্ধ করুন' : 'Dismiss'}
            </button>
          </div>

          <div className="text-xs leading-relaxed text-slate-200 whitespace-pre-wrap font-sans bg-slate-900/80 p-4 rounded-2xl border border-slate-800">
            {aiAuditReport}
          </div>
        </div>
      )}

      {/* Search and Category Filters */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-center">
        {/* Action Type Filter Buttons */}
        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1">
          {actionFilters.map((af) => (
            <button
              key={af.id}
              onClick={() => handleActionClick(af.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                selectedAction === af.id
                  ? 'bg-indigo-600 text-white shadow'
                  : 'bg-slate-850 text-slate-400 hover:text-white border border-slate-800'
              }`}
            >
              {isBn ? af.labelBn : af.labelEn}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="relative w-full sm:w-72">
          <Search className="w-3.5 h-3.5 absolute left-3.5 top-3 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isBn ? 'অ্যাকশন, সদস্য বা আইপি খুঁজুন...' : 'Search activity, actor, IP...'}
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-850 border border-slate-700/70 text-xs text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500"
          />
        </div>
      </div>

      {/* Chronological Audit Log List */}
      <div className="space-y-3">
        {filteredLogs.length > 0 ? (
          filteredLogs.map((log) => (
            <div
              key={log.id}
              className="p-4 sm:p-5 rounded-2xl bg-slate-850 border border-slate-700/60 hover:border-slate-600 shadow transition-all duration-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-3.5">
                <div className="p-2.5 rounded-xl bg-slate-900 border border-slate-700/70 shadow-sm shrink-0">
                  {actionIcon(log.actionType)}
                </div>

                <div className="space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border uppercase tracking-wider ${severityBadge(log.severity)}`}>
                      {log.severity}
                    </span>
                    <span className="text-xs font-bold text-white">
                      {isBn ? log.targetSubject : log.targetSubject}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      • {log.performedBy}
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed">
                    {isBn ? log.detailsBn : log.detailsEn}
                  </p>

                  <div className="flex items-center gap-3 text-[10px] text-slate-500 font-mono pt-1">
                    <span>IP: {log.ipAddress || '103.114.98.24'}</span>
                    <span>•</span>
                    <span>{log.deviceInfo || 'Secure Client'}</span>
                  </div>
                </div>
              </div>

              {/* Timestamp */}
              <div className="text-right text-[11px] text-slate-400 whitespace-nowrap shrink-0 flex sm:flex-col items-center sm:items-end justify-between w-full sm:w-auto">
                <span className="font-mono text-slate-300">{log.timestamp.split(' ')[1]}</span>
                <span className="text-[10px] text-slate-500">{log.timestamp.split(' ')[0]}</span>
              </div>
            </div>
          ))
        ) : (
          <div className="p-8 rounded-2xl bg-slate-850 border border-dashed border-slate-700 text-center text-xs text-slate-400">
            {isBn ? 'কোনো অডিট রেকর্ড পাওয়া যায়নি।' : 'No audit records match the filter criteria.'}
          </div>
        )}
      </div>

    </div>
  );
};
