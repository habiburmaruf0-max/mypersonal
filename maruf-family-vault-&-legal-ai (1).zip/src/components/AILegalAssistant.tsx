import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  Mic, 
  MicOff, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Paperclip, 
  Upload, 
  FileCheck2, 
  RefreshCw, 
  CheckCircle2, 
  HelpCircle,
  X,
  FileText
} from 'lucide-react';
import { Language } from '../types/family';

interface AILegalAssistantProps {
  language: Language;
}

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  imageUrl?: string;
}

export const AILegalAssistant: React.FC<AILegalAssistantProps> = ({ language }) => {
  const isBn = language === 'bn';
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg-welcome',
      sender: 'ai',
      text: isBn 
        ? `👋 আসসালামু আলাইকুম! আমি মারুফের পরিবারের বিশেষায়িত **আইনি ও দলিল এআই সহায়ক**।
পৈতৃক জমি-জমার অংশ বণ্টন (ফারায়েয), ওয়ারিশ সনদ বিশ্লেষণ, ই-নামজারি (e-Mutation) আবেদন, বা দলিলের স্ক্যান কপি পরীক্ষা করতে আমাকে যে কোনো প্রশ্ন করতে পারেন।`
        : `👋 Welcome! I am your AI Legal & Document Assistant for Maruf's Family.
Ask me anything about Muslim Inheritance calculations, Warish Sanad verification, e-Namjari steps, or upload deed scans for AI legal analysis.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const [inputMessage, setInputMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [attachedImage, setAttachedImage] = useState<string | null>(null);
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const suggestedQuestions = [
    {
      bn: 'ওয়ারিশ জমি বিক্রির জন্য কি কি কাগজপত্র বাধ্যতামূলক?',
      en: 'What documents are required to sell inherited land?',
    },
    {
      bn: 'মারুফের পরিবারের উত্তরাধিকার অংশের সঠিক হিসাব দেখাও',
      en: "Show exact inheritance shares for Maruf's family",
    },
    {
      bn: 'বণ্টননামা দলিল (Partition Deed) ছাড়া কি জমি বিক্রি করা যায়?',
      en: 'Can inherited land be sold without a registered Bontonnama deed?',
    },
    {
      bn: 'ই-নামজারি শুনানিতে AC Land অফিসে কি কি নিতে হবে?',
      en: 'What documents should be taken to AC Land office for e-Namjari hearing?',
    },
  ];

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputMessage;
    if (!textToSend.trim() && !attachedImage) return;

    const userMsg: Message = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend,
      imageUrl: attachedImage || undefined,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    const curAttachedImage = attachedImage;
    setAttachedImage(null);
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToSend,
          imageBase64: curAttachedImage,
          history: messages.slice(-4).map((m) => ({
            role: m.sender === 'user' ? 'user' : 'model',
            text: m.text,
          })),
        }),
      });

      const data = await res.json();
      const aiReplyText = data.reply || data.fallback || 'দুঃখিত, কোনো উত্তর পাওয়া যায়নি।';

      const aiMsg: Message = {
        id: `ai-${Date.now()}`,
        sender: 'ai',
        text: aiReplyText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
      setMessages((prev) => [
        ...prev,
        {
          id: `ai-${Date.now()}`,
          sender: 'ai',
          text: isBn 
            ? 'সার্ভারে সাময়িক ত্রুটি হয়েছে। মারুফের পরিবারের ওয়ারিশ অংশ: মাতা নুর আক্তার ১২.৫%, ভাইরা (ওমর ফারুক, আব্দুল কাদের, হাবিবুর রহমান) ২৫% করে এবং বোন ফারজানা ১২.৫%।'
            : 'Temporary connection delay. Family legal distribution: Mother 12.5%, Brothers 25% each, Sister 12.5%.',
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setAttachedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Web Speech API Voice Recognition
  const toggleVoiceInput = () => {
    if (!('webkitSpeechRecognition' in window) && !('SpeechRecognition' in window)) {
      alert(isBn ? 'আপনার ব্রাউজারে স্পিচ রিকগনিশন সমর্থন করে না।' : 'Voice recognition not supported in this browser.');
      return;
    }

    if (isListening) {
      setIsListening(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.lang = isBn ? 'bn-BD' : 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    recognition.onstart = () => setIsListening(true);
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);
    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setInputMessage((prev) => (prev ? `${prev} ${transcript}` : transcript));
    };

    recognition.start();
  };

  // Text to Speech playback
  const handleSpeakText = (text: string) => {
    if ('speechSynthesis' in window) {
      if (isSpeaking) {
        window.speechSynthesis.cancel();
        setIsSpeaking(false);
        return;
      }

      const cleanText = text.replace(/[*#_`]/g, '');
      const utterance = new SpeechSynthesisUtterance(cleanText);
      utterance.lang = isBn ? 'bn-BD' : 'en-US';
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);
      setIsSpeaking(true);
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="space-y-6 max-w-4xl mx-auto flex flex-col h-[78vh]">
      
      {/* Header Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-850 border border-slate-700 shadow-md flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white shadow-md shadow-emerald-900/30">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <span>{isBn ? 'জেমিনি এআই আইনি ও দলিল পরামর্শক' : 'Gemini AI Legal & Deed Assistant'}</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                Gemini 3.8 Flash
              </span>
            </h2>
            <p className="text-xs text-slate-400">
              {isBn ? 'বাংলাদেশ ভূমি আইন, ওয়ারিশ ফারায়েয ও দলিল স্ক্যান OCR অ্যানালাইসিস' : 'Bangladesh Land Laws, Muslim Inheritance & Document OCR'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {attachedImage && (
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-800 border border-emerald-500/50 text-xs text-emerald-300">
              <FileCheck2 className="w-3.5 h-3.5" />
              <span>{isBn ? 'ছবি সংযুক্ত' : 'Image Ready'}</span>
              <button onClick={() => setAttachedImage(null)} className="text-slate-400 hover:text-white">
                <X className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Chat Messages Box */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 rounded-3xl bg-slate-850 border border-slate-700/80 space-y-4 shadow-inner">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-3xl p-4 shadow-md ${
                msg.sender === 'user'
                  ? 'bg-emerald-600 text-white rounded-br-none'
                  : 'bg-slate-800 border border-slate-700/80 text-slate-100 rounded-bl-none'
              }`}
            >
              {msg.imageUrl && (
                <div className="mb-3 rounded-2xl overflow-hidden border border-white/20 max-h-48">
                  <img src={msg.imageUrl} alt="Attached Document" className="w-full object-cover" />
                </div>
              )}

              {/* Message text with formatting */}
              <div className="text-xs sm:text-sm leading-relaxed whitespace-pre-wrap font-sans">
                {msg.text}
              </div>

              {/* Message Footer: Timestamp & TTS */}
              <div className="mt-2 pt-2 border-t border-slate-700/40 flex items-center justify-between text-[10px] opacity-70">
                <span>{msg.timestamp}</span>
                {msg.sender === 'ai' && (
                  <button
                    onClick={() => handleSpeakText(msg.text)}
                    className="p-1 hover:text-emerald-300 transition flex items-center gap-1"
                    title={isBn ? 'ভয়েসে শুনুন' : 'Listen with Speech'}
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                    <span>{isBn ? 'শুনুন' : 'Listen'}</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-3 p-4 rounded-3xl bg-slate-800 border border-slate-700 max-w-xs text-xs text-slate-300">
            <RefreshCw className="w-4 h-4 text-emerald-400 animate-spin" />
            <span>{isBn ? 'দলিল ও আইনগত ধারা বিশ্লেষণ করা হচ্ছে...' : 'Analyzing laws & documents...'}</span>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions Quick Chips */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] text-slate-400 whitespace-nowrap font-medium flex items-center gap-1">
          <Sparkles className="w-3 h-3 text-amber-300" />
          <span>{isBn ? 'দ্রুত প্রশ্নসমূহ:' : 'Quick Questions:'}</span>
        </span>
        {suggestedQuestions.map((q, idx) => (
          <button
            key={idx}
            onClick={() => handleSendMessage(isBn ? q.bn : q.en)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-white border border-slate-700/70 whitespace-nowrap transition text-xs"
          >
            {isBn ? q.bn : q.en}
          </button>
        ))}
      </div>

      {/* Input Form Bar */}
      <div className="p-3 rounded-2xl bg-slate-850 border border-slate-700 flex items-center gap-2 shadow-lg">
        {/* Hidden File Input */}
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleImageUpload}
          accept="image/*"
          className="hidden"
        />

        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          title={isBn ? 'দলিল বা সনদের ছবি আপলোড করুন' : 'Attach deed or sanad photo'}
          className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-emerald-400 border border-slate-700 transition"
        >
          <Paperclip className="w-4 h-4" />
        </button>

        <button
          type="button"
          onClick={toggleVoiceInput}
          title={isBn ? 'ভয়েস ইনপুট (মাইক্রোফোন)' : 'Voice Input (Microphone)'}
          className={`p-2.5 rounded-xl border transition ${
            isListening
              ? 'bg-rose-600 text-white border-rose-500 animate-pulse'
              : 'bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-emerald-400 border border-slate-700'
          }`}
        >
          {isListening ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
        </button>

        <input
          type="text"
          value={inputMessage}
          onChange={(e) => setInputMessage(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
          placeholder={
            isBn
              ? 'উত্তরাধিকার বণ্টন, নামজারি বা দলিলের যেকোনো আইনি প্রশ্ন লিখুন...'
              : 'Ask legal questions about inheritance, deeds or e-Namjari...'
          }
          className="flex-1 px-3 py-2 text-xs sm:text-sm bg-transparent text-white placeholder-slate-400 outline-none"
        />

        <button
          type="button"
          onClick={() => handleSendMessage()}
          disabled={isLoading || (!inputMessage.trim() && !attachedImage)}
          className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:bg-slate-800 text-white font-semibold text-xs transition shadow flex items-center gap-1.5"
        >
          <span>{isBn ? 'পাঠান' : 'Send'}</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </div>

    </div>
  );
};
