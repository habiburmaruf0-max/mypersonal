import React, { useState } from 'react';
import { 
  Sparkles, 
  Globe, 
  Search, 
  ExternalLink, 
  Bot, 
  Plus, 
  FileText, 
  Bookmark, 
  CheckCircle2, 
  BookOpen, 
  Tag, 
  Copy, 
  Download, 
  Share2, 
  Compass, 
  Layers, 
  FolderPlus, 
  RefreshCw, 
  Send, 
  Check, 
  Landmark, 
  Scale, 
  Database,
  ArrowRight,
  ShieldCheck,
  X
} from 'lucide-react';
import { WebDataCollection, Language, UserRole, VaultDocument } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface AILabInternetHubProps {
  collections: WebDataCollection[];
  language: Language;
  userRole: UserRole;
  soundEnabled: boolean;
  onAddCollection: (item: WebDataCollection) => void;
  onSaveToVault?: (doc: VaultDocument) => void;
}

export const AILabInternetHub: React.FC<AILabInternetHubProps> = ({
  collections,
  language,
  userRole,
  soundEnabled,
  onAddCollection,
  onSaveToVault,
}) => {
  const isBn = language === 'bn';
  const canEdit = userRole === 'Admin' || userRole === 'Editor';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [activeAnalysisItem, setActiveAnalysisItem] = useState<WebDataCollection | null>(null);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [aiQuestionPrompt, setAiQuestionPrompt] = useState('');
  const [customAiAnswer, setCustomAiAnswer] = useState<string | null>(null);
  const [isCustomAiLoading, setIsCustomAiLoading] = useState(false);

  // New Collection Form State
  const [newTitleBn, setNewTitleBn] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newCategory, setNewCategory] = useState<WebDataCollection['category']>('land_records');
  const [newSourceName, setNewSourceName] = useState('');
  const [newSourceUrl, setNewSourceUrl] = useState('');
  const [newContentBn, setNewContentBn] = useState('');
  const [newTags, setNewTags] = useState('');
  const [newImportance, setNewImportance] = useState<WebDataCollection['importance']>('high');

  const categories = [
    { id: 'all', labelBn: 'সকল ডেটা সংগ্রহ', labelEn: 'All Collections' },
    { id: 'land_records', labelBn: 'ভূমি ও নামজারি পোর্টাল', labelEn: 'Land & Mutation' },
    { id: 'inheritance', labelBn: 'ফারায়েয ও আইন বিচার', labelEn: 'Inheritance & Laws' },
    { id: 'legal_laws', labelBn: 'আইনি ধারা ও প্রবিধান', labelEn: 'Statutory Acts' },
    { id: 'gazette', labelBn: 'গেজেট ও খাজনা (LDTAX)', labelEn: 'Gazette & Revenue' },
    { id: 'family_heritage', labelBn: 'পারিবারিক ঐতিহ্য ও স্মৃতি', labelEn: 'Family Heritage' },
  ];

  const officialPortals = [
    { name: 'ই-নামজারি (e-Mutation)', url: 'https://mutation.land.gov.bd', descBn: 'অনলাইনে নামজারি আবেদন ও ট্র্যাকিং' },
    { name: 'ই-পর্চা (e-Porcha)', url: 'https://eporcha.gov.bd', descBn: 'CS, SA, RS, BS খতিয়ান অনুসন্ধান' },
    { name: 'ভূমি উন্নয়ন কর (LDTAX)', url: 'https://ldtax.gov.bd', descBn: 'ডিজিটাল খাজনা ও দাখিলা যাচাই' },
    { name: 'বাংলাদেশ আইন (BDLaws)', url: 'https://bdlaws.minlaw.gov.bd', descBn: 'উত্তরাধিকার ও রেজিস্ট্রেশন আইন' },
    { name: 'ভূমি মন্ত্রণালয়', url: 'https://land.gov.bd', descBn: 'স্মার্ট ভূমি সেবা পোর্টাল' },
  ];

  const filteredCollections = collections.filter((item) => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const q = searchQuery.toLowerCase().trim();
    const matchesQ = 
      !q || 
      item.titleBn.toLowerCase().includes(q) || 
      item.titleEn.toLowerCase().includes(q) ||
      item.sourceName.toLowerCase().includes(q) ||
      item.contentBn.toLowerCase().includes(q) ||
      item.tags.some((t) => t.toLowerCase().includes(q));
    return matchesCat && matchesQ;
  });

  const handleCopy = (text: string, id: string) => {
    soundEffects.playClick(soundEnabled);
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const handleAnalyzeWithAI = async (item: WebDataCollection) => {
    soundEffects.playCyberPulse(soundEnabled);
    setActiveAnalysisItem(item);
    setIsAnalyzing(true);
    setAnalysisResult(null);

    try {
      const res = await fetch('/api/ai-lab/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ collectionItem: item }),
      });
      const data = await res.json();
      if (data.summary) {
        setAnalysisResult(data.summary);
        soundEffects.playSuccess(soundEnabled);
      } else {
        setAnalysisResult('বিশ্লেষণ সম্পন্ন হতে পারেনি। অনুগ্রহ করে আবার চেষ্টা করুন।');
      }
    } catch (err: any) {
      setAnalysisResult(`ত্রুটি: ${err.message || 'সার্ভারে সমস্যা হয়েছে।'}`);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleCustomAiQuestion = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestionPrompt.trim()) return;

    soundEffects.playClick(soundEnabled);
    setIsCustomAiLoading(true);
    setCustomAiAnswer(null);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `[AI LAB RESEARCH QUERY]: ${aiQuestionPrompt}. 
Context: Analyze within the framework of Bangladesh Land Administration, e-Namjari, Khatians (CS/SA/RS/BS), Muslim Hanafi succession laws, and Maruf's family document vault. Provide direct actionable answers in Bengali.`,
        }),
      });
      const data = await res.json();
      setCustomAiAnswer(data.reply || 'কোনো উত্তর পাওয়া যায়নি।');
      soundEffects.playSuccess(soundEnabled);
    } catch (err: any) {
      setCustomAiAnswer(`ত্রুটি: ${err.message || 'সার্ভার সংযোগে সমস্যা।'}`);
    } finally {
      setIsCustomAiLoading(false);
    }
  };

  const handleCreateCollection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleBn.trim() || !newContentBn.trim()) return;

    soundEffects.playSuccess(soundEnabled);

    const parsedTags = newTags
      ? newTags.split(',').map((t) => t.trim()).filter(Boolean)
      : ['ইন্টারনেট তথ্য', 'পারিবারিক সংগ্রহ'];

    const newCol: WebDataCollection = {
      id: `web-col-${Date.now()}`,
      titleBn: newTitleBn,
      titleEn: newTitleEn || newTitleBn,
      category: newCategory,
      sourceName: newSourceName || 'অনলাইন সংগ্রহ',
      sourceUrl: newSourceUrl || undefined,
      contentBn: newContentBn,
      tags: parsedTags,
      collectedDate: new Date().toISOString().split('T')[0],
      verified: true,
      importance: newImportance,
    };

    onAddCollection(newCol);
    setIsAddModalOpen(false);

    // Reset Form
    setNewTitleBn('');
    setNewTitleEn('');
    setNewSourceName('');
    setNewSourceUrl('');
    setNewContentBn('');
    setNewTags('');
    setNewImportance('high');
  };

  const handleExportToVault = (item: WebDataCollection, textContent: string) => {
    if (!onSaveToVault) return;
    soundEffects.playSuccess(soundEnabled);
    const newDoc: VaultDocument = {
      id: `doc-lab-${Date.now()}`,
      titleBn: `[AI ল্যাব] ${item.titleBn}`,
      titleEn: `[AI Lab] ${item.titleEn}`,
      category: 'internet_archive',
      fileType: 'text',
      fileSize: `${(textContent.length / 1024).toFixed(1)} KB`,
      isEncrypted: true,
      encryptionHash: `AES256:LAB-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
      issueDate: new Date().toISOString().split('T')[0],
      documentNumber: `LAB-ARCHIVE-${Math.floor(1000 + Math.random() * 9000)}`,
      notesBn: `উৎস: ${item.sourceName} | এআই সারসংক্ষেপ ও ডেটা`,
      verified: true,
    };
    onSaveToVault(newDoc);
  };

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-teal-950 via-slate-900 to-indigo-950 border border-teal-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="relative z-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-2 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 border border-teal-500/40 text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5 animate-spin" />
              <span>{isBn ? 'এআই ল্যাব ও ইন্টারনেট ডেটা হাব' : 'AI Lab & Web Intelligence Hub'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              {isBn ? 'ইন্টারনেট সংগ্রহ ও ভূমি আইন এআই গবেষণা' : 'Internet Collections & Legal AI Research'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
              {isBn 
                ? 'অনলাইন ভূমি সেবা (ই-নামজারি, ই-পর্চা, LDTAX), সরকারি গেজেট ও মুসলিম উত্তরাধিকার আইন সংক্রান্ত তথ্য সংগ্রহ, আর্কাইভ এবং জেমিনি এআই দিয়ে তাৎক্ষণিক বিশ্লেষণ।' 
                : 'National land portal records, cadastral survey references, statutory inheritance laws, and intelligent Gemini AI synthesis for Maruf\'s family.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            {canEdit && (
              <button
                onClick={() => {
                  soundEffects.playClick(soundEnabled);
                  setIsAddModalOpen(true);
                }}
                className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-500 hover:to-emerald-500 text-white font-bold text-xs shadow-lg shadow-teal-900/40 transition hover:scale-[1.02] active:scale-[0.98]"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন তথ্য যুক্ত করুন' : 'Add Web Record'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Ambient glow decoration */}
        <div className="absolute -top-16 -right-16 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Official Bangladesh Government Portals Quick Bar */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-md">
        <div className="flex items-center gap-2 text-xs font-bold text-teal-400 mb-3">
          <Globe className="w-4 h-4 text-teal-400" />
          <span>{isBn ? 'বাংলাদেশ ডিজিটাল ভূমি ও সরকারি সেবা লিঙ্কসমূহ' : 'Official Bangladesh Digital Land Services'}</span>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {officialPortals.map((portal) => (
            <a
              key={portal.name}
              href={portal.url}
              target="_blank"
              rel="noopener noreferrer"
              className="p-3 rounded-2xl bg-slate-800/80 hover:bg-slate-750 border border-slate-700/60 hover:border-teal-500/50 transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between text-white font-bold text-xs group-hover:text-teal-300 transition">
                  <span className="truncate">{portal.name}</span>
                  <ExternalLink className="w-3 h-3 text-slate-400 group-hover:text-teal-400 shrink-0 ml-1" />
                </div>
                <p className="text-[11px] text-slate-400 mt-1 line-clamp-1">{portal.descBn}</p>
              </div>
            </a>
          ))}
        </div>
      </div>

      {/* Interactive AI Research Input Box */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 border border-indigo-500/30 shadow-xl space-y-4">
        <div className="flex items-center gap-2 text-sm font-bold text-indigo-300">
          <Bot className="w-5 h-5 text-indigo-400" />
          <span>{isBn ? 'স্মার্ট এআই সহকারী: ইন্টারনেট ও পারিবারিক তথ্য নিয়ে প্রশ্ন করুন' : 'Smart AI Lab: Query Collected Web & Legal Records'}</span>
        </div>

        <form onSubmit={handleCustomAiQuestion} className="flex gap-2">
          <input
            type="text"
            value={aiQuestionPrompt}
            onChange={(e) => setAiQuestionPrompt(e.target.value)}
            placeholder={isBn ? 'যেমন: নামজারি আবেদনে কী কী ভুল থাকলে ডিসি অফিস বাতিল করে? কিংবা সিএস ও আরএস খতিয়ানের পার্থক্য কী?' : 'e.g., What documents are required for e-Namjari appeal in Dhaka division?'}
            className="flex-1 px-4 py-3 rounded-2xl bg-slate-800/90 border border-slate-700 text-white text-xs sm:text-sm focus:ring-2 focus:ring-indigo-500 outline-none placeholder:text-slate-500"
          />
          <button
            type="submit"
            disabled={isCustomAiLoading || !aiQuestionPrompt.trim()}
            className="px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 shadow-md transition"
          >
            {isCustomAiLoading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
            <span className="hidden sm:inline">{isBn ? 'অনুসন্ধান' : 'Analyze'}</span>
          </button>
        </form>

        {customAiAnswer && (
          <div className="p-4 rounded-2xl bg-indigo-950/40 border border-indigo-700/50 space-y-3">
            <div className="flex items-center justify-between text-xs text-indigo-300 font-bold">
              <span className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-indigo-400" />
                {isBn ? 'জেমিনি এআই আইনি উত্তর:' : 'Gemini AI Intelligence Answer:'}
              </span>
              <button
                onClick={() => handleCopy(customAiAnswer, 'custom-ai-ans')}
                className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white"
              >
                {copiedId === 'custom-ai-ans' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedId === 'custom-ai-ans' ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি' : 'Copy')}</span>
              </button>
            </div>
            <div className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
              {customAiAnswer}
            </div>
          </div>
        )}
      </div>

      {/* Filter and Search Bar */}
      <div className="space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isBn ? 'ইন্টারনেট সংগ্রহ, খতিয়ান, আইন বা উৎস অনুসন্ধান...' : 'Search internet collections, laws, sources...'}
              className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-slate-850 border border-slate-700/80 text-white text-xs outline-none focus:ring-2 focus:ring-teal-500"
            />
          </div>
          <span className="text-xs text-slate-400 shrink-0 self-center">
            {isBn ? `মোট ${filteredCollections.length}টি সংগ্রহ` : `${filteredCollections.length} collections`}
          </span>
        </div>

        {/* Category Filter Pills */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                soundEffects.playClick(soundEnabled);
                setSelectedCategory(cat.id);
              }}
              className={`px-3 py-1.5 rounded-xl whitespace-nowrap font-medium transition ${
                selectedCategory === cat.id
                  ? 'bg-teal-600 text-white shadow'
                  : 'bg-slate-800 text-slate-400 hover:text-white hover:bg-slate-700'
              }`}
            >
              {isBn ? cat.labelBn : cat.labelEn}
            </button>
          ))}
        </div>
      </div>

      {/* Collections Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCollections.map((item) => {
          const isSelected = activeAnalysisItem?.id === item.id;
          return (
            <div
              key={item.id}
              className={`p-5 rounded-3xl border transition-all duration-300 flex flex-col justify-between ${
                isSelected
                  ? 'bg-slate-850 border-teal-500 shadow-xl shadow-teal-950/30'
                  : 'bg-slate-850/90 border-slate-700/70 hover:border-slate-600 shadow'
              }`}
            >
              <div className="space-y-3">
                {/* Header & Category Badge */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-teal-500/15 text-teal-300 border border-teal-500/30 text-[10px] font-bold">
                      {item.category === 'land_records' ? (isBn ? 'ভূমি ও নামজারি' : 'Land Records')
                        : item.category === 'inheritance' ? (isBn ? 'ফারায়েয ও বণ্টন' : 'Inheritance')
                        : item.category === 'legal_laws' ? (isBn ? 'আইনি ধারা' : 'Legal Law')
                        : item.category === 'gazette' ? (isBn ? 'গেজেট ও কর' : 'Gazette / Tax')
                        : (isBn ? 'পারিবারিক ঐতিহ্য' : 'Heritage')}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      {item.collectedDate}
                    </span>
                  </div>

                  {item.sourceUrl && (
                    <a
                      href={item.sourceUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-teal-400 hover:text-teal-300 text-xs flex items-center gap-1 font-semibold"
                    >
                      <span className="hidden sm:inline">{isBn ? 'উৎস লিংক' : 'Source'}</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  )}
                </div>

                {/* Title */}
                <h3 className="font-bold text-sm sm:text-base text-white leading-snug">
                  {isBn ? item.titleBn : item.titleEn}
                </h3>

                <p className="text-xs text-slate-400">
                  <span className="font-semibold text-slate-300">উৎস: </span>
                  {item.sourceName}
                </p>

                {/* Content snippet */}
                <p className="text-xs text-slate-300 leading-relaxed line-clamp-3 bg-slate-900/60 p-3 rounded-2xl border border-slate-800">
                  {isBn ? item.contentBn : (item.contentEn || item.contentBn)}
                </p>

                {/* Key Takeaways */}
                {item.keyTakeaways && item.keyTakeaways.length > 0 && (
                  <div className="space-y-1">
                    <span className="text-[11px] font-bold text-slate-400">
                      {isBn ? 'মূল বিষয়বস্তু:' : 'Key Takeaways:'}
                    </span>
                    <ul className="space-y-1">
                      {item.keyTakeaways.map((point, idx) => (
                        <li key={idx} className="flex items-start gap-1.5 text-xs text-slate-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-teal-400 shrink-0 mt-0.5" />
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {/* Tags */}
                <div className="flex flex-wrap gap-1 pt-1">
                  {item.tags.map((tag) => (
                    <span key={tag} className="px-2 py-0.5 rounded-lg bg-slate-800 text-slate-400 text-[10px]">
                      #{tag}
                    </span>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                <button
                  onClick={() => handleAnalyzeWithAI(item)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-teal-500/15 hover:bg-teal-500/25 text-teal-300 border border-teal-500/30 text-xs font-semibold transition"
                >
                  <Bot className="w-3.5 h-3.5 text-teal-400" />
                  <span>{isBn ? 'এআই গবেষণা' : 'AI Analysis'}</span>
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleCopy(`${item.titleBn}\n${item.contentBn}\nউৎস: ${item.sourceName}`, item.id)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs"
                    title={isBn ? 'কপি করুন' : 'Copy'}
                  >
                    {copiedId === item.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>

                  {onSaveToVault && (
                    <button
                      onClick={() => handleExportToVault(item, item.contentBn)}
                      className="p-1.5 rounded-lg bg-slate-800 hover:bg-emerald-600 text-slate-300 hover:text-white text-xs"
                      title={isBn ? 'ভল্টে সংরক্ষণ করুন' : 'Save to Vault'}
                    >
                      <FolderPlus className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* AI Analysis Modal / Slide-out Details */}
      {activeAnalysisItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-teal-500/40 p-6 space-y-4 shadow-2xl">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-teal-500/20 text-teal-300">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-white">
                    {isBn ? 'এআই ল্যাব গবেষণা রিপোর্ট' : 'AI Lab Research Report'}
                  </h3>
                  <p className="text-xs text-slate-400">{activeAnalysisItem.titleBn}</p>
                </div>
              </div>
              <button
                onClick={() => setActiveAnalysisItem(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {isAnalyzing ? (
              <div className="py-12 flex flex-col items-center justify-center space-y-3">
                <RefreshCw className="w-8 h-8 text-teal-400 animate-spin" />
                <p className="text-xs text-teal-300 font-medium">
                  {isBn ? 'জেমিনি এআই মডেল দ্বারা ডেটা বিশ্লেষণ ও আইনি সারসংক্ষেপ তৈরি হচ্ছে...' : 'Gemini AI is analyzing web records and cross-referencing land laws...'}
                </p>
              </div>
            ) : analysisResult ? (
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-800/80 border border-slate-700 text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {analysisResult}
                </div>

                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={() => handleCopy(analysisResult, 'analysis-res')}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                  >
                    {copiedId === 'analysis-res' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId === 'analysis-res' ? (isBn ? 'কপি সম্পন্ন' : 'Copied') : (isBn ? 'কপি রিপোর্ট' : 'Copy Report')}</span>
                  </button>

                  {onSaveToVault && (
                    <button
                      onClick={() => {
                        handleExportToVault(activeAnalysisItem, analysisResult);
                        setActiveAnalysisItem(null);
                      }}
                      className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow"
                    >
                      <FolderPlus className="w-3.5 h-3.5" />
                      <span>{isBn ? 'ভল্টে দলিল হিসেবে জমা দিন' : 'Save to Vault'}</span>
                    </button>
                  )}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Add New Collection Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700 p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-base text-white flex items-center gap-2">
                <Globe className="w-5 h-5 text-teal-400" />
                <span>{isBn ? 'নতুন ইন্টারনেট ডেটা সংরক্ষণ' : 'Add Web & Legal Intelligence'}</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCollection} className="space-y-3">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'শিরোনাম (বাংলা) *' : 'Title (Bangla) *'}
                </label>
                <input
                  type="text"
                  value={newTitleBn}
                  onChange={(e) => setNewTitleBn(e.target.value)}
                  placeholder="যেমন: আরএস খতিয়ান ও ওয়ারিশ হিস্যা সংক্রান্ত হাইকোর্ট নির্দেশনা"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'শিরোনাম (English)' : 'Title (English)'}
                </label>
                <input
                  type="text"
                  value={newTitleEn}
                  onChange={(e) => setNewTitleEn(e.target.value)}
                  placeholder="e.g., RS Khatian & Legal Succession Precedent"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e: any) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  >
                    <option value="land_records">{isBn ? 'ভূমি ও নামজারি' : 'Land & Mutation'}</option>
                    <option value="inheritance">{isBn ? 'ফারায়েয ও বণ্টন' : 'Inheritance'}</option>
                    <option value="legal_laws">{isBn ? 'আইনি ধারা' : 'Statutory Laws'}</option>
                    <option value="gazette">{isBn ? 'গেজেট ও খাজনা' : 'Gazette & Revenue'}</option>
                    <option value="family_heritage">{isBn ? 'পারিবারিক ঐতিহ্য' : 'Family Heritage'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'গুরুত্ব' : 'Importance'}
                  </label>
                  <select
                    value={newImportance}
                    onChange={(e: any) => setNewImportance(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                  >
                    <option value="high">{isBn ? 'উচ্চ অগ্রাধিকার (High)' : 'High Priority'}</option>
                    <option value="medium">{isBn ? 'সাধারণ (Medium)' : 'Medium'}</option>
                    <option value="reference">{isBn ? 'রেফারেন্স (Reference)' : 'Reference'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'উৎস বা ওয়েবসাইটের নাম' : 'Source Organization'}
                </label>
                <input
                  type="text"
                  value={newSourceName}
                  onChange={(e) => setNewSourceName(e.target.value)}
                  placeholder="যেমন: ভূমি মন্ত্রণালয় / সুপ্রিম কোর্ট রায়"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ওয়েবসাইট লিংক (URL)' : 'Source URL'}
                </label>
                <input
                  type="url"
                  value={newSourceUrl}
                  onChange={(e) => setNewSourceUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'সংগৃহীত তথ্য বা মূল নোট *' : 'Content & Notes *'}
                </label>
                <textarea
                  value={newContentBn}
                  onChange={(e) => setNewContentBn(e.target.value)}
                  rows={4}
                  placeholder="তথ্যটি বিস্তারিত লিখুন বা কপি করে পেস্ট করুন..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none resize-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ট্যাগ (কমা দিয়ে আলাদা করুন)' : 'Tags (comma separated)'}
                </label>
                <input
                  type="text"
                  value={newTags}
                  onChange={(e) => setNewTags(e.target.value)}
                  placeholder="খতিয়ান, ওয়ারিশ, জমি বিক্রি"
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs focus:ring-2 focus:ring-teal-500 outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-bold shadow"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Record'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
