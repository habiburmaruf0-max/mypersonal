import React, { useState, useRef } from 'react';
import { 
  X, 
  Send, 
  FileUp, 
  Sparkles, 
  CheckCircle2, 
  Upload, 
  FileText, 
  Paperclip, 
  ShieldCheck, 
  AlertTriangle,
  Clock,
  KeyRound,
  UserCheck,
  FileSpreadsheet,
  Image as ImageIcon
} from 'lucide-react';
import { Language, VisitorRequest, VisitorRequestType } from '../types/family';
import { soundEffects } from '../utils/soundEffects';

interface VisitorRequestModalProps {
  language: Language;
  soundEnabled?: boolean;
  onClose: () => void;
  onSubmitRequest: (req: VisitorRequest) => void;
}

export const VisitorRequestModal: React.FC<VisitorRequestModalProps> = ({
  language,
  soundEnabled = true,
  onClose,
  onSubmitRequest,
}) => {
  const isBn = language === 'bn';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [relationClaim, setRelationClaim] = useState('');
  const [requestType, setRequestType] = useState<VisitorRequestType>('document_upload');
  const [urgency, setUrgency] = useState<'normal' | 'urgent' | 'critical'>('normal');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [trackingId, setTrackingId] = useState('');

  // File Upload State (Supports ALL formatted files)
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [selectedFileType, setSelectedFileType] = useState<string | null>(null);
  const [selectedFileSize, setSelectedFileSize] = useState<string | null>(null);
  const [selectedFileDataUrl, setSelectedFileDataUrl] = useState<string | null>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    soundEffects.playClick(soundEnabled);
    setSelectedFileName(file.name);
    setSelectedFileType(file.type || file.name.split('.').pop() || 'file');
    setSelectedFileSize(`${(file.size / (1024 * 1024)).toFixed(2)} MB`);

    // Read base64
    const reader = new FileReader();
    reader.onload = () => {
      setSelectedFileDataUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !title.trim()) return;

    soundEffects.playSuccess(soundEnabled);

    const generatedTrackingId = `REQ-${Date.now().toString().slice(-6)}`;
    setTrackingId(generatedTrackingId);

    const newReq: VisitorRequest = {
      id: `req-${Date.now()}`,
      submitterName: name,
      submitterPhone: phone || '+880 17...',
      submitterEmail: email,
      relationClaimBn: relationClaim || 'পারিবারিক সদস্য / শুভাকাঙ্ক্ষী',
      relationClaimEn: relationClaim || 'Family Member / Relative',
      requestType,
      urgency,
      title,
      description,
      submittedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      status: 'pending',
      fileAttachmentName: selectedFileName || undefined,
      fileAttachmentType: selectedFileType || undefined,
      fileAttachmentSize: selectedFileSize || undefined,
      fileAttachmentDataUrl: selectedFileDataUrl || undefined,
    };

    onSubmitRequest(newReq);
    setIsSuccess(true);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-3xl bg-slate-900 border border-slate-700/80 p-6 sm:p-8 space-y-4 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
        >
          <X className="w-4 h-4" />
        </button>

        {isSuccess ? (
          <div className="py-8 text-center space-y-4">
            <div className="relative inline-block">
              <CheckCircle2 className="w-16 h-16 text-emerald-400 mx-auto animate-bounce" />
              <div className="absolute inset-0 bg-emerald-500/20 rounded-full blur-xl" />
            </div>
            <div className="space-y-1">
              <h3 className="text-lg font-extrabold text-white">
                {isBn ? 'আপনার অনুরোধ সফলভাবে জমা হয়েছে!' : 'Request Submitted Successfully!'}
              </h3>
              <p className="text-xs text-slate-300 max-w-sm mx-auto">
                {isBn 
                  ? 'অ্যাডমিন মারুফ ভাইয়ের প্যানেলে তাৎক্ষণিক নোটিফিকেশন পৌঁছেছে। যাচাইপূর্বক অনুমোদন দিলে সিস্টেম স্বয়ংক্রিয়ভাবে কার্যকর করবে।' 
                  : 'Admin Maruf has received your request and real-time notification alert. Upon verification, the action will be published.'}
              </p>
            </div>

            <div className="p-3 rounded-2xl bg-slate-800/80 border border-slate-700 inline-block">
              <span className="text-[11px] text-slate-400 font-semibold">{isBn ? 'ট্র্যাকিং রেফারেন্স আইডি:' : 'Tracking Reference ID:'} </span>
              <span className="text-xs font-mono font-bold text-emerald-400 ml-1">{trackingId}</span>
            </div>

            <div className="pt-2">
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg transition"
              >
                {isBn ? 'ঠিক আছে' : 'Done'}
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded-xl bg-emerald-500/15 text-emerald-400">
                  <FileUp className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-white">
                    {isBn ? 'অ্যাডমিন মারুফের নিকট অনুরোধ / ফাইল জমা' : 'Submit Request & File to Admin Maruf'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {isBn 
                      ? 'নতুন ফাইল অনুমোদন, রোল আপগ্রেড, বা তথ্য সংশোধনের জন্য অনুরোধ পাঠান' 
                      : 'Request document upload approval, role upgrade, or records edit'}
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              
              {/* Submitter Name & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'আপনার নাম *' : 'Your Name *'}
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder={isBn ? 'যেমন: ওমর ফারুক / পান্না' : 'e.g., Omar Faruque'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'মোবাইল নম্বর' : 'Phone Number'}
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+880 17..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Email & Relationship */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'ইমেইল (ঐচ্ছিক)' : 'Email (Optional)'}
                  </label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="email@example.com"
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'পারিবারিক সম্পর্ক' : 'Family Relationship'}
                  </label>
                  <input
                    type="text"
                    value={relationClaim}
                    onChange={(e) => setRelationClaim(e.target.value)}
                    placeholder={isBn ? 'যেমন: বড় ভাই / বোন / চাচাতো ভাই' : 'e.g. Elder Brother'}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  />
                </div>
              </div>

              {/* Request Type & Urgency */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'অনুরোধের ধরন' : 'Request Type'}
                  </label>
                  <select
                    value={requestType}
                    onChange={(e: any) => setRequestType(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="document_upload">{isBn ? '📁 দলিল/ফাইল আপলোড অনুমোদন' : '📁 Document Upload Approval'}</option>
                    <option value="role_upgrade">{isBn ? '🛡️ রোল আপগ্রেড আবেদন (Editor/Admin)' : '🛡️ Role Upgrade Request'}</option>
                    <option value="info_update">{isBn ? '✏️ প্রোফাইল/তথ্য সংশোধন' : '✏️ Profile Info Update'}</option>
                    <option value="vault_unlock">{isBn ? '🔓 ভল্ট ফাইল এক্সেস অনুরোধ' : '🔓 Vault Unlock Request'}</option>
                    <option value="contact_query">{isBn ? '💬 সাধারণ জিজ্ঞাসা / আইনি সহায়তা' : '💬 General Inquiry'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    {isBn ? 'জরুরিতা (Urgency)' : 'Urgency'}
                  </label>
                  <select
                    value={urgency}
                    onChange={(e: any) => setUrgency(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  >
                    <option value="normal">{isBn ? 'সাধারণ (Normal)' : 'Normal'}</option>
                    <option value="urgent">{isBn ? 'জরুরি (Urgent)' : 'Urgent'}</option>
                    <option value="critical">{isBn ? 'অতি জরুরি (Critical / Same Day)' : 'Critical'}</option>
                  </select>
                </div>
              </div>

              {/* Title */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'আবেদনের শিরোনাম *' : 'Request Title *'}
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={isBn ? 'যেমন: ধানমন্ডি প্লটের খারিজ খতিয়ান স্ক্যান সংযুক্তি' : 'e.g. Mutation Khatian scan upload'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500"
                  required
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'বিস্তারিত বিবরণ' : 'Description'}
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={2}
                  placeholder={isBn ? 'অনুরোধের কারণ ও প্রয়োজনীয় তথ্য উল্লেখ করুন...' : 'Explain context and reasons for admin review...'}
                  className="w-full px-3 py-2 rounded-xl bg-slate-800 border border-slate-700 text-white text-xs outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                />
              </div>

              {/* Universal File Attachment (Supports ALL Formats) */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  {isBn ? 'ফাইল বা দলিল সংযুক্তি (সকল ফরম্যাট সমর্থিত)' : 'Attach Any File (All Formats Supported)'}
                </label>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                />

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-slate-700 hover:border-emerald-500/60 rounded-2xl p-3.5 bg-slate-800/50 hover:bg-slate-800/80 cursor-pointer transition text-center space-y-1.5"
                >
                  {selectedFileName ? (
                    <div className="flex items-center justify-between px-2">
                      <div className="flex items-center gap-2 text-left">
                        <Paperclip className="w-4 h-4 text-emerald-400 shrink-0" />
                        <div>
                          <p className="text-xs font-bold text-white truncate max-w-[220px]">{selectedFileName}</p>
                          <p className="text-[10px] text-slate-400 font-mono">{selectedFileSize}</p>
                        </div>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/30">
                        {isBn ? 'সংযুক্ত হয়েছে' : 'Attached'}
                      </span>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-5 h-5 text-slate-400 mx-auto" />
                      <p className="text-xs text-slate-300 font-medium">
                        {isBn ? 'ফাইল সিলেক্ট করতে এখানে ক্লিক করুন' : 'Click to select or drop any file'}
                      </p>
                      <p className="text-[10px] text-slate-500">
                        PDF, DOCX, XLSX, PPTX, JPG, PNG, WEBP, ZIP, TXT, CAD (.dwg)
                      </p>
                    </>
                  )}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg shadow-emerald-950/40 transition"
                >
                  <Send className="w-4 h-4" />
                  <span>{isBn ? 'অনুরোধ পাঠান' : 'Submit to Admin'}</span>
                </button>
              </div>

            </form>
          </>
        )}
      </div>
    </div>
  );
};
