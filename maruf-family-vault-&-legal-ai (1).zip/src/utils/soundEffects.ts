// Procedural Web Audio API sound effects and ambient generative music synthesizer
let audioCtx: AudioContext | null = null;
let ambientOscillators: OscillatorNode[] = [];
let ambientGains: GainNode[] = [];
let ambientMasterGain: GainNode | null = null;
let isAmbientPlaying = false;
let ambientInterval: any = null;

function getAudioContext(): AudioContext | null {
  if (typeof window === 'undefined') return null;
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (AudioContextClass) {
      audioCtx = new AudioContextClass();
    }
  }
  if (audioCtx && audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => {});
  }
  return audioCtx;
}

export const soundEffects = {
  // Soft high-tech tactile click
  playClick: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.08, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.05);
    } catch (e) {}
  },

  // Uplifting double-chime success chord
  playSuccess: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      // Note 1: E5 (659Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'triangle';
      osc1.frequency.setValueAtTime(659.25, now);
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.3);

      // Note 2: B5 (987Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'triangle';
      osc2.frequency.setValueAtTime(987.77, now + 0.1);
      gain2.gain.setValueAtTime(0.14, now + 0.1);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.1);
      osc2.stop(now + 0.45);
    } catch (e) {}
  },

  // Role Assignment Chime (Harmonic progression)
  playRoleAssign: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      const chord = [523.25, 659.25, 783.99, 1046.50]; // C Major arpeggio
      chord.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);
        gain.gain.setValueAtTime(0.09, now + idx * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.08 + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + idx * 0.08 + 0.4);
      });
    } catch (e) {}
  },

  // Security alert / Warning chime
  playAlert: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(440, now);
      osc.frequency.setValueAtTime(330, now + 0.1);
      osc.frequency.setValueAtTime(220, now + 0.2);

      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch (e) {}
  },

  // Cyber audit entry tick
  playAuditTick: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, now);
      osc.frequency.exponentialRampToValueAtTime(800, now + 0.04);

      gain.gain.setValueAtTime(0.06, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.04);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.04);
    } catch (e) {}
  },

  // Soft ambient pulse chord for dramatic visual updates
  playAmbientPulse: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(261.63, now); // Middle C
      gain.gain.setValueAtTime(0.04, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.6);
    } catch (e) {}
  },

  // Cyber pulse sound alias for high-tech scanning
  playCyberPulse: (enabled = true) => {
    soundEffects.playAmbientPulse(enabled);
  },

  // Safe lock sound
  playLock: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(320, now);
      osc.frequency.exponentialRampToValueAtTime(180, now + 0.12);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.12);
    } catch (e) {}
  },

  // Safe unlock sound
  playUnlock: (enabled = true) => {
    if (!enabled) return;
    try {
      const ctx = getAudioContext();
      if (!ctx) return;
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(420, now);
      osc.frequency.exponentialRampToValueAtTime(840, now + 0.15);
      gain.gain.setValueAtTime(0.1, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(now);
      osc.stop(now + 0.15);
    } catch (e) {}
  },

  // --- Procedural Ambient Background Music Synthesizer ---
  // Generates calming, peaceful family vault meditation chords in C Major / Pentatonic
  startAmbientMusic: () => {
    try {
      const ctx = getAudioContext();
      if (!ctx) return false;
      if (isAmbientPlaying) return true;

      // Master ambient gain
      ambientMasterGain = ctx.createGain();
      ambientMasterGain.gain.setValueAtTime(0.035, ctx.currentTime);
      ambientMasterGain.connect(ctx.destination);

      // Chords progression frequencies [C major, Am, F major, G]
      const chordProgressions = [
        [130.81, 196.00, 261.63, 329.63], // C major (C3, G3, C4, E4)
        [110.00, 164.81, 220.00, 261.63], // A minor (A2, E3, A3, C4)
        [174.61, 220.00, 261.63, 349.23], // F major (F3, A3, C4, F4)
        [196.00, 246.94, 293.66, 392.00], // G major (G3, B3, D4, G4)
      ];

      let chordIndex = 0;

      const playChord = () => {
        if (!isAmbientPlaying || !ambientMasterGain) return;
        const currentChord = chordProgressions[chordIndex % chordProgressions.length];
        chordIndex++;

        // Stop previous notes gracefully
        ambientOscillators.forEach((osc) => {
          try { osc.stop(); } catch (e) {}
        });
        ambientOscillators = [];
        ambientGains = [];

        const now = ctx.currentTime;
        const chordDuration = 5.5; // 5.5 seconds per chord

        currentChord.forEach((freq, idx) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          const filter = ctx.createBiquadFilter();

          osc.type = idx === 0 ? 'sine' : 'triangle';
          osc.frequency.setValueAtTime(freq, now);

          // Low pass filter for soft warm texture
          filter.type = 'lowpass';
          filter.frequency.setValueAtTime(600, now);
          filter.frequency.exponentialRampToValueAtTime(1200, now + 2.5);
          filter.frequency.exponentialRampToValueAtTime(600, now + chordDuration);

          // Gentle attack and long release
          gain.gain.setValueAtTime(0.001, now);
          gain.gain.linearRampToValueAtTime(0.04 / currentChord.length, now + 1.2);
          gain.gain.setValueAtTime(0.04 / currentChord.length, now + chordDuration - 1.5);
          gain.gain.linearRampToValueAtTime(0.001, now + chordDuration);

          osc.connect(filter);
          filter.connect(gain);
          gain.connect(ambientMasterGain!);

          osc.start(now);
          osc.stop(now + chordDuration + 0.1);

          ambientOscillators.push(osc);
          ambientGains.push(gain);
        });
      };

      isAmbientPlaying = true;
      playChord();
      ambientInterval = setInterval(playChord, 5200);
      return true;
    } catch (e) {
      console.warn('Ambient music failed to start', e);
      return false;
    }
  },

  stopAmbientMusic: () => {
    isAmbientPlaying = false;
    if (ambientInterval) {
      clearInterval(ambientInterval);
      ambientInterval = null;
    }
    ambientOscillators.forEach((osc) => {
      try { osc.stop(); } catch (e) {}
    });
    ambientOscillators = [];
    ambientGains = [];
    if (ambientMasterGain) {
      try {
        ambientMasterGain.gain.setValueAtTime(0, audioCtx ? audioCtx.currentTime : 0);
      } catch (e) {}
      ambientMasterGain = null;
    }
  },

  toggleAmbientMusic: () => {
    if (isAmbientPlaying) {
      soundEffects.stopAmbientMusic();
      return false;
    } else {
      return soundEffects.startAmbientMusic();
    }
  },

  isMusicPlaying: () => isAmbientPlaying,
};
