import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  User as FirebaseUser,
  updateProfile,
  sendPasswordResetEmail
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  getDocFromServer, 
  setDoc, 
  getDoc, 
  collection, 
  getDocs,
  serverTimestamp
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { UserRole, FirebaseAllowedEmail } from '../types/family';

// Authorized Master Admin Email Accounts specified by Maruf
export const AUTHORIZED_ADMIN_EMAILS = [
  'habiburmaruf@gmail.com',
  'lion.maruf@gmail.com',
  'marufsage@gmail.com',
  'marufsage2@gmail.com'
] as const;

export type AuthorizedAdminEmail = typeof AUTHORIZED_ADMIN_EMAILS[number];

// Initialize Firebase App
const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// Check if an email has Master Admin access (checks hardcoded master list and optional dynamic list)
export function isAuthorizedAdminEmail(email?: string | null, customAllowedList?: FirebaseAllowedEmail[]): boolean {
  if (!email) return false;
  const cleanEmail = email.trim().toLowerCase();
  
  // 1. Check primary master list
  const isMaster = AUTHORIZED_ADMIN_EMAILS.some((adminEmail) => adminEmail.toLowerCase() === cleanEmail);
  if (isMaster) return true;

  // 2. Check dynamic allowed emails list from Admin Panel
  if (customAllowedList && customAllowedList.length > 0) {
    const found = customAllowedList.find((item) => item.email.trim().toLowerCase() === cleanEmail && item.isActive);
    if (found && found.role === 'Admin') return true;
  }

  // 3. Fallback check localStorage if available
  try {
    const cached = localStorage.getItem('maruf_vault_admin_settings');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed.allowedEmails && Array.isArray(parsed.allowedEmails)) {
        const match = parsed.allowedEmails.find((item: FirebaseAllowedEmail) => item.email?.trim().toLowerCase() === cleanEmail && item.isActive);
        if (match && match.role === 'Admin') return true;
      }
    }
  } catch (e) {}

  return false;
}

// Find allowed email entry if present
export function findAllowedEmailConfig(email?: string | null, customAllowedList?: FirebaseAllowedEmail[]): FirebaseAllowedEmail | null {
  if (!email) return null;
  const cleanEmail = email.trim().toLowerCase();

  if (customAllowedList && customAllowedList.length > 0) {
    const match = customAllowedList.find((item) => item.email.trim().toLowerCase() === cleanEmail);
    if (match) return match;
  }

  try {
    const cached = localStorage.getItem('maruf_vault_admin_settings');
    if (cached) {
      const parsed = JSON.parse(cached);
      if (parsed.allowedEmails && Array.isArray(parsed.allowedEmails)) {
        const match = parsed.allowedEmails.find((item: FirebaseAllowedEmail) => item.email?.trim().toLowerCase() === cleanEmail);
        if (match) return match;
      }
    }
  } catch (e) {}

  if (AUTHORIZED_ADMIN_EMAILS.some((adminEmail) => adminEmail.toLowerCase() === cleanEmail)) {
    return {
      id: `master-${cleanEmail}`,
      email: cleanEmail,
      displayName: cleanEmail.includes('maruf') ? 'মারুফ (মাস্টার অ্যাডমিন)' : cleanEmail.split('@')[0],
      role: 'Admin',
      isActive: true,
      addedAt: '2026-10-15',
      isMasterAccount: true,
      notes: 'মাস্টার অ্যাকাউন্ট',
    };
  }

  return null;
}

// Check if an email is permitted to login under Strict Login Mode
export function isEmailPermittedToLogin(email?: string | null, strictMode?: boolean, customAllowedList?: FirebaseAllowedEmail[]): boolean {
  if (!strictMode) return true; // Open mode
  if (!email) return false;
  const config = findAllowedEmailConfig(email, customAllowedList);
  return !!(config && config.isActive);
}

// Mandatory connection test on boot as per Firebase Integration Skill
export async function testConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    console.log('✅ Firebase connection established successfully.');
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration or network connection.');
      return false;
    }
    // Document not found is fine, connection is still alive
    return true;
  }
}

// Trigger initial connection test
testConnection().catch(() => {});

// User Profile Data in Firestore
export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  isMasterAdmin: boolean;
  createdAt?: any;
  lastLogin?: any;
}

// Get or Create user document in Firestore with RBAC role
export async function syncUserProfile(user: FirebaseUser, customAllowedList?: FirebaseAllowedEmail[]): Promise<UserProfile> {
  const allowedConfig = findAllowedEmailConfig(user.email, customAllowedList);
  const isMaster = isAuthorizedAdminEmail(user.email, customAllowedList);
  const assignedRole: UserRole = allowedConfig ? allowedConfig.role : (isMaster ? 'Admin' : 'Viewer');

  const userDocRef = doc(db, 'users', user.uid);
  try {
    const snap = await getDoc(userDocRef);
    if (snap.exists()) {
      const data = snap.data() as UserProfile;
      // If email is in authorized admin list or configured role differs, keep updated
      if (assignedRole === 'Admin' && data.role !== 'Admin') {
        await setDoc(userDocRef, { role: 'Admin', isMasterAdmin: true, lastLogin: serverTimestamp() }, { merge: true });
        data.role = 'Admin';
        data.isMasterAdmin = true;
      } else {
        await setDoc(userDocRef, { lastLogin: serverTimestamp() }, { merge: true });
      }
      return data;
    } else {
      const newProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: user.displayName || allowedConfig?.displayName || (isMaster ? 'মারুফ (মাস্টার অ্যাডমিন)' : user.email?.split('@')[0] || 'User'),
        role: assignedRole,
        isMasterAdmin: isMaster,
        createdAt: serverTimestamp(),
        lastLogin: serverTimestamp(),
      };
      await setDoc(userDocRef, newProfile);
      return newProfile;
    }
  } catch (err) {
    console.warn('Firestore profile sync fallback (using local role):', err);
    return {
      uid: user.uid,
      email: user.email || '',
      displayName: user.displayName || allowedConfig?.displayName || (isMaster ? 'মারুফ (মাস্টার অ্যাডমিন)' : 'User'),
      role: assignedRole,
      isMasterAdmin: isMaster,
    };
  }
}

// Firebase Email & Password Sign In
export async function loginWithEmail(email: string, pass: string, customAllowedList?: FirebaseAllowedEmail[]): Promise<{ user: FirebaseUser; profile: UserProfile }> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), pass);
  const profile = await syncUserProfile(cred.user, customAllowedList);
  return { user: cred.user, profile };
}

// Firebase Email & Password Registration
export async function registerWithEmail(email: string, pass: string, displayName?: string, customAllowedList?: FirebaseAllowedEmail[]): Promise<{ user: FirebaseUser; profile: UserProfile }> {
  const cred = await createUserWithEmailAndPassword(auth, email.trim(), pass);
  if (displayName) {
    try {
      await updateProfile(cred.user, { displayName });
    } catch (e) {}
  }
  const profile = await syncUserProfile(cred.user, customAllowedList);
  return { user: cred.user, profile };
}

// Send Password Reset
export async function sendResetPassword(email: string): Promise<boolean> {
  await sendPasswordResetEmail(auth, email.trim());
  return true;
}

// Sign Out
export async function logoutFirebaseUser(): Promise<void> {
  await signOut(auth);
}

